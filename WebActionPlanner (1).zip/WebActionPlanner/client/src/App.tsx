import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import NotFound from "@/pages/not-found";
import AuthPage from "@/pages/auth-page";
import DashboardPage from "@/pages/dashboard-page";
import ContractsPage from "@/pages/contracts-page";
import ContractForm from "@/pages/contract-form";
import DetailedContractForm from "@/pages/detailed-contract-form";
import AppointmentsPage from "@/pages/appointments-page";
import TimeTrackingPage from "@/pages/time-tracking-page";
import StatisticsPage from "@/pages/statistics-page";
import UsersPage from "@/pages/admin/users-page";
import UserImportPage from "@/pages/admin/user-import";
import UserCreatePage from "@/pages/admin/user-create";
import UserEditPage from "@/pages/admin/user-edit";
import { ProtectedRoute } from "./lib/protected-route";
import { MainLayout } from "@/components/layout/main-layout";
import { AuthProvider } from "@/hooks/use-auth";

function ProtectedApp() {
  return (
    <MainLayout>
      <Switch>
        <Route path="/" component={DashboardPage} />
        <Route path="/contracts" component={ContractsPage} />
        <Route path="/contracts/new" component={ContractForm} />
        <Route path="/contracts/:id" component={ContractForm} />
        <Route path="/contracts/detailed/new" component={DetailedContractForm} />
        <Route path="/contracts/detailed/:id" component={DetailedContractForm} />
        <Route path="/appointments" component={AppointmentsPage} />
        <Route path="/time-tracking" component={TimeTrackingPage} />
        <Route path="/statistics" component={StatisticsPage} />
        <Route path="/admin/users" component={UsersPage} />
        <Route path="/admin/users/import" component={UserImportPage} />
        <Route path="/admin/users/create" component={UserCreatePage} />
        <Route path="/admin/users/edit/:id" component={UserEditPage} />
        <Route component={NotFound} />
      </Switch>
    </MainLayout>
  );
}

function Router() {
  return (
    <Switch>
      {/* Auth Page */}
      <Route path="/auth" component={AuthPage} />
      
      {/* Protected Routes - En utilisant un seul ProtectedRoute pour tout, ce qui simplifie la gestion du layout */}
      <ProtectedRoute path="/*" component={ProtectedApp} />
      
      {/* Fallback to 404 */}
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <Router />
        <Toaster />
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
