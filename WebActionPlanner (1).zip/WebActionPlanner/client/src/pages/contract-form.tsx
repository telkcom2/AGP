import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useParams, useLocation, useRoute, Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useAuth } from "@/hooks/use-auth";
import { insertContractSchema, Contract } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import AppLayout from "@/components/layout/app-layout";

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Loader2, AlertCircle, Save, ArrowLeft } from "lucide-react";

// Custom format for contract value (euros to cents)
const contractSchema = insertContractSchema
  .omit({ createdBy: true, validatedBy: true, validatedAt: true })
  .extend({
    contractValue: z.string().refine(
      (val) => {
        const num = parseFloat(val.replace(/,/g, "."));
        return !isNaN(num) && num > 0;
      },
      {
        message: "Value must be a positive number",
      }
    ),
    customerId: z
      .string()
      .optional()
      .transform((val) => (val ? parseInt(val) : undefined)),
  });

type ContractFormValues = z.infer<typeof contractSchema>;

const ContractForm = () => {
  const { t } = useTranslation();
  const params = useParams();
  const [location, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const isEditMode = !!params.id;
  const [match, params2] = useRoute("/contracts/:id");
  const contractId = isEditMode ? parseInt(params.id) : null;

  // Fetch contract details if in edit mode
  const {
    data: contract,
    isLoading: isLoadingContract,
    isError: isErrorContract,
  } = useQuery<Contract>({
    queryKey: [`/api/contracts/${contractId}`],
    enabled: isEditMode,
  });

  // Initialize form
  const form = useForm<ContractFormValues>({
    resolver: zodResolver(contractSchema),
    defaultValues: {
      contractNumber: "",
      customerName: "",
      customerEmail: "",
      customerPhone: "",
      productType: "",
      contractValue: "",
      status: "draft",
      notes: "",
    },
  });

  // Fill form with contract data when loaded
  useEffect(() => {
    if (contract) {
      form.reset({
        contractNumber: contract.contractNumber,
        customerName: contract.customerName,
        customerEmail: contract.customerEmail || "",
        customerPhone: contract.customerPhone || "",
        productType: contract.productType,
        contractValue: (contract.contractValue / 100).toString(),
        status: contract.status,
        notes: contract.notes || "",
        customerId: contract.customerId?.toString(),
      });
    }
  }, [contract, form]);

  // Create contract mutation
  const createContractMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/contracts", data);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: t("contract.created"),
        description: t("contract.createdDescription"),
      });
      queryClient.invalidateQueries({ queryKey: ["/api/contracts"] });
      navigate("/contracts");
    },
    onError: (error: Error) => {
      toast({
        title: t("contract.createFailed"),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update contract mutation
  const updateContractMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("PUT", `/api/contracts/${contractId}`, data);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: t("contract.updated"),
        description: t("contract.updatedDescription"),
      });
      queryClient.invalidateQueries({ queryKey: [`/api/contracts/${contractId}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/contracts"] });
      navigate("/contracts");
    },
    onError: (error: Error) => {
      toast({
        title: t("contract.updateFailed"),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: ContractFormValues) => {
    // Convert contract value from euros to cents
    const contractValueCents = Math.round(parseFloat(data.contractValue.replace(/,/g, ".")) * 100);
    
    const contractData = {
      ...data,
      contractValue: contractValueCents,
      customerId: data.customerId ? parseInt(data.customerId as unknown as string) : undefined,
    };

    // Add the user ID as creator if creating a new contract
    if (!isEditMode) {
      contractData.createdBy = user.id;
    }

    if (isEditMode) {
      updateContractMutation.mutate(contractData);
    } else {
      createContractMutation.mutate(contractData);
    }
  };

  // Check if user can edit the contract
  const canEdit = () => {
    if (!contract) return true; // New contract
    
    if (user.role === 'admin') return true;
    
    if (user.role === 'telemarketer') {
      return contract.createdBy === user.id && contract.status === 'draft';
    }
    
    if (user.role === 'supervisor') {
      return contract.status === 'pending' || contract.status === 'draft';
    }
    
    if (user.role === 'backoffice') {
      return contract.status === 'validated';
    }
    
    return false;
  };

  // Loading state
  if (isEditMode && isLoadingContract) {
    return (
      <AppLayout>
        <div className="py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          </div>
        </div>
      </AppLayout>
    );
  }

  // Error state
  if (isEditMode && isErrorContract) {
    return (
      <AppLayout>
        <div className="py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <Alert variant="destructive" className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>{t("errors.title")}</AlertTitle>
              <AlertDescription>
                {t("contract.loadFailed")}
              </AlertDescription>
            </Alert>
            <Button asChild>
              <Link href="/contracts">
                <ArrowLeft className="mr-2 h-4 w-4" />
                {t("common.backToList")}
              </Link>
            </Button>
          </div>
        </div>
      </AppLayout>
    );
  }

  // Permission check
  if (isEditMode && contract && !canEdit()) {
    return (
      <AppLayout>
        <div className="py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <Alert variant="destructive" className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>{t("errors.permissionDenied")}</AlertTitle>
              <AlertDescription>
                {t("contract.cannotEdit")}
              </AlertDescription>
            </Alert>
            <Button asChild>
              <Link href="/contracts">
                <ArrowLeft className="mr-2 h-4 w-4" />
                {t("common.backToList")}
              </Link>
            </Button>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="py-6">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-semibold text-gray-900 dark:text-gray-100">
              {isEditMode
                ? t("contract.editContract")
                : t("contract.newContract")}
            </h1>
            <Button variant="outline" asChild>
              <Link href="/contracts">
                <ArrowLeft className="mr-2 h-4 w-4" />
                {t("common.cancel")}
              </Link>
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>
                {isEditMode ? t("contract.contractDetails") : t("contract.createContract")}
              </CardTitle>
              <CardDescription>
                {isEditMode
                  ? t("contract.editContractDescription")
                  : t("contract.createContractDescription")}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                  {/* Contract number is readonly in edit mode and auto-generated in create mode */}
                  {isEditMode && (
                    <FormField
                      control={form.control}
                      name="contractNumber"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("contract.number")}</FormLabel>
                          <FormControl>
                            <Input {...field} disabled />
                          </FormControl>
                          <FormDescription>
                            {t("contract.numberDescription")}
                          </FormDescription>
                        </FormItem>
                      )}
                    />
                  )}

                  <Separator className="my-6" />
                  <h3 className="text-lg font-medium mb-4">
                    {t("contract.customerInformation")}
                  </h3>

                  {/* Customer ID (optional) */}
                  <FormField
                    control={form.control}
                    name="customerId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("contract.customerId")}</FormLabel>
                        <FormControl>
                          <Input
                            type="text"
                            placeholder={t("contract.customerIdPlaceholder")}
                            {...field}
                            value={field.value || ""}
                          />
                        </FormControl>
                        <FormDescription>
                          {t("contract.customerIdDescription")}
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Customer Name */}
                  <FormField
                    control={form.control}
                    name="customerName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("contract.customerName")}</FormLabel>
                        <FormControl>
                          <Input
                            placeholder={t("contract.customerNamePlaceholder")}
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    {/* Customer Email */}
                    <FormField
                      control={form.control}
                      name="customerEmail"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("contract.customerEmail")}</FormLabel>
                          <FormControl>
                            <Input
                              type="email"
                              placeholder={t("contract.customerEmailPlaceholder")}
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {/* Customer Phone */}
                    <FormField
                      control={form.control}
                      name="customerPhone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t("contract.customerPhone")}</FormLabel>
                          <FormControl>
                            <Input
                              placeholder={t("contract.customerPhonePlaceholder")}
                              {...field}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <Separator className="my-6" />
                  <h3 className="text-lg font-medium mb-4">
                    {t("contract.productInformation")}
                  </h3>

                  {/* Product Type */}
                  <FormField
                    control={form.control}
                    name="productType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("contract.productType")}</FormLabel>
                        <FormControl>
                          <Input
                            placeholder={t("contract.productTypePlaceholder")}
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Contract Value */}
                  <FormField
                    control={form.control}
                    name="contractValue"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("contract.value")}</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                              €
                            </span>
                            <Input
                              className="pl-8"
                              placeholder="0.00"
                              {...field}
                            />
                          </div>
                        </FormControl>
                        <FormDescription>
                          {t("contract.valueDescription")}
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Notes */}
                  <FormField
                    control={form.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t("contract.notes")}</FormLabel>
                        <FormControl>
                          <Textarea
                            placeholder={t("contract.notesPlaceholder")}
                            className="min-h-32"
                            {...field}
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="flex justify-end space-x-4">
                    <Button type="button" variant="outline" asChild>
                      <Link href="/contracts">{t("common.cancel")}</Link>
                    </Button>
                    <Button
                      type="submit"
                      disabled={
                        createContractMutation.isPending ||
                        updateContractMutation.isPending
                      }
                    >
                      {(createContractMutation.isPending ||
                        updateContractMutation.isPending) ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : (
                        <Save className="mr-2 h-4 w-4" />
                      )}
                      {isEditMode
                        ? t("common.save")
                        : t("contract.create")}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
};

export default ContractForm;
