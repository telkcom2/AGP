import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Appointment, insertAppointmentSchema } from "@shared/schema";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format, parseISO, addMinutes, isAfter } from "date-fns";
import { fr, it } from "date-fns/locale";
import AppLayout from "@/components/layout/app-layout";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar } from "@/components/ui/calendar";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Loader2, CalendarIcon, MoreHorizontal, Plus, Clock } from "lucide-react";

// Form schema
const appointmentSchema = insertAppointmentSchema
  .omit({ createdBy: true })
  .extend({
    date: z.string(),
    duration: z.string().transform((val) => parseInt(val)),
  });

type AppointmentFormValues = z.infer<typeof appointmentSchema>;

const AppointmentsPage = () => {
  const { t, i18n } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  const [viewMode, setViewMode] = useState<"list" | "calendar">("list");
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());

  // Locale for date formatting
  const dateLocale = i18n.language === 'fr' ? fr : it;

  // Fetch appointments
  const { data: appointments, isLoading } = useQuery<Appointment[]>({
    queryKey: ["/api/appointments"],
  });

  // Form for creating/editing appointments
  const form = useForm<AppointmentFormValues>({
    resolver: zodResolver(appointmentSchema),
    defaultValues: {
      title: "",
      description: "",
      customerName: "",
      date: format(new Date(), "yyyy-MM-dd'T'HH:mm"),
      duration: "30",
      status: "scheduled",
      notes: "",
    },
  });

  // Reset form when dialog opens/closes
  const resetForm = (appointment?: Appointment) => {
    if (appointment) {
      form.reset({
        title: appointment.title,
        description: appointment.description || "",
        customerName: appointment.customerName,
        customerId: appointment.customerId,
        date: format(new Date(appointment.date), "yyyy-MM-dd'T'HH:mm"),
        duration: appointment.duration.toString(),
        status: appointment.status,
        notes: appointment.notes || "",
      });
    } else {
      form.reset({
        title: "",
        description: "",
        customerName: "",
        date: format(new Date(), "yyyy-MM-dd'T'HH:mm"),
        duration: "30",
        status: "scheduled",
        notes: "",
      });
    }
  };

  // Create appointment mutation
  const createAppointmentMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/appointments", data);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: t("appointment.created"),
        description: t("appointment.createdDescription"),
      });
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      setIsDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: t("appointment.createFailed"),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update appointment mutation
  const updateAppointmentMutation = useMutation({
    mutationFn: async (data: { id: number; appointment: any }) => {
      const response = await apiRequest("PUT", `/api/appointments/${data.id}`, data.appointment);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: t("appointment.updated"),
        description: t("appointment.updatedDescription"),
      });
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      setIsDialogOpen(false);
    },
    onError: (error: Error) => {
      toast({
        title: t("appointment.updateFailed"),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle form submission
  const onSubmit = (data: AppointmentFormValues) => {
    const appointmentData = {
      ...data,
      createdBy: user.id,
    };

    if (selectedAppointment) {
      updateAppointmentMutation.mutate({
        id: selectedAppointment.id,
        appointment: appointmentData,
      });
    } else {
      createAppointmentMutation.mutate(appointmentData);
    }
  };

  // Open dialog for editing appointment
  const handleEditAppointment = (appointment: Appointment) => {
    setSelectedAppointment(appointment);
    resetForm(appointment);
    setIsDialogOpen(true);
  };

  // Open dialog for creating new appointment
  const handleNewAppointment = () => {
    setSelectedAppointment(null);
    resetForm();
    setIsDialogOpen(true);
  };

  // Handle status change
  const handleStatusChange = async (appointmentId: number, newStatus: string) => {
    try {
      await apiRequest("PUT", `/api/appointments/${appointmentId}`, { status: newStatus });
      
      queryClient.invalidateQueries({ queryKey: ["/api/appointments"] });
      toast({
        title: t("appointment.statusUpdated"),
        description: t("appointment.statusUpdatedDescription"),
      });
    } catch (error) {
      toast({
        title: t("appointment.statusUpdateFailed"),
        description: error instanceof Error ? error.message : t("errors.unknown"),
        variant: "destructive",
      });
    }
  };

  // Filter appointments for calendar view
  const getAppointmentsForDate = (date: Date) => {
    if (!appointments) return [];
    
    return appointments.filter((appointment) => {
      const appointmentDate = new Date(appointment.date);
      return (
        appointmentDate.getDate() === date.getDate() &&
        appointmentDate.getMonth() === date.getMonth() &&
        appointmentDate.getFullYear() === date.getFullYear()
      );
    });
  };

  // Status badge colors
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case "scheduled":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200";
      case "confirmed":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200";
      case "cancelled":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
      case "completed":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300";
    }
  };

  // Check if appointment is in the past
  const isAppointmentInPast = (date: string) => {
    return isAfter(new Date(), new Date(date));
  };

  return (
    <AppLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-6">
            <h1 className="text-2xl font-semibold text-gray-900 dark:text-gray-100">
              {t("appointment.appointments")}
            </h1>
            <div className="flex items-center space-x-4">
              <div className="hidden sm:flex space-x-2">
                <Button
                  variant={viewMode === "list" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setViewMode("list")}
                >
                  {t("appointment.listView")}
                </Button>
                <Button
                  variant={viewMode === "calendar" ? "default" : "outline"}
                  size="sm"
                  onClick={() => setViewMode("calendar")}
                >
                  {t("appointment.calendarView")}
                </Button>
              </div>
              <Button onClick={handleNewAppointment}>
                <Plus className="h-4 w-4 mr-2" />
                {t("appointment.newAppointment")}
              </Button>
            </div>
          </div>

          {isLoading ? (
            <div className="flex justify-center items-center p-12">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : viewMode === "list" ? (
            <Card>
              <CardHeader>
                <CardTitle>{t("appointment.upcomingAppointments")}</CardTitle>
                <CardDescription>
                  {t("appointment.manageYourSchedule")}
                </CardDescription>
              </CardHeader>
              <CardContent>
                {appointments && appointments.length > 0 ? (
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>{t("appointment.title")}</TableHead>
                        <TableHead>{t("appointment.customer")}</TableHead>
                        <TableHead>{t("appointment.dateTime")}</TableHead>
                        <TableHead>{t("appointment.duration")}</TableHead>
                        <TableHead>{t("appointment.status")}</TableHead>
                        <TableHead className="text-right">{t("common.actions")}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {appointments
                        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                        .map((appointment) => (
                          <TableRow key={appointment.id}>
                            <TableCell className="font-medium">
                              {appointment.title}
                            </TableCell>
                            <TableCell>{appointment.customerName}</TableCell>
                            <TableCell>
                              {format(new Date(appointment.date), "PPp", {
                                locale: dateLocale,
                              })}
                            </TableCell>
                            <TableCell>
                              {appointment.duration} {t("appointment.minutes")}
                            </TableCell>
                            <TableCell>
                              <span
                                className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(
                                  appointment.status
                                )}`}
                              >
                                {t(`appointment.status.${appointment.status}`)}
                              </span>
                            </TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon">
                                    <MoreHorizontal className="h-4 w-4" />
                                    <span className="sr-only">{t("common.openMenu")}</span>
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <DropdownMenuItem onClick={() => handleEditAppointment(appointment)}>
                                    {t("common.edit")}
                                  </DropdownMenuItem>
                                  
                                  {appointment.status === "scheduled" && !isAppointmentInPast(appointment.date) && (
                                    <DropdownMenuItem onSelect={() => handleStatusChange(appointment.id, "confirmed")}>
                                      {t("appointment.confirm")}
                                    </DropdownMenuItem>
                                  )}
                                  
                                  {(appointment.status === "scheduled" || appointment.status === "confirmed") && 
                                   !isAppointmentInPast(appointment.date) && (
                                    <DropdownMenuItem onSelect={() => handleStatusChange(appointment.id, "cancelled")}>
                                      {t("appointment.cancel")}
                                    </DropdownMenuItem>
                                  )}
                                  
                                  {(appointment.status === "scheduled" || appointment.status === "confirmed") && 
                                   isAppointmentInPast(appointment.date) && (
                                    <DropdownMenuItem onSelect={() => handleStatusChange(appointment.id, "completed")}>
                                      {t("appointment.markAsCompleted")}
                                    </DropdownMenuItem>
                                  )}
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                ) : (
                  <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                    {t("appointment.noAppointments")}
                  </div>
                )}
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>{t("appointment.calendarView")}</CardTitle>
                <CardDescription>
                  {t("appointment.calendarDescription")}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="md:col-span-1">
                    <Calendar
                      mode="single"
                      selected={selectedDate}
                      onSelect={setSelectedDate}
                      className="rounded-md border"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <div className="border rounded-md p-4">
                      <h3 className="font-medium mb-4">
                        {selectedDate && format(selectedDate, "PPP", { locale: dateLocale })}
                      </h3>
                      
                      {selectedDate && getAppointmentsForDate(selectedDate).length > 0 ? (
                        <div className="space-y-2">
                          {getAppointmentsForDate(selectedDate)
                            .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
                            .map((appointment) => (
                              <div
                                key={appointment.id}
                                className="border rounded-md p-3 hover:bg-gray-50 dark:hover:bg-gray-800 transition cursor-pointer"
                                onClick={() => handleEditAppointment(appointment)}
                              >
                                <div className="flex justify-between items-start">
                                  <div>
                                    <h4 className="font-medium">{appointment.title}</h4>
                                    <p className="text-sm text-gray-600 dark:text-gray-400">
                                      {appointment.customerName}
                                    </p>
                                  </div>
                                  <span
                                    className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(
                                      appointment.status
                                    )}`}
                                  >
                                    {t(`appointment.status.${appointment.status}`)}
                                  </span>
                                </div>
                                <div className="flex items-center mt-2 text-sm text-gray-600 dark:text-gray-400">
                                  <Clock className="h-4 w-4 mr-1" />
                                  {format(new Date(appointment.date), "HH:mm", {
                                    locale: dateLocale,
                                  })}
                                  {" - "}
                                  {format(addMinutes(new Date(appointment.date), appointment.duration), "HH:mm", {
                                    locale: dateLocale,
                                  })}
                                  <span className="mx-1">•</span>
                                  {appointment.duration} {t("appointment.minutes")}
                                </div>
                                {appointment.description && (
                                  <p className="mt-1 text-sm text-gray-600 dark:text-gray-400 line-clamp-2">
                                    {appointment.description}
                                  </p>
                                )}
                              </div>
                            ))}
                        </div>
                      ) : (
                        <div className="text-center py-8 text-gray-500 dark:text-gray-400">
                          {t("appointment.noAppointmentsForDate")}
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Appointment form dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="sm:max-w-[550px]">
          <DialogHeader>
            <DialogTitle>
              {selectedAppointment
                ? t("appointment.editAppointment")
                : t("appointment.newAppointment")}
            </DialogTitle>
            <DialogDescription>
              {selectedAppointment
                ? t("appointment.editAppointmentDescription")
                : t("appointment.newAppointmentDescription")}
            </DialogDescription>
          </DialogHeader>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t("appointment.title")}</FormLabel>
                    <FormControl>
                      <Input
                        placeholder={t("appointment.titlePlaceholder")}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t("appointment.description")}</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder={t("appointment.descriptionPlaceholder")}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="customerName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t("appointment.customerName")}</FormLabel>
                    <FormControl>
                      <Input
                        placeholder={t("appointment.customerNamePlaceholder")}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t("appointment.dateTime")}</FormLabel>
                      <FormControl>
                        <Input type="datetime-local" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="duration"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>{t("appointment.duration")}</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value.toString()}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder={t("appointment.selectDuration")} />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="15">15 {t("appointment.minutes")}</SelectItem>
                          <SelectItem value="30">30 {t("appointment.minutes")}</SelectItem>
                          <SelectItem value="45">45 {t("appointment.minutes")}</SelectItem>
                          <SelectItem value="60">60 {t("appointment.minutes")}</SelectItem>
                          <SelectItem value="90">90 {t("appointment.minutes")}</SelectItem>
                          <SelectItem value="120">120 {t("appointment.minutes")}</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t("appointment.status.status")}</FormLabel>
                    <Select
                      onValueChange={field.onChange}
                      defaultValue={field.value}
                    >
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder={t("appointment.selectStatus")} />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="scheduled">{t("appointment.status.scheduled")}</SelectItem>
                        <SelectItem value="confirmed">{t("appointment.status.confirmed")}</SelectItem>
                        <SelectItem value="cancelled">{t("appointment.status.cancelled")}</SelectItem>
                        <SelectItem value="completed">{t("appointment.status.completed")}</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="notes"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>{t("appointment.notes")}</FormLabel>
                    <FormControl>
                      <Textarea
                        placeholder={t("appointment.notesPlaceholder")}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <DialogFooter>
                <Button
                  type="submit"
                  disabled={
                    createAppointmentMutation.isPending ||
                    updateAppointmentMutation.isPending
                  }
                >
                  {(createAppointmentMutation.isPending ||
                    updateAppointmentMutation.isPending) && (
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  )}
                  {selectedAppointment
                    ? t("common.save")
                    : t("appointment.create")}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>
    </AppLayout>
  );
};

export default AppointmentsPage;
