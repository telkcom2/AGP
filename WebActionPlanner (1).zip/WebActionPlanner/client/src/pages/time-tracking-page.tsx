import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { format, parse, eachDayOfInterval, startOfWeek, endOfWeek, addWeeks, subWeeks, parseISO, differenceInMinutes, isAfter } from "date-fns";
import { fr, it } from "date-fns/locale";
import AppLayout from "@/components/layout/app-layout";

import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Input } from "@/components/ui/input";

import {
  ChevronLeft,
  ChevronRight,
  Clock,
  Coffee,
  Loader2,
  LogIn,
  LogOut,
  Pause,
  Play
} from "lucide-react";

const TimeTrackingPage = () => {
  const { t, i18n } = useTranslation();
  const { toast } = useToast();
  const [currentWeek, setCurrentWeek] = useState(new Date());
  const [currentTab, setCurrentTab] = useState("weekly");
  const [notes, setNotes] = useState("");
  const [workStatus, setWorkStatus] = useState<'idle' | 'working' | 'paused'>('idle');
  const [currentTime, setCurrentTime] = useState<string>("00:00:00");
  const [elapsedTime, setElapsedTime] = useState<number>(0);
  
  // Date formatting
  const dateLocale = i18n.language === 'fr' ? fr : it;

  // Get today's time tracking data
  const { data: timeTrackings, isLoading: isLoadingTimeTracking } = useQuery({
    queryKey: ["/api/time/today"],
    refetchInterval: 60000, // Refresh every minute
  });

  // Check-in mutation
  const checkInMutation = useMutation({
    mutationFn: async (notes: string) => {
      const res = await apiRequest("POST", "/api/time/checkin", { notes });
      return await res.json();
    },
    onSuccess: () => {
      setWorkStatus('working');
      queryClient.invalidateQueries({ queryKey: ["/api/time/today"] });
      toast({
        title: t('timeTracking.checkedIn'),
        description: format(new Date(), 'HH:mm:ss'),
      });
      setNotes("");
    },
    onError: (error: Error) => {
      toast({
        title: t('timeTracking.checkInFailed'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Check-out mutation
  const checkOutMutation = useMutation({
    mutationFn: async (notes: string) => {
      const res = await apiRequest("POST", "/api/time/checkout", { notes });
      return await res.json();
    },
    onSuccess: () => {
      setWorkStatus('idle');
      queryClient.invalidateQueries({ queryKey: ["/api/time/today"] });
      toast({
        title: t('timeTracking.checkedOut'),
        description: format(new Date(), 'HH:mm:ss'),
      });
      setNotes("");
    },
    onError: (error: Error) => {
      toast({
        title: t('timeTracking.checkOutFailed'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Start pause mutation
  const startPauseMutation = useMutation({
    mutationFn: async (notes: string) => {
      const res = await apiRequest("POST", "/api/time/pause/start", { notes });
      return await res.json();
    },
    onSuccess: () => {
      setWorkStatus('paused');
      queryClient.invalidateQueries({ queryKey: ["/api/time/today"] });
      toast({
        title: t('timeTracking.pauseStarted'),
        description: format(new Date(), 'HH:mm:ss'),
      });
      setNotes("");
    },
    onError: (error: Error) => {
      toast({
        title: t('timeTracking.pauseStartFailed'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // End pause mutation
  const endPauseMutation = useMutation({
    mutationFn: async (notes: string) => {
      const res = await apiRequest("POST", "/api/time/pause/end", { notes });
      return await res.json();
    },
    onSuccess: () => {
      setWorkStatus('working');
      queryClient.invalidateQueries({ queryKey: ["/api/time/today"] });
      toast({
        title: t('timeTracking.pauseEnded'),
        description: format(new Date(), 'HH:mm:ss'),
      });
      setNotes("");
    },
    onError: (error: Error) => {
      toast({
        title: t('timeTracking.pauseEndFailed'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Determine current work status from time tracking data
  useEffect(() => {
    if (!timeTrackings || timeTrackings.length === 0) {
      setWorkStatus('idle');
      return;
    }

    // Sort by timestamp in descending order
    const sortedTimeTrackings = [...timeTrackings].sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );

    const latestEntry = sortedTimeTrackings[0];
    
    if (latestEntry.status === 'in') {
      setWorkStatus('working');
    } else if (latestEntry.status === 'pause') {
      setWorkStatus('paused');
    } else if (latestEntry.status === 'out') {
      setWorkStatus('idle');
    }
  }, [timeTrackings]);

  // Calculate time metrics
  const calculateTimeMetrics = () => {
    if (!timeTrackings || timeTrackings.length === 0) {
      return {
        totalWorked: 0,
        totalPaused: 0,
        checkInTime: null,
        checkOutTime: null,
        status: 'idle',
      };
    }
    
    // Sort entries by timestamp
    const sortedEntries = [...timeTrackings].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );
    
    let totalWorkedMinutes = 0;
    let totalPausedMinutes = 0;
    let checkInTime = null;
    let checkOutTime = null;
    let lastInTime = null;
    let lastPauseTime = null;
    let currentStatus = 'idle';
    
    sortedEntries.forEach((entry) => {
      const timestamp = new Date(entry.timestamp);
      
      if (entry.status === 'in') {
        if (!checkInTime) {
          checkInTime = timestamp;
        }
        
        lastInTime = timestamp;
        
        if (lastPauseTime) {
          totalPausedMinutes += differenceInMinutes(timestamp, lastPauseTime);
          lastPauseTime = null;
        }
      } else if (entry.status === 'out') {
        checkOutTime = timestamp;
        
        if (lastInTime) {
          totalWorkedMinutes += differenceInMinutes(timestamp, lastInTime);
          lastInTime = null;
        }
      } else if (entry.status === 'pause') {
        if (lastInTime) {
          totalWorkedMinutes += differenceInMinutes(timestamp, lastInTime);
          lastInTime = null;
        }
        
        lastPauseTime = timestamp;
      }
      
      currentStatus = entry.status;
    });
    
    // Calculate ongoing session time
    const now = new Date();
    if (lastInTime && currentStatus === 'in') {
      totalWorkedMinutes += differenceInMinutes(now, lastInTime);
    } else if (lastPauseTime && currentStatus === 'pause') {
      totalPausedMinutes += differenceInMinutes(now, lastPauseTime);
    }
    
    return {
      totalWorked: totalWorkedMinutes,
      totalPaused: totalPausedMinutes,
      checkInTime,
      checkOutTime,
      status: currentStatus,
    };
  };

  // Timer to update current time every second
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (workStatus !== 'idle') {
      const { totalWorked } = calculateTimeMetrics();
      setElapsedTime(totalWorked);
      
      const updateTimer = () => {
        const { totalWorked } = calculateTimeMetrics();
        setElapsedTime(totalWorked);
        
        const hours = Math.floor(totalWorked / 60);
        const minutes = Math.floor(totalWorked % 60);
        const seconds = Math.floor((totalWorked * 60) % 60);
        
        setCurrentTime(
          `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
        );
      };
      
      updateTimer();
      interval = setInterval(updateTimer, 1000);
    } else {
      setCurrentTime("00:00:00");
      setElapsedTime(0);
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [workStatus, timeTrackings]);

  // Handle check-in
  const handleCheckIn = () => {
    checkInMutation.mutate(notes);
  };

  // Handle check-out
  const handleCheckOut = () => {
    checkOutMutation.mutate(notes);
  };

  // Handle pause
  const handlePause = () => {
    if (workStatus === 'paused') {
      endPauseMutation.mutate(notes);
    } else {
      startPauseMutation.mutate(notes);
    }
  };

  // Get days of current week
  const daysOfWeek = eachDayOfInterval({
    start: startOfWeek(currentWeek, { weekStartsOn: 1 }),
    end: endOfWeek(currentWeek, { weekStartsOn: 1 }),
  });

  // Format week range for display
  const formatWeekRange = () => {
    const start = startOfWeek(currentWeek, { weekStartsOn: 1 });
    const end = endOfWeek(currentWeek, { weekStartsOn: 1 });
    return `${format(start, 'PP', { locale: dateLocale })} - ${format(end, 'PP', { locale: dateLocale })}`;
  };

  // Navigation to previous week
  const goToPreviousWeek = () => {
    setCurrentWeek(subWeeks(currentWeek, 1));
  };

  // Navigation to next week
  const goToNextWeek = () => {
    setCurrentWeek(addWeeks(currentWeek, 1));
  };

  // Navigation to current week
  const goToCurrentWeek = () => {
    setCurrentWeek(new Date());
  };

  // Time metrics
  const timeMetrics = calculateTimeMetrics();
  const targetHoursPerDay = 8 * 60; // 8 hours in minutes
  const progressPercentage = Math.min(100, (timeMetrics.totalWorked / targetHoursPerDay) * 100);

  // Mock weekly data (in a real app, this would come from an API)
  const weeklyData = daysOfWeek.map(day => {
    // For simplicity, we're generating random data for past days
    // In a real app, you would fetch this from your API
    const isToday = format(day, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd');
    const isPast = day < new Date(new Date().setHours(0, 0, 0, 0));
    
    if (isToday) {
      return {
        date: day,
        hoursWorked: timeMetrics.totalWorked / 60,
        breakTime: timeMetrics.totalPaused / 60,
        checkIn: timeMetrics.checkInTime ? format(timeMetrics.checkInTime, 'HH:mm') : '-',
        checkOut: timeMetrics.checkOutTime ? format(timeMetrics.checkOutTime, 'HH:mm') : '-',
        status: timeMetrics.status
      };
    } else if (isPast) {
      // Random data for past days
      const randomHours = 7 + Math.random() * 2; // Between 7 and 9 hours
      const randomBreak = 0.5 + Math.random() * 0.5; // Between 30 and 60 minutes
      
      return {
        date: day,
        hoursWorked: randomHours,
        breakTime: randomBreak,
        checkIn: '09:00',
        checkOut: `${17 + Math.floor(randomHours - 8)}:${Math.floor(Math.random() * 60).toString().padStart(2, '0')}`,
        status: 'out'
      };
    } else {
      // Future days
      return {
        date: day,
        hoursWorked: 0,
        breakTime: 0,
        checkIn: '-',
        checkOut: '-',
        status: 'idle'
      };
    }
  });

  return (
    <AppLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h1 className="text-2xl font-semibold text-gray-900 dark:text-gray-100 mb-6">
            {t("timeTracking.title")}
          </h1>

          {/* Today's time tracking */}
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>{t("timeTracking.today")}</CardTitle>
              <CardDescription>
                {format(new Date(), "PPP", { locale: dateLocale })}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
                {/* Time worked */}
                <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <Clock className="h-5 w-5 mr-2 text-primary" />
                    <h3 className="text-sm font-medium">{t("timeTracking.timeWorked")}</h3>
                  </div>
                  <p className="text-2xl font-bold">{currentTime}</p>
                  <Progress className="mt-2" value={progressPercentage} />
                  <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                    {Math.floor(timeMetrics.totalWorked / 60)}h {Math.floor(timeMetrics.totalWorked % 60)}m
                    {' '}/{' '}
                    {Math.floor(targetHoursPerDay / 60)}h
                  </p>
                </div>

                {/* Status */}
                <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <div className="mr-2">
                      {workStatus === 'working' ? (
                        <Play className="h-5 w-5 text-green-500" />
                      ) : workStatus === 'paused' ? (
                        <Pause className="h-5 w-5 text-yellow-500" />
                      ) : (
                        <LogOut className="h-5 w-5 text-red-500" />
                      )}
                    </div>
                    <h3 className="text-sm font-medium">{t("timeTracking.currentStatus")}</h3>
                  </div>
                  <p className="text-xl font-bold">
                    {workStatus === 'working' && (
                      <span className="text-green-600 dark:text-green-500">{t("dashboard.status.working")}</span>
                    )}
                    {workStatus === 'paused' && (
                      <span className="text-yellow-600 dark:text-yellow-500">{t("dashboard.status.paused")}</span>
                    )}
                    {workStatus === 'idle' && (
                      <span className="text-gray-600 dark:text-gray-400">{t("dashboard.status.idle")}</span>
                    )}
                  </p>
                  <div className="mt-2 space-y-1 text-sm">
                    {timeMetrics.checkInTime && (
                      <div className="flex items-center text-gray-600 dark:text-gray-400">
                        <LogIn className="h-4 w-4 mr-1" />
                        {t("timeTracking.checkedInAt", { time: format(timeMetrics.checkInTime, "HH:mm", { locale: dateLocale }) })}
                      </div>
                    )}
                    {timeMetrics.checkOutTime && (
                      <div className="flex items-center text-gray-600 dark:text-gray-400">
                        <LogOut className="h-4 w-4 mr-1" />
                        {t("timeTracking.checkedOutAt", { time: format(timeMetrics.checkOutTime, "HH:mm", { locale: dateLocale }) })}
                      </div>
                    )}
                  </div>
                </div>

                {/* Breaks */}
                <div className="bg-gray-50 dark:bg-gray-800 p-4 rounded-lg">
                  <div className="flex items-center mb-2">
                    <Coffee className="h-5 w-5 mr-2 text-primary" />
                    <h3 className="text-sm font-medium">{t("timeTracking.breaks")}</h3>
                  </div>
                  <p className="text-2xl font-bold">
                    {Math.floor(timeMetrics.totalPaused / 60)}h {Math.floor(timeMetrics.totalPaused % 60)}m
                  </p>
                  <div className="mt-2 text-sm text-gray-600 dark:text-gray-400">
                    {t("timeTracking.breakExplanation")}
                  </div>
                </div>
              </div>

              {/* Actions */}
              <div className="space-y-4">
                <Separator />
                
                <div className="mt-4">
                  <Input
                    placeholder={t("timeTracking.notesPlaceholder")}
                    value={notes}
                    onChange={(e) => setNotes(e.target.value)}
                    className="mb-4"
                  />
                  
                  <div className="flex flex-wrap gap-2">
                    <Button
                      onClick={handleCheckIn}
                      disabled={workStatus !== 'idle' || checkInMutation.isPending}
                      className="flex-1"
                      variant={workStatus === 'idle' ? "default" : "outline"}
                    >
                      {checkInMutation.isPending ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : (
                        <LogIn className="mr-2 h-4 w-4" />
                      )}
                      {t("timeTracking.checkIn")}
                    </Button>
                    
                    <Button
                      onClick={handlePause}
                      disabled={workStatus === 'idle' || startPauseMutation.isPending || endPauseMutation.isPending}
                      className="flex-1"
                      variant={workStatus === 'working' || workStatus === 'paused' ? "default" : "outline"}
                    >
                      {startPauseMutation.isPending || endPauseMutation.isPending ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : workStatus === 'paused' ? (
                        <Play className="mr-2 h-4 w-4" />
                      ) : (
                        <Pause className="mr-2 h-4 w-4" />
                      )}
                      {workStatus === 'paused' ? t("timeTracking.resume") : t("timeTracking.pause")}
                    </Button>
                    
                    <Button
                      onClick={handleCheckOut}
                      disabled={workStatus === 'idle' || checkOutMutation.isPending}
                      className="flex-1"
                      variant={workStatus !== 'idle' ? "default" : "outline"}
                    >
                      {checkOutMutation.isPending ? (
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      ) : (
                        <LogOut className="mr-2 h-4 w-4" />
                      )}
                      {t("timeTracking.checkOut")}
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Weekly time tracking */}
          <Card>
            <CardHeader>
              <CardTitle>{t("timeTracking.history")}</CardTitle>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={goToPreviousWeek}
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <span className="text-sm font-medium">
                    {formatWeekRange()}
                  </span>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={goToNextWeek}
                    disabled={isAfter(endOfWeek(currentWeek, { weekStartsOn: 1 }), new Date())}
                  >
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={goToCurrentWeek}
                    className="ml-2"
                  >
                    {t("timeTracking.today")}
                  </Button>
                </div>
                
                <Tabs value={currentTab} onValueChange={setCurrentTab} className="hidden sm:block">
                  <TabsList>
                    <TabsTrigger value="weekly">{t("timeTracking.weekly")}</TabsTrigger>
                    <TabsTrigger value="summary">{t("timeTracking.summary")}</TabsTrigger>
                  </TabsList>
                </Tabs>
              </div>
            </CardHeader>
            <CardContent>
              <TabsContent value="weekly" className="m-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>{t("timeTracking.date")}</TableHead>
                      <TableHead>{t("timeTracking.checkIn")}</TableHead>
                      <TableHead>{t("timeTracking.checkOut")}</TableHead>
                      <TableHead>{t("timeTracking.hoursWorked")}</TableHead>
                      <TableHead>{t("timeTracking.breakTime")}</TableHead>
                      <TableHead>{t("timeTracking.status")}</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {weeklyData.map((day) => (
                      <TableRow key={format(day.date, 'yyyy-MM-dd')}>
                        <TableCell className={format(day.date, 'yyyy-MM-dd') === format(new Date(), 'yyyy-MM-dd') ? "font-bold" : ""}>
                          {format(day.date, "EEE dd MMM", { locale: dateLocale })}
                        </TableCell>
                        <TableCell>{day.checkIn}</TableCell>
                        <TableCell>{day.checkOut}</TableCell>
                        <TableCell>
                          {day.hoursWorked > 0 ? `${day.hoursWorked.toFixed(2)}h` : "-"}
                        </TableCell>
                        <TableCell>
                          {day.breakTime > 0 ? `${day.breakTime.toFixed(2)}h` : "-"}
                        </TableCell>
                        <TableCell>
                          {day.status !== 'idle' && (
                            <Badge variant={day.status === 'in' ? "default" : day.status === 'pause' ? "outline" : "secondary"}>
                              {t(`dashboard.status.${day.status === 'in' ? 'working' : day.status === 'pause' ? 'paused' : 'idle'}`)}
                            </Badge>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TabsContent>
              
              <TabsContent value="summary" className="m-0">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">{t("timeTracking.weeklyStats")}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">
                            {t("timeTracking.totalHoursWorked")}
                          </div>
                          <div className="text-2xl font-bold">
                            {weeklyData.reduce((total, day) => total + day.hoursWorked, 0).toFixed(2)}h
                          </div>
                        </div>
                        
                        <div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">
                            {t("timeTracking.totalBreakTime")}
                          </div>
                          <div className="text-2xl font-bold">
                            {weeklyData.reduce((total, day) => total + day.breakTime, 0).toFixed(2)}h
                          </div>
                        </div>
                        
                        <div>
                          <div className="text-sm text-gray-500 dark:text-gray-400">
                            {t("timeTracking.averageDailyHours")}
                          </div>
                          <div className="text-2xl font-bold">
                            {(weeklyData.reduce((total, day) => total + day.hoursWorked, 0) / weeklyData.filter(d => d.hoursWorked > 0).length || 0).toFixed(2)}h
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">{t("timeTracking.weekProgress")}</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <div className="text-sm text-gray-500 dark:text-gray-400">
                            {t("timeTracking.weeklyTarget")}
                          </div>
                          <div className="text-sm font-medium">
                            {weeklyData.reduce((total, day) => total + day.hoursWorked, 0).toFixed(2)}h / 40h
                          </div>
                        </div>
                        <Progress
                          value={(weeklyData.reduce((total, day) => total + day.hoursWorked, 0) / 40) * 100}
                          className="h-2"
                        />
                      </div>
                      
                      <div className="mt-6 space-y-4">
                        {weeklyData.map((day) => (
                          <div key={format(day.date, 'yyyy-MM-dd')}>
                            <div className="flex items-center justify-between mb-1">
                              <div className="text-sm text-gray-500 dark:text-gray-400">
                                {format(day.date, "EEEE", { locale: dateLocale })}
                              </div>
                              <div className="text-sm font-medium">
                                {day.hoursWorked.toFixed(2)}h / 8h
                              </div>
                            </div>
                            <Progress
                              value={(day.hoursWorked / 8) * 100}
                              className="h-1"
                            />
                          </div>
                        ))}
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
};

export default TimeTrackingPage;
