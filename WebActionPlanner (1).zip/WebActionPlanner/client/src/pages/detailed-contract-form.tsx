import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useParams, useLocation, Link } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Contract } from "@shared/schema";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import AppLayout from "@/components/layout/app-layout";
import { ContractFormDetailed } from "@/components/contracts/contract-form-detailed";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Button } from "@/components/ui/button";
import { Loader2, AlertCircle, ArrowLeft } from "lucide-react";

export default function DetailedContractForm() {
  const { t } = useTranslation();
  const params = useParams();
  const [location, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const isEditMode = !!params.id;
  const contractId = isEditMode ? parseInt(params.id) : null;

  // Fetch contract details if in edit mode
  const {
    data: contract,
    isLoading: isLoadingContract,
    isError: isErrorContract,
  } = useQuery<Contract>({
    queryKey: [`/api/contracts/${contractId}`],
    enabled: isEditMode,
  });

  // Create contract mutation
  const createContractMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/contracts", data);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Contrat créé",
        description: "Le contrat a été créé avec succès",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/contracts"] });
      navigate("/contracts");
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur lors de la création",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Update contract mutation
  const updateContractMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("PUT", `/api/contracts/${contractId}`, data);
      return await response.json();
    },
    onSuccess: () => {
      toast({
        title: "Contrat mis à jour",
        description: "Le contrat a été mis à jour avec succès",
      });
      queryClient.invalidateQueries({ queryKey: [`/api/contracts/${contractId}`] });
      queryClient.invalidateQueries({ queryKey: ["/api/contracts"] });
      navigate("/contracts");
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur lors de la mise à jour",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: any) => {
    // Add the user ID as creator if creating a new contract
    if (!isEditMode) {
      data.createdBy = user.id;
    }

    if (isEditMode) {
      updateContractMutation.mutate(data);
    } else {
      createContractMutation.mutate(data);
    }
  };

  // Check if user can edit the contract
  const canEdit = () => {
    if (!contract) return true; // New contract
    
    if (user.role === 'manager' || user.role === 'responsable_administratif') return true;
    
    if (user.role === 'televendeur') {
      return contract.createdBy === user.id && contract.status === 'draft';
    }
    
    if (user.role === 'team_leader' || user.role === 'responsable_plateau') {
      return contract.status === 'pending' || contract.status === 'draft';
    }
    
    if (user.role === 'backoffice' || user.role === 'responsable_backoffice') {
      return contract.status === 'validated';
    }
    
    return false;
  };

  // Loading state
  if (isEditMode && isLoadingContract) {
    return (
      <AppLayout>
        <div className="py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          </div>
        </div>
      </AppLayout>
    );
  }

  // Error state
  if (isEditMode && isErrorContract) {
    return (
      <AppLayout>
        <div className="py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <Alert variant="destructive" className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Erreur</AlertTitle>
              <AlertDescription>
                Impossible de charger les détails du contrat
              </AlertDescription>
            </Alert>
            <Button asChild>
              <Link href="/contracts">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Retour à la liste des contrats
              </Link>
            </Button>
          </div>
        </div>
      </AppLayout>
    );
  }

  // Permission check
  if (isEditMode && contract && !canEdit()) {
    return (
      <AppLayout>
        <div className="py-6">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <Alert variant="destructive" className="mb-6">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Accès refusé</AlertTitle>
              <AlertDescription>
                Vous n'avez pas les permissions nécessaires pour modifier ce contrat
              </AlertDescription>
            </Alert>
            <Button asChild>
              <Link href="/contracts">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Retour à la liste des contrats
              </Link>
            </Button>
          </div>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="py-6">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-6">
            <h1 className="text-2xl font-semibold text-gray-900 dark:text-gray-100">
              {isEditMode ? "Modifier le contrat" : "Nouveau contrat"}
            </h1>
            <Button variant="outline" asChild>
              <Link href="/contracts">
                <ArrowLeft className="mr-2 h-4 w-4" />
                Annuler
              </Link>
            </Button>
          </div>
          
          <ContractFormDetailed
            isEditMode={isEditMode}
            initialData={contract}
            onSubmit={onSubmit}
            isLoading={createContractMutation.isPending || updateContractMutation.isPending}
          />
        </div>
      </div>
    </AppLayout>
  );
}