import { useAuth } from "@/hooks/use-auth";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import { z } from "zod";
import { useTranslation } from "react-i18next";
import { Redirect } from "wouter";

import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { insertUserSchema } from "@shared/schema";

// Importer les logos
import tnEccoPowerLogo from "../assets/tn-ecco-power-logo.jpeg";
import telkLogo from "../assets/telk-logo.png";

// Login Schema
const loginSchema = z.object({
  username: z
    .string()
    .min(3, "Le nom d'utilisateur doit contenir au moins 3 caractères"),
  password: z
    .string()
    .min(6, "Le mot de passe doit contenir au moins 6 caractères"),
});

// Register Schema
const registerSchema = insertUserSchema
  .extend({
    confirmPassword: z.string(),
  })
  .refine((data) => data.password === data.confirmPassword, {
    message: "Les mots de passe ne correspondent pas",
    path: ["confirmPassword"],
  });

type LoginFormValues = z.infer<typeof loginSchema>;
type RegisterFormValues = z.infer<typeof registerSchema>;

const AuthPage = () => {
  const { t } = useTranslation();
  const { user, loginMutation } = useAuth();

  // Login form
  const loginForm = useForm<LoginFormValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: "",
      password: "",
    },
  });

  const onLoginSubmit = (data: LoginFormValues) => {
    loginMutation.mutate(data);
  };

  // If user is already logged in, redirect to dashboard
  if (user) {
    return <Redirect to="/" />;
  }

  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-gray-50 p-6">
      <div className="w-full max-w-md flex flex-col items-center">
        {/* Logo TN ECCO POWER centré en haut */}
        <div className="mb-4 flex justify-center">
          <img src={tnEccoPowerLogo} alt="TN ECCO POWER" className="h-24" />
        </div>

        {/* Suppression du bloc séparé pour le nom de l'application */}
        
        <Card className="w-full">
          <CardHeader>
            <CardTitle className="text-center">Bienvenue à AGP v1.0</CardTitle>
            <CardDescription className="text-center">
              Connectez-vous pour accéder à la plateforme
            </CardDescription>
          </CardHeader>
          
          {/* Login Form */}
          <form onSubmit={loginForm.handleSubmit(onLoginSubmit)}>
            <CardContent className="space-y-4 pt-6">
              <div className="space-y-2">
                <Label htmlFor="username">{t("auth.username")}</Label>
                <Input
                  id="username"
                  {...loginForm.register("username")}
                  placeholder={t("auth.usernamePlaceholder")}
                />
                {loginForm.formState.errors.username && (
                  <p className="text-sm text-red-500">
                    {loginForm.formState.errors.username.message}
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="password">{t("auth.password")}</Label>
                <Input
                  id="password"
                  type="password"
                  {...loginForm.register("password")}
                  placeholder={t("auth.passwordPlaceholder")}
                />
                {loginForm.formState.errors.password && (
                  <p className="text-sm text-red-500">
                    {loginForm.formState.errors.password.message}
                  </p>
                )}
              </div>
            </CardContent>

            <CardFooter>
              <Button
                type="submit"
                className="w-full"
                disabled={loginMutation.isPending}
              >
                {loginMutation.isPending ? (
                  <span className="flex items-center">
                    <span className="material-icons animate-spin mr-2">cached</span>
                    {t("auth.loggingIn")}
                  </span>
                ) : (
                  t("auth.login")
                )}
              </Button>
            </CardFooter>
          </form>
        </Card>

        {/* Logo TEL-K avec mention "Développé par" en bas */}
        <div className="mt-8 flex flex-col items-center">
          <p className="text-sm text-gray-500 mb-2">Développé par</p>
          <img src={telkLogo} alt="TEL-K Tunisie" className="h-10" />
        </div>
      </div>
    </div>
  );
};

export default AuthPage;