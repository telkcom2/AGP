import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { format } from "date-fns";
import { fr, it } from "date-fns/locale";
import Sidebar from "@/components/layout/sidebar";
import TopBar from "@/components/layout/topbar";
import { 
  Card, 
  CardContent, 
  CardDescription, 
  CardFooter, 
  CardHeader, 
  CardTitle 
} from "@/components/ui/card";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer
} from "recharts";

const DashboardPage = () => {
  const { t, i18n } = useTranslation();
  const { user } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Get the current date for display
  const currentDate = new Date();
  const dateLocale = i18n.language === 'fr' ? fr : it;
  const formattedDate = format(currentDate, 'PPP', { locale: dateLocale });
  
  // Get today's time tracking data
  const { data: timeTrackings, isLoading: isLoadingTimeTracking } = useQuery({
    queryKey: ["/api/time/today"],
    enabled: !!user,
  });
  
  // Get contracts
  const { data: contracts, isLoading: isLoadingContracts } = useQuery({
    queryKey: ["/api/contracts"],
    enabled: !!user,
  });
  
  // Get appointments
  const { data: appointments, isLoading: isLoadingAppointments } = useQuery({
    queryKey: ["/api/appointments"],
    enabled: !!user,
  });
  
  // Get user statistics
  const { data: statistics, isLoading: isLoadingStatistics } = useQuery({
    queryKey: ["/api/statistics/user"],
    enabled: !!user,
  });
  
  // Calculate time tracking metrics
  const calculateTimeMetrics = () => {
    if (!timeTrackings || timeTrackings.length === 0) {
      return {
        hoursWorked: "0h 00m",
        status: "idle",
        breakTime: "0m"
      };
    }
    
    // Sort entries by timestamp
    const sortedEntries = [...timeTrackings].sort(
      (a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime()
    );
    
    // Calculate total work time
    let totalWorkMs = 0;
    let totalBreakMs = 0;
    let workStartTime = null;
    let lastStatus = "out";
    
    sortedEntries.forEach((entry, index) => {
      const currentTime = new Date(entry.timestamp);
      
      if (entry.status === "in" && lastStatus !== "in") {
        workStartTime = currentTime;
      } else if (entry.status === "pause" && lastStatus === "in") {
        if (workStartTime) {
          totalWorkMs += currentTime.getTime() - workStartTime.getTime();
          workStartTime = null;
        }
      } else if (entry.status === "in" && lastStatus === "pause") {
        workStartTime = currentTime;
      } else if (entry.status === "out") {
        if (workStartTime) {
          totalWorkMs += currentTime.getTime() - workStartTime.getTime();
          workStartTime = null;
        }
      }
      
      lastStatus = entry.status;
    });
    
    // If still working, add time until now
    if (workStartTime && lastStatus === "in") {
      totalWorkMs += new Date().getTime() - workStartTime.getTime();
    }
    
    // Convert to hours and minutes
    const totalWorkHours = Math.floor(totalWorkMs / (1000 * 60 * 60));
    const totalWorkMinutes = Math.floor((totalWorkMs % (1000 * 60 * 60)) / (1000 * 60));
    const totalBreakMinutes = Math.floor(totalBreakMs / (1000 * 60));
    
    return {
      hoursWorked: `${totalWorkHours}h ${totalWorkMinutes.toString().padStart(2, '0')}m`,
      status: lastStatus === "in" ? "working" : lastStatus === "pause" ? "paused" : "idle",
      breakTime: `${totalBreakMinutes}m`
    };
  };
  
  const timeMetrics = calculateTimeMetrics();
  
  // Filter recent contracts
  const recentContracts = contracts
    ? [...contracts]
        .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
        .slice(0, 5)
    : [];
  
  // Filter upcoming appointments
  const upcomingAppointments = appointments
    ? [...appointments]
        .filter(app => new Date(app.date) > new Date())
        .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
        .slice(0, 5)
    : [];
  
  // Mock data for activity chart
  const activityData = [
    { name: '01', contracts: 4, validated: 3, converted: 2 },
    { name: '05', contracts: 3, validated: 2, converted: 1 },
    { name: '10', contracts: 5, validated: 4, converted: 3 },
    { name: '15', contracts: 7, validated: 5, converted: 4 },
    { name: '20', contracts: 6, validated: 4, converted: 3 },
    { name: '25', contracts: 8, validated: 6, converted: 5 },
    { name: '30', contracts: 5, validated: 3, converted: 2 },
  ];
  
  // Performance metrics
  const performanceMetrics = [
    {
      title: t('dashboard.contractsCreated'),
      value: statistics?.contractsCreated || 0,
      change: 12,
      trend: 'up'
    },
    {
      title: t('dashboard.contractsValidated'),
      value: statistics?.contractsValidated || 0,
      change: 8,
      trend: 'up'
    },
    {
      title: t('dashboard.appointmentsScheduled'),
      value: statistics?.appointmentsScheduled || 0,
      change: -3,
      trend: 'down'
    },
    {
      title: t('dashboard.conversionRate'),
      value: statistics?.contractsValidated && statistics?.contractsCreated 
        ? `${Math.round((statistics.contractsValidated / statistics.contractsCreated) * 100)}%` 
        : '0%',
      change: 5,
      trend: 'up'
    },
  ];
  
  return (
    <div className="min-h-screen flex">
      {/* Sidebar Navigation */}
      <Sidebar />
      
      {/* Main Content Area */}
      <div className="flex-1 flex flex-col">
        {/* Top Navigation Bar */}
        <TopBar onMobileMenuToggle={() => setMobileMenuOpen(!mobileMenuOpen)} />
        
        {/* Mobile menu (off-canvas) */}
        {mobileMenuOpen && (
          <div className="lg:hidden fixed inset-0 z-40">
            <div 
              className="fixed inset-0 bg-gray-600 bg-opacity-75" 
              onClick={() => setMobileMenuOpen(false)}
            ></div>
            <div className="fixed inset-y-0 left-0 flex flex-col w-full max-w-xs bg-primary-700">
              <Sidebar />
            </div>
          </div>
        )}
        
        {/* Main Content */}
        <main className="flex-1 overflow-auto bg-gray-100 dark:bg-gray-900">
          <div className="py-6">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <h1 className="text-2xl font-semibold text-gray-900 dark:text-gray-100">
                {t('dashboard.title')}
              </h1>
            </div>
            
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              {/* Time Tracking Summary */}
              <section className="mt-6">
                <div className="bg-white dark:bg-gray-800 shadow rounded-lg p-4 sm:p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-medium text-gray-900 dark:text-gray-100">
                      {t('dashboard.timeTrackingToday')}
                    </h2>
                    <span className="text-sm text-gray-500 dark:text-gray-400">{formattedDate}</span>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 bg-blue-100 dark:bg-blue-900 rounded-full p-2">
                          <span className="material-icons text-blue-600 dark:text-blue-300">access_time</span>
                        </div>
                        <div className="ml-4">
                          <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100">
                            {t('dashboard.hoursWorked')}
                          </h3>
                          <p className="text-lg font-semibold">{timeMetrics.hoursWorked}</p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 bg-green-100 dark:bg-green-900 rounded-full p-2">
                          <span className="material-icons text-green-600 dark:text-green-300">check_circle</span>
                        </div>
                        <div className="ml-4">
                          <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100">
                            {t('dashboard.currentStatus')}
                          </h3>
                          <p className={`text-lg font-semibold ${
                            timeMetrics.status === 'working' 
                              ? 'text-green-600 dark:text-green-400' 
                              : timeMetrics.status === 'paused'
                                ? 'text-yellow-600 dark:text-yellow-400'
                                : 'text-gray-600 dark:text-gray-400'
                          }`}>
                            {t(`dashboard.status.${timeMetrics.status}`)}
                          </p>
                        </div>
                      </div>
                    </div>
                    
                    <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                      <div className="flex items-center">
                        <div className="flex-shrink-0 bg-purple-100 dark:bg-purple-900 rounded-full p-2">
                          <span className="material-icons text-purple-600 dark:text-purple-300">coffee</span>
                        </div>
                        <div className="ml-4">
                          <h3 className="text-sm font-medium text-gray-900 dark:text-gray-100">
                            {t('dashboard.breakTime')}
                          </h3>
                          <p className="text-lg font-semibold">{timeMetrics.breakTime}</p>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </section>
              
              {/* Key Performance Metrics */}
              <section className="mt-6">
                <div className="bg-white dark:bg-gray-800 shadow rounded-lg p-4 sm:p-6">
                  <h2 className="text-lg font-medium text-gray-900 dark:text-gray-100 mb-4">
                    {t('dashboard.performanceTitle')}
                  </h2>
                  
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                    {performanceMetrics.map((metric, index) => (
                      <div key={index} className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                        <p className="text-sm text-gray-500 dark:text-gray-400">{metric.title}</p>
                        <p className="text-2xl font-bold text-gray-900 dark:text-gray-100">{metric.value}</p>
                        <div className="flex items-center mt-1">
                          <span className={`text-xs flex items-center ${
                            metric.trend === 'up' ? 'text-green-500' : 'text-red-500'
                          }`}>
                            <span className="material-icons text-xs">
                              {metric.trend === 'up' ? 'arrow_upward' : 'arrow_downward'}
                            </span>
                            {metric.change}%
                          </span>
                          <span className="text-xs text-gray-500 dark:text-gray-400 ml-2">
                            {t('dashboard.vsLastMonth')}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </section>
              
              {/* Recent Contracts & Appointments */}
              <div className="mt-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Recent Contracts */}
                <section>
                  <div className="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
                    <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
                      <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
                        {t('dashboard.recentContracts')}
                      </h3>
                      <Link href="/contracts">
                        <a className="text-sm font-medium text-primary-600 dark:text-primary-400 hover:text-primary-500">
                          {t('dashboard.viewAll')}
                        </a>
                      </Link>
                    </div>
                    
                    <div className="border-t border-gray-200 dark:border-gray-700">
                      {recentContracts.length > 0 ? (
                        <ul className="divide-y divide-gray-200 dark:divide-gray-700">
                          {recentContracts.map((contract) => (
                            <li key={contract.id}>
                              <Link href={`/contracts/${contract.id}`}>
                                <a className="block hover:bg-gray-50 dark:hover:bg-gray-700">
                                  <div className="px-4 py-4 sm:px-6">
                                    <div className="flex items-center justify-between">
                                      <div className="text-sm font-medium text-primary-600 dark:text-primary-400 truncate">
                                        {contract.contractNumber}
                                      </div>
                                      <div className="ml-2 flex-shrink-0 flex">
                                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                          contract.status === 'validated' 
                                            ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200' 
                                            : contract.status === 'pending'
                                              ? 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
                                              : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200'
                                        }`}>
                                          {t(`contract.status.${contract.status}`)}
                                        </span>
                                      </div>
                                    </div>
                                    <div className="mt-2 flex justify-between">
                                      <div className="sm:flex">
                                        <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                                          <span className="material-icons text-sm mr-1">person</span>
                                          <p>{contract.customerName}</p>
                                        </div>
                                      </div>
                                      <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                                        <span className="material-icons text-sm mr-1">event</span>
                                        <p>{format(new Date(contract.createdAt), 'PP', { locale: dateLocale })}</p>
                                      </div>
                                    </div>
                                  </div>
                                </a>
                              </Link>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <div className="px-4 py-6 text-center text-gray-500 dark:text-gray-400">
                          {t('dashboard.noContracts')}
                        </div>
                      )}
                    </div>
                  </div>
                </section>
                
                {/* Upcoming Appointments */}
                <section>
                  <div className="bg-white dark:bg-gray-800 shadow rounded-lg overflow-hidden">
                    <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
                      <h3 className="text-lg font-medium text-gray-900 dark:text-gray-100">
                        {t('dashboard.upcomingAppointments')}
                      </h3>
                      <Link href="/appointments">
                        <a className="text-sm font-medium text-primary-600 dark:text-primary-400 hover:text-primary-500">
                          {t('dashboard.viewAll')}
                        </a>
                      </Link>
                    </div>
                    
                    <div className="border-t border-gray-200 dark:border-gray-700">
                      {upcomingAppointments.length > 0 ? (
                        <ul className="divide-y divide-gray-200 dark:divide-gray-700">
                          {upcomingAppointments.map((appointment) => (
                            <li key={appointment.id}>
                              <Link href={`/appointments/${appointment.id}`}>
                                <a className="block hover:bg-gray-50 dark:hover:bg-gray-700">
                                  <div className="px-4 py-4 sm:px-6">
                                    <div className="flex items-center justify-between">
                                      <div className="text-sm font-medium text-primary-600 dark:text-primary-400 truncate">
                                        {appointment.title}
                                      </div>
                                      <div className="ml-2 flex-shrink-0 flex">
                                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                                          appointment.status === 'confirmed' 
                                            ? 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200' 
                                            : 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-200'
                                        }`}>
                                          {t(`appointment.status.${appointment.status}`)}
                                        </span>
                                      </div>
                                    </div>
                                    <div className="mt-2 flex justify-between">
                                      <div className="sm:flex">
                                        <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                                          <span className="material-icons text-sm mr-1">person</span>
                                          <p>{appointment.customerName}</p>
                                        </div>
                                      </div>
                                      <div className="flex items-center text-sm text-gray-500 dark:text-gray-400">
                                        <span className="material-icons text-sm mr-1">schedule</span>
                                        <p>{format(new Date(appointment.date), 'PPp', { locale: dateLocale })}</p>
                                      </div>
                                    </div>
                                  </div>
                                </a>
                              </Link>
                            </li>
                          ))}
                        </ul>
                      ) : (
                        <div className="px-4 py-6 text-center text-gray-500 dark:text-gray-400">
                          {t('dashboard.noAppointments')}
                        </div>
                      )}
                    </div>
                  </div>
                </section>
              </div>
              
              {/* Activity Chart */}
              <section className="mt-6">
                <div className="bg-white dark:bg-gray-800 shadow rounded-lg p-4 sm:p-6">
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-medium text-gray-900 dark:text-gray-100">
                      {t('dashboard.monthlyActivity')}
                    </h2>
                    <div>
                      <select className="mt-1 block pl-3 pr-10 py-2 text-base border-gray-300 dark:border-gray-600 focus:outline-none focus:ring-primary-500 focus:border-primary-500 sm:text-sm rounded-md bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100">
                        <option>{format(new Date(), 'MMMM yyyy', { locale: dateLocale })}</option>
                        <option>{format(new Date(new Date().setMonth(new Date().getMonth() - 1)), 'MMMM yyyy', { locale: dateLocale })}</option>
                        <option>{format(new Date(new Date().setMonth(new Date().getMonth() - 2)), 'MMMM yyyy', { locale: dateLocale })}</option>
                      </select>
                    </div>
                  </div>
                  
                  <div className="h-64 bg-gray-50 dark:bg-gray-700 rounded-lg">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart
                        data={activityData}
                        margin={{
                          top: 20,
                          right: 30,
                          left: 0,
                          bottom: 5,
                        }}
                      >
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="name" />
                        <YAxis />
                        <Tooltip />
                        <Legend />
                        <Line type="monotone" dataKey="contracts" stroke="#3b82f6" name={t('dashboard.chart.contracts')} />
                        <Line type="monotone" dataKey="validated" stroke="#10b981" name={t('dashboard.chart.validated')} />
                        <Line type="monotone" dataKey="converted" stroke="#f59e0b" name={t('dashboard.chart.converted')} />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </div>
              </section>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default DashboardPage;
