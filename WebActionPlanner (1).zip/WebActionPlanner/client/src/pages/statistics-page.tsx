import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { format, startOfMonth, endOfMonth, subMonths, eachDayOfInterval } from "date-fns";
import { fr, it } from "date-fns/locale";
import { useAuth } from "@/hooks/use-auth";
import AppLayout from "@/components/layout/app-layout";

import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart,
  LineChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { Loader2, TrendingUp, TrendingDown, FileText, Clock, Calendar, Filter } from "lucide-react";

const CHART_COLORS = ["#3b82f6", "#10b981", "#f59e0b", "#ef4444", "#8b5cf6"];

const StatisticsPage = () => {
  const { t, i18n } = useTranslation();
  const { user } = useAuth();
  const [selectedView, setSelectedView] = useState("personal");
  const [selectedPeriod, setSelectedPeriod] = useState("month");
  const [selectedMonth, setSelectedMonth] = useState(new Date());
  
  // Date locale
  const dateLocale = i18n.language === 'fr' ? fr : it;

  // Fetch user statistics (mock data in this implementation)
  const { data: userStats, isLoading: isLoadingUserStats } = useQuery({
    queryKey: ["/api/statistics/user"],
    refetchInterval: false,
  });

  // Format month for display
  const formattedMonth = format(selectedMonth, "MMMM yyyy", { locale: dateLocale });

  // Move to previous month
  const handlePreviousMonth = () => {
    setSelectedMonth(subMonths(selectedMonth, 1));
  };

  // Move to next month
  const handleNextMonth = () => {
    const nextMonth = new Date(selectedMonth);
    nextMonth.setMonth(nextMonth.getMonth() + 1);
    
    // Don't allow selecting future months
    if (nextMonth <= new Date()) {
      setSelectedMonth(nextMonth);
    }
  };

  // Reset to current month
  const handleCurrentMonth = () => {
    setSelectedMonth(new Date());
  };

  // Get dates of current month
  const daysInMonth = eachDayOfInterval({
    start: startOfMonth(selectedMonth),
    end: endOfMonth(selectedMonth),
  });

  // Generate mock data for charts
  // In a real app, these would come from API calls
  const generateMockData = () => {
    // Monthly trends data
    const monthlyData = daysInMonth.map((day) => {
      const dayOfMonth = day.getDate();
      // Generate different patterns for contracts based on day of month
      const contractsCreated = Math.max(0, Math.floor(4 + Math.sin(dayOfMonth * 0.5) * 3));
      const contractsValidated = Math.max(0, Math.floor(contractsCreated * 0.7 + Math.sin(dayOfMonth * 0.3) * 2));
      
      return {
        date: format(day, "dd/MM"),
        contractsCreated,
        contractsValidated,
        appointmentsScheduled: Math.max(0, Math.floor(2 + Math.cos(dayOfMonth * 0.6) * 2)),
        hoursWorked: Math.max(0, Math.min(10, 7.5 + Math.sin(dayOfMonth * 0.2) * 1.5)),
      };
    });

    // Contract status breakdown
    const contractStatusData = [
      { name: t("statistics.draft"), value: 12 },
      { name: t("statistics.pending"), value: 8 },
      { name: t("statistics.validated"), value: 30 },
      { name: t("statistics.rejected"), value: 5 },
      { name: t("statistics.completed"), value: 25 },
    ];

    // Performance comparison
    const performanceComparisonData = [
      {
        name: t("statistics.contracts"),
        [t("statistics.you")]: 42,
        [t("statistics.teamAverage")]: 35,
      },
      {
        name: t("statistics.validated"),
        [t("statistics.you")]: 30,
        [t("statistics.teamAverage")]: 24,
      },
      {
        name: t("statistics.appointments"),
        [t("statistics.you")]: 15,
        [t("statistics.teamAverage")]: 12,
      },
      {
        name: t("statistics.hoursWorked"),
        [t("statistics.you")]: 160,
        [t("statistics.teamAverage")]: 152,
      },
      {
        name: t("statistics.conversionRate"),
        [t("statistics.you")]: 71,
        [t("statistics.teamAverage")]: 68,
      },
    ];

    // Team performance data
    const teamPerformanceData = [
      { name: "Alice", contracts: 38, validated: 28, conversion: 74 },
      { name: "Bob", contracts: 45, validated: 32, conversion: 71 },
      { name: "Charlie", contracts: 30, validated: 25, conversion: 83 },
      { name: "David", contracts: 52, validated: 35, conversion: 67 },
      { name: "Eve", contracts: 42, validated: 30, conversion: 71 },
      { name: "Frank", contracts: 35, validated: 22, conversion: 63 },
      { name: user.firstName, contracts: 42, validated: 30, conversion: 71 },
    ];

    return {
      monthlyData,
      contractStatusData,
      performanceComparisonData,
      teamPerformanceData,
    };
  };

  const {
    monthlyData,
    contractStatusData,
    performanceComparisonData,
    teamPerformanceData,
  } = generateMockData();

  // Performance metrics
  const performanceMetrics = [
    {
      title: t("dashboard.contractsCreated"),
      value: 42,
      change: 12,
      trend: "up",
      icon: <FileText className="h-5 w-5" />,
    },
    {
      title: t("dashboard.contractsValidated"),
      value: 30,
      change: 8,
      trend: "up",
      icon: <FileText className="h-5 w-5" />,
    },
    {
      title: t("dashboard.conversionRate"),
      value: "71%",
      change: 5,
      trend: "up",
      icon: <TrendingUp className="h-5 w-5" />,
    },
    {
      title: t("dashboard.hoursWorked"),
      value: "160h",
      change: 3,
      trend: "down",
      icon: <Clock className="h-5 w-5" />,
    },
  ];

  return (
    <AppLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-6">
            <div>
              <h1 className="text-2xl font-semibold text-gray-900 dark:text-gray-100">
                {t("statistics.title")}
              </h1>
              <p className="text-gray-500 dark:text-gray-400 mt-1">
                {t("statistics.description")}
              </p>
            </div>
            
            <div className="mt-4 md:mt-0 flex items-center space-x-2">
              <Select
                value={selectedView}
                onValueChange={setSelectedView}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder={t("statistics.selectView")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="personal">{t("statistics.personalStats")}</SelectItem>
                  {(user.role === "supervisor" || user.role === "admin") && (
                    <SelectItem value="team">{t("statistics.teamStats")}</SelectItem>
                  )}
                  {user.role === "admin" && (
                    <SelectItem value="company">{t("statistics.companyStats")}</SelectItem>
                  )}
                </SelectContent>
              </Select>
              
              <Select
                value={selectedPeriod}
                onValueChange={setSelectedPeriod}
              >
                <SelectTrigger className="w-[180px]">
                  <SelectValue placeholder={t("statistics.selectPeriod")} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="day">{t("statistics.day")}</SelectItem>
                  <SelectItem value="week">{t("statistics.week")}</SelectItem>
                  <SelectItem value="month">{t("statistics.month")}</SelectItem>
                  <SelectItem value="year">{t("statistics.year")}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          
          {isLoadingUserStats ? (
            <div className="flex justify-center items-center h-64">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
            </div>
          ) : (
            <>
              {/* Time Period Navigation */}
              <div className="bg-white dark:bg-gray-800 p-4 rounded-lg shadow mb-6 flex items-center justify-between">
                <Button variant="outline" onClick={handlePreviousMonth}>
                  {t("statistics.previous")}
                </Button>
                <div className="flex items-center">
                  <Calendar className="h-5 w-5 mr-2 text-gray-700 dark:text-gray-300" />
                  <span className="text-lg font-medium">{formattedMonth}</span>
                </div>
                <div className="space-x-2">
                  <Button variant="outline" onClick={handleCurrentMonth}>
                    {t("statistics.current")}
                  </Button>
                  <Button variant="outline" onClick={handleNextMonth} disabled={selectedMonth.getMonth() === new Date().getMonth() && selectedMonth.getFullYear() === new Date().getFullYear()}>
                    {t("statistics.next")}
                  </Button>
                </div>
              </div>
              
              {/* Key Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-6">
                {performanceMetrics.map((metric, index) => (
                  <Card key={index}>
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between">
                        <div className="bg-primary-50 dark:bg-primary-900 p-2 rounded-full">
                          <div className="text-primary-600 dark:text-primary-300">
                            {metric.icon}
                          </div>
                        </div>
                        <div className={`flex items-center ${
                          metric.trend === "up"
                            ? "text-green-500 dark:text-green-400"
                            : "text-red-500 dark:text-red-400"
                        }`}>
                          {metric.trend === "up" ? (
                            <TrendingUp className="h-4 w-4 mr-1" />
                          ) : (
                            <TrendingDown className="h-4 w-4 mr-1" />
                          )}
                          {metric.change}%
                        </div>
                      </div>
                      <h3 className="mt-4 text-lg font-medium text-gray-700 dark:text-gray-300">
                        {metric.title}
                      </h3>
                      <p className="text-2xl font-bold mt-1">{metric.value}</p>
                    </CardContent>
                  </Card>
                ))}
              </div>
              
              {/* Charts */}
              <div className="space-y-6">
                {/* Monthly Trends */}
                <Card>
                  <CardHeader>
                    <CardTitle>{t("statistics.monthlyTrends")}</CardTitle>
                    <CardDescription>
                      {t("statistics.monthlyTrendsDescription")}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <Tabs defaultValue="contracts">
                      <TabsList className="mb-4">
                        <TabsTrigger value="contracts">{t("statistics.contracts")}</TabsTrigger>
                        <TabsTrigger value="appointments">{t("statistics.appointments")}</TabsTrigger>
                        <TabsTrigger value="hours">{t("statistics.hoursWorked")}</TabsTrigger>
                      </TabsList>
                      
                      <TabsContent value="contracts">
                        <div className="h-80">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart
                              data={monthlyData}
                              margin={{
                                top: 20,
                                right: 30,
                                left: 0,
                                bottom: 0,
                              }}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="date" />
                              <YAxis />
                              <Tooltip />
                              <Legend />
                              <Line
                                type="monotone"
                                dataKey="contractsCreated"
                                name={t("statistics.contractsCreated")}
                                stroke="#3b82f6"
                                activeDot={{ r: 8 }}
                              />
                              <Line
                                type="monotone"
                                dataKey="contractsValidated"
                                name={t("statistics.contractsValidated")}
                                stroke="#10b981"
                              />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </TabsContent>
                      
                      <TabsContent value="appointments">
                        <div className="h-80">
                          <ResponsiveContainer width="100%" height="100%">
                            <BarChart
                              data={monthlyData}
                              margin={{
                                top: 20,
                                right: 30,
                                left: 0,
                                bottom: 0,
                              }}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="date" />
                              <YAxis />
                              <Tooltip />
                              <Legend />
                              <Bar
                                dataKey="appointmentsScheduled"
                                name={t("statistics.appointmentsScheduled")}
                                fill="#8b5cf6"
                              />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      </TabsContent>
                      
                      <TabsContent value="hours">
                        <div className="h-80">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart
                              data={monthlyData}
                              margin={{
                                top: 20,
                                right: 30,
                                left: 0,
                                bottom: 0,
                              }}
                            >
                              <CartesianGrid strokeDasharray="3 3" />
                              <XAxis dataKey="date" />
                              <YAxis />
                              <Tooltip />
                              <Legend />
                              <Line
                                type="monotone"
                                dataKey="hoursWorked"
                                name={t("statistics.hoursWorked")}
                                stroke="#f59e0b"
                                activeDot={{ r: 8 }}
                              />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </TabsContent>
                    </Tabs>
                  </CardContent>
                </Card>
                
                {/* Contract Status Breakdown */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle>{t("statistics.contractStatusBreakdown")}</CardTitle>
                      <CardDescription>
                        {t("statistics.contractStatusDescription")}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <PieChart>
                            <Pie
                              data={contractStatusData}
                              cx="50%"
                              cy="50%"
                              labelLine={true}
                              outerRadius={80}
                              fill="#8884d8"
                              dataKey="value"
                              nameKey="name"
                              label={({ name, value, percent }) => 
                                `${name}: ${value} (${(percent * 100).toFixed(0)}%)`
                              }
                            >
                              {contractStatusData.map((entry, index) => (
                                <Cell
                                  key={`cell-${index}`}
                                  fill={CHART_COLORS[index % CHART_COLORS.length]}
                                />
                              ))}
                            </Pie>
                            <Tooltip />
                          </PieChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                  
                  {/* Performance Comparison */}
                  <Card>
                    <CardHeader>
                      <CardTitle>{t("statistics.performanceComparison")}</CardTitle>
                      <CardDescription>
                        {t("statistics.performanceComparisonDescription")}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-64">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={performanceComparisonData}
                            margin={{
                              top: 20,
                              right: 30,
                              left: 0,
                              bottom: 0,
                            }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Bar
                              dataKey={t("statistics.you")}
                              fill="#3b82f6"
                            />
                            <Bar
                              dataKey={t("statistics.teamAverage")}
                              fill="#10b981"
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                </div>
                
                {/* Team Performance (only visible for supervisors and admins) */}
                {(selectedView === "team" || selectedView === "company") && 
                 (user.role === "supervisor" || user.role === "admin") && (
                  <Card>
                    <CardHeader>
                      <CardTitle>{t("statistics.teamPerformance")}</CardTitle>
                      <CardDescription>
                        {t("statistics.teamPerformanceDescription")}
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="h-80">
                        <ResponsiveContainer width="100%" height="100%">
                          <BarChart
                            data={teamPerformanceData}
                            margin={{
                              top: 20,
                              right: 30,
                              left: 0,
                              bottom: 0,
                            }}
                          >
                            <CartesianGrid strokeDasharray="3 3" />
                            <XAxis dataKey="name" />
                            <YAxis />
                            <Tooltip />
                            <Legend />
                            <Bar
                              dataKey="contracts"
                              name={t("statistics.contracts")}
                              fill="#3b82f6"
                            />
                            <Bar
                              dataKey="validated"
                              name={t("statistics.validated")}
                              fill="#10b981"
                            />
                            <Bar
                              dataKey="conversion"
                              name={t("statistics.conversionRate")}
                              fill="#f59e0b"
                            />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </AppLayout>
  );
};

export default StatisticsPage;
