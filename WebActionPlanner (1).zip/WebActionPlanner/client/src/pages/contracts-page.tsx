import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useQuery } from "@tanstack/react-query";
import { format } from "date-fns";
import { fr, it } from "date-fns/locale";
import { useAuth } from "@/hooks/use-auth";
import { Link } from "wouter";
import { Contract } from "@shared/schema";
import AppLayout from "@/components/layout/app-layout";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink,
  PaginationNext,
  PaginationPrevious,
} from "@/components/ui/pagination";
import { Input } from "@/components/ui/input";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { 
  MoreHorizontal, 
  Plus, 
  FileEdit, 
  FileText,
  Trash2, 
  ChevronUp, 
  ChevronDown,
  Filter,
  Search,
  Loader2
} from "lucide-react";

const ContractsPage = () => {
  const { t, i18n } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState<string | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [sortField, setSortField] = useState<string>("createdAt");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  const itemsPerPage = 10;

  // Fetch contracts
  const { data: contracts, isLoading, isError } = useQuery<Contract[]>({
    queryKey: ["/api/contracts"],
  });

  const dateLocale = i18n.language === 'fr' ? fr : it;

  // Handle status change
  const handleStatusChange = async (contractId: number, newStatus: string) => {
    try {
      await apiRequest("PUT", `/api/contracts/${contractId}/status`, { status: newStatus });
      
      queryClient.invalidateQueries({ queryKey: ["/api/contracts"] });
      toast({
        title: t("contract.statusUpdated"),
        description: t("contract.statusUpdatedDescription"),
      });
    } catch (error) {
      toast({
        title: t("contract.statusUpdateFailed"),
        description: error instanceof Error ? error.message : t("errors.unknown"),
        variant: "destructive",
      });
    }
  };

  // Filter and sort contracts
  const filteredContracts = contracts
    ? contracts.filter((contract) => {
        // Search filter
        const searchMatch =
          searchTerm === "" ||
          contract.contractNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
          contract.customerName.toLowerCase().includes(searchTerm.toLowerCase());

        // Status filter
        const statusMatch = !statusFilter || contract.status === statusFilter;

        return searchMatch && statusMatch;
      })
    : [];

  // Sort contracts
  const sortedContracts = [...filteredContracts].sort((a, b) => {
    if (sortField === "createdAt") {
      const dateA = new Date(a.createdAt).getTime();
      const dateB = new Date(b.createdAt).getTime();
      return sortDirection === "asc" ? dateA - dateB : dateB - dateA;
    } else if (sortField === "contractNumber") {
      return sortDirection === "asc"
        ? a.contractNumber.localeCompare(b.contractNumber)
        : b.contractNumber.localeCompare(a.contractNumber);
    } else if (sortField === "customerName") {
      return sortDirection === "asc"
        ? a.customerName.localeCompare(b.customerName)
        : b.customerName.localeCompare(a.customerName);
    } else if (sortField === "contractValue") {
      return sortDirection === "asc"
        ? a.contractValue - b.contractValue
        : b.contractValue - a.contractValue;
    }
    return 0;
  });

  // Pagination
  const totalPages = Math.ceil(sortedContracts.length / itemsPerPage);
  const paginatedContracts = sortedContracts.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  // Toggle sort direction or change sort field
  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("asc");
    }
  };

  // Status badge colors
  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case "draft":
        return "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300";
      case "pending":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200";
      case "validated":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200";
      case "rejected":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200";
      case "completed":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200";
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300";
    }
  };

  return (
    <AppLayout>
      <div className="py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center">
            <h1 className="text-2xl font-semibold text-gray-900 dark:text-gray-100">
              {t("contract.contracts")}
            </h1>
            <div className="flex space-x-2">
              <Link href="/contracts/detailed/new">
                <Button variant="outline">
                  <FileText className="h-4 w-4 mr-2" />
                  Nouveau contrat détaillé
                </Button>
              </Link>
              <Link href="/contracts/new">
                <Button>
                  <Plus className="h-4 w-4 mr-2" />
                  {t("contract.newContract")}
                </Button>
              </Link>
            </div>
          </div>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>{t("contract.contractsList")}</CardTitle>
              <CardDescription>
                {t("contract.contractsDescription")}
              </CardDescription>

              <div className="flex flex-col md:flex-row justify-between gap-4 mt-4">
                <div className="flex items-center gap-2 flex-1">
                  <div className="relative flex-1">
                    <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-gray-500 dark:text-gray-400" />
                    <Input
                      placeholder={t("common.search")}
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-8"
                    />
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  <Select
                    value={statusFilter || "all"}
                    onValueChange={(value) => setStatusFilter(value === "all" ? null : value)}
                  >
                    <SelectTrigger className="w-[180px]">
                      <SelectValue placeholder={t("contract.statusFilter")} />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">{t("contract.allStatuses")}</SelectItem>
                      <SelectItem value="draft">{t("contract.status.draft")}</SelectItem>
                      <SelectItem value="pending">{t("contract.status.pending")}</SelectItem>
                      <SelectItem value="validated">{t("contract.status.validated")}</SelectItem>
                      <SelectItem value="rejected">{t("contract.status.rejected")}</SelectItem>
                      <SelectItem value="completed">{t("contract.status.completed")}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </CardHeader>

            <CardContent>
              {isLoading ? (
                <div className="flex justify-center items-center p-8">
                  <Loader2 className="h-8 w-8 animate-spin text-primary" />
                </div>
              ) : isError ? (
                <div className="text-center p-4 text-red-500">
                  {t("errors.loadingFailed")}
                </div>
              ) : paginatedContracts.length === 0 ? (
                <div className="text-center p-4 text-gray-500">
                  {searchTerm || statusFilter
                    ? t("contract.noContractsFiltered")
                    : t("contract.noContracts")}
                </div>
              ) : (
                <>
                  <div className="overflow-x-auto">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead
                            className="cursor-pointer"
                            onClick={() => handleSort("contractNumber")}
                          >
                            <div className="flex items-center">
                              {t("contract.number")}
                              {sortField === "contractNumber" && (
                                <span className="ml-1">
                                  {sortDirection === "asc" ? (
                                    <ChevronUp className="h-4 w-4" />
                                  ) : (
                                    <ChevronDown className="h-4 w-4" />
                                  )}
                                </span>
                              )}
                            </div>
                          </TableHead>
                          <TableHead
                            className="cursor-pointer"
                            onClick={() => handleSort("customerName")}
                          >
                            <div className="flex items-center">
                              {t("contract.customer")}
                              {sortField === "customerName" && (
                                <span className="ml-1">
                                  {sortDirection === "asc" ? (
                                    <ChevronUp className="h-4 w-4" />
                                  ) : (
                                    <ChevronDown className="h-4 w-4" />
                                  )}
                                </span>
                              )}
                            </div>
                          </TableHead>
                          <TableHead
                            className="cursor-pointer"
                            onClick={() => handleSort("contractValue")}
                          >
                            <div className="flex items-center">
                              {t("contract.value")}
                              {sortField === "contractValue" && (
                                <span className="ml-1">
                                  {sortDirection === "asc" ? (
                                    <ChevronUp className="h-4 w-4" />
                                  ) : (
                                    <ChevronDown className="h-4 w-4" />
                                  )}
                                </span>
                              )}
                            </div>
                          </TableHead>
                          <TableHead>
                            {t("contract.status.status")}
                          </TableHead>
                          <TableHead
                            className="cursor-pointer"
                            onClick={() => handleSort("createdAt")}
                          >
                            <div className="flex items-center">
                              {t("contract.createdAt")}
                              {sortField === "createdAt" && (
                                <span className="ml-1">
                                  {sortDirection === "asc" ? (
                                    <ChevronUp className="h-4 w-4" />
                                  ) : (
                                    <ChevronDown className="h-4 w-4" />
                                  )}
                                </span>
                              )}
                            </div>
                          </TableHead>
                          <TableHead className="text-right">
                            {t("common.actions")}
                          </TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {paginatedContracts.map((contract) => (
                          <TableRow key={contract.id}>
                            <TableCell className="font-medium">
                              {contract.contractNumber}
                            </TableCell>
                            <TableCell>{contract.customerName}</TableCell>
                            <TableCell>
                              {new Intl.NumberFormat(i18n.language, {
                                style: "currency",
                                currency: "EUR",
                              }).format(contract.contractValue / 100)}
                            </TableCell>
                            <TableCell>
                              <span
                                className={`px-2 py-1 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusBadgeClass(
                                  contract.status
                                )}`}
                              >
                                {t(`contract.status.${contract.status}`)}
                              </span>
                            </TableCell>
                            <TableCell>
                              {format(new Date(contract.createdAt), "PPP", {
                                locale: dateLocale,
                              })}
                            </TableCell>
                            <TableCell className="text-right">
                              <DropdownMenu>
                                <DropdownMenuTrigger asChild>
                                  <Button variant="ghost" size="icon">
                                    <MoreHorizontal className="h-4 w-4" />
                                    <span className="sr-only">{t("common.openMenu")}</span>
                                  </Button>
                                </DropdownMenuTrigger>
                                <DropdownMenuContent align="end">
                                  <Link href={`/contracts/${contract.id}`}>
                                    <DropdownMenuItem>
                                      <FileEdit className="h-4 w-4 mr-2" />
                                      {t("common.edit")}
                                    </DropdownMenuItem>
                                  </Link>
                                  
                                  {/* Status change options based on role and current status */}
                                  {user.role === 'televendeur' && contract.status === 'draft' && (
                                    <DropdownMenuItem onSelect={() => handleStatusChange(contract.id, 'pending')}>
                                      {t("contract.submitForValidation")}
                                    </DropdownMenuItem>
                                  )}
                                  
                                  {(user.role === 'team_leader' || user.role === 'responsable_plateau' || user.role === 'manager' || user.role === 'responsable_administratif') && contract.status === 'pending' && (
                                    <>
                                      <DropdownMenuItem onSelect={() => handleStatusChange(contract.id, 'validated')}>
                                        {t("contract.validate")}
                                      </DropdownMenuItem>
                                      <DropdownMenuItem onSelect={() => handleStatusChange(contract.id, 'rejected')}>
                                        {t("contract.reject")}
                                      </DropdownMenuItem>
                                    </>
                                  )}
                                  
                                  {(user.role === 'backoffice' || user.role === 'responsable_backoffice' || user.role === 'manager') && contract.status === 'validated' && (
                                    <DropdownMenuItem onSelect={() => handleStatusChange(contract.id, 'completed')}>
                                      {t("contract.markAsCompleted")}
                                    </DropdownMenuItem>
                                  )}
                                </DropdownMenuContent>
                              </DropdownMenu>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>

                  {/* Pagination */}
                  {totalPages > 1 && (
                    <Pagination className="mt-4">
                      <PaginationContent>
                        <PaginationItem>
                          <PaginationPrevious
                            onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
                            disabled={currentPage === 1}
                          />
                        </PaginationItem>
                        
                        {[...Array(totalPages)].map((_, index) => (
                          <PaginationItem key={index}>
                            <PaginationLink
                              onClick={() => setCurrentPage(index + 1)}
                              isActive={currentPage === index + 1}
                            >
                              {index + 1}
                            </PaginationLink>
                          </PaginationItem>
                        ))}
                        
                        <PaginationItem>
                          <PaginationNext
                            onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
                            disabled={currentPage === totalPages}
                          />
                        </PaginationItem>
                      </PaginationContent>
                    </Pagination>
                  )}
                </>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </AppLayout>
  );
};

export default ContractsPage;
