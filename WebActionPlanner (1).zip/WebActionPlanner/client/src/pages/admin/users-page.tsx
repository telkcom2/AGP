import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, Check, X, Plus, Download, FileSpreadsheet, Edit, Trash2 } from "lucide-react";
import { Link } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { format } from "date-fns";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";

export default function UsersPage() {
  const { user } = useAuth();

  // Vérifier si l'utilisateur a les droits d'accès
  if (!user || !['manager', 'responsable_rh', 'responsable_administratif'].includes(user.role)) {
    return (
      <div className="container mx-auto py-10">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Accès non autorisé</AlertTitle>
          <AlertDescription>
            Vous n'avez pas les permissions nécessaires pour accéder à cette page.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  // Récupérer la liste des utilisateurs
  const { data: users, isLoading: usersLoading } = useQuery({
    queryKey: ['/api/users'],
    queryFn: () => apiRequest('GET', '/api/users').then(res => res.json())
  });

  const getRoleLabel = (role: string) => {
    const roles: Record<string, string> = {
      'televendeur': 'Télévendeur',
      'team_leader': 'Chef d\'équipe',
      'responsable_plateau': 'Responsable Plateau',
      'backoffice': 'Backoffice',
      'responsable_backoffice': 'Responsable Backoffice',
      'responsable_formation': 'Responsable Formation',
      'responsable_production': 'Responsable Production',
      'responsable_administratif': 'Responsable Administratif',
      'responsable_technique': 'Responsable Technique',
      'responsable_rh': 'Responsable RH',
      'manager': 'Manager'
    };
    return roles[role] || role;
  };

  const downloadExcelTemplate = () => {
    // Créer un lien pour télécharger un fichier texte explicatif
    const content = `Instructions pour créer un fichier d'importation d'utilisateurs:

1. Créez un nouveau fichier Excel (.xlsx)
2. Ajoutez les colonnes suivantes:
   - username (obligatoire): Nom d'utilisateur unique
   - password (optionnel): Mot de passe (default: 'password123')
   - firstName (obligatoire): Prénom
   - lastName (obligatoire): Nom de famille
   - email (obligatoire): Adresse email
   - role (obligatoire): Un des rôles suivants: televendeur, team_leader, responsable_plateau, backoffice, responsable_backoffice, responsable_formation, responsable_production, responsable_administratif, responsable_technique, responsable_rh, manager
   - language (optionnel): Langue (default: 'fr')
   - phone (optionnel): Numéro de téléphone
   - isActive (optionnel): true/false (default: true)

3. Enregistrez le fichier et importez-le via la page d'importation.
`;

    const element = document.createElement('a');
    const file = new Blob([content], { type: 'text/plain' });
    element.href = URL.createObjectURL(file);
    element.download = 'instructions_import_utilisateurs.txt';
    document.body.appendChild(element);
    element.click();
    document.body.removeChild(element);
  };

  return (
    <div className="container mx-auto py-10">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Gestion des Utilisateurs</h1>
        <div className="space-x-2">
          <Button onClick={downloadExcelTemplate} variant="outline">
            <FileSpreadsheet className="mr-2 h-4 w-4" />
            Instructions d'import
          </Button>
          <Button asChild>
            <Link href="/admin/users/import">
              <FileSpreadsheet className="mr-2 h-4 w-4" />
              Importer des utilisateurs
            </Link>
          </Button>
          <Button asChild>
            <Link href="/admin/users/create">
              <Plus className="mr-2 h-4 w-4" />
              Nouvel utilisateur
            </Link>
          </Button>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Liste des utilisateurs</CardTitle>
          <CardDescription>
            {usersLoading ? 'Chargement des utilisateurs...' : 
              users ? `${users.length} utilisateurs enregistrés` : 'Aucun utilisateur trouvé'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          {usersLoading ? (
            <div className="flex justify-center p-10">
              <div className="animate-spin h-8 w-8 border-4 border-primary border-t-transparent rounded-full"></div>
            </div>
          ) : users && users.length > 0 ? (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>ID</TableHead>
                    <TableHead>Nom d'utilisateur</TableHead>
                    <TableHead>Nom complet</TableHead>
                    <TableHead>Email</TableHead>
                    <TableHead>Rôle</TableHead>
                    <TableHead>Statut</TableHead>
                    <TableHead>Dernière connexion</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((user: any) => (
                    <TableRow key={user.id}>
                      <TableCell>{user.id}</TableCell>
                      <TableCell>{user.username}</TableCell>
                      <TableCell>{user.firstName} {user.lastName}</TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>{getRoleLabel(user.role)}</TableCell>
                      <TableCell>
                        {user.isActive ? (
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                            <Check className="mr-1 h-3 w-3" />
                            Actif
                          </span>
                        ) : (
                          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
                            <X className="mr-1 h-3 w-3" />
                            Inactif
                          </span>
                        )}
                      </TableCell>
                      <TableCell>
                        {user.lastLogin ? format(new Date(user.lastLogin), 'dd/MM/yyyy HH:mm') : 'Jamais'}
                      </TableCell>
                      <TableCell>
                        <div className="flex space-x-2">
                          <Button 
                            variant="outline" 
                            size="icon"
                            asChild
                          >
                            <Link href={`/admin/users/edit/${user.id}`}>
                              <Edit className="h-4 w-4" />
                            </Link>
                          </Button>
                        </div>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          ) : (
            <div className="text-center p-10 text-gray-500">Aucun utilisateur trouvé</div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}