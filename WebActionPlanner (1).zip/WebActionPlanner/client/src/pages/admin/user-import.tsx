import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, FileSpreadsheet, Upload, Check, Download, ArrowLeft } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import * as XLSX from 'xlsx';
import { Progress } from "@/components/ui/progress";

export default function UserImportPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [, setLocation] = useLocation();
  const [importing, setImporting] = useState(false);
  const [fileSelected, setFileSelected] = useState(false);
  const [fileName, setFileName] = useState('');
  const [users, setUsers] = useState<any[]>([]);
  const [progress, setProgress] = useState(0);
  const [results, setResults] = useState<{
    success: number;
    errors: { row: number; message: string }[];
  }>({ success: 0, errors: [] });

  // Vérifier si l'utilisateur a les droits d'accès
  if (!user || !['manager', 'responsable_rh', 'responsable_administratif'].includes(user.role)) {
    return (
      <div className="container mx-auto py-10">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Accès non autorisé</AlertTitle>
          <AlertDescription>
            Vous n'avez pas les permissions nécessaires pour accéder à cette page.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  const importMutation = useMutation({
    mutationFn: async (userData: any) => {
      const res = await apiRequest('POST', '/api/users', userData);
      return await res.json();
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur lors de l'importation",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    setFileSelected(true);

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const data = evt.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const json = XLSX.utils.sheet_to_json(worksheet);
        
        // Validate required fields
        const validUsers = json.map((row: any) => {
          return {
            username: row.username,
            password: row.password || 'password123',
            firstName: row.firstName,
            lastName: row.lastName,
            email: row.email,
            role: row.role,
            language: row.language || 'fr',
            phone: row.phone || null,
            isActive: row.isActive !== undefined ? row.isActive : true,
          };
        });
        
        setUsers(validUsers);
      } catch (error) {
        toast({
          title: "Erreur lors de la lecture du fichier",
          description: "Le format du fichier n'est pas valide.",
          variant: "destructive",
        });
      }
    };
    reader.onerror = () => {
      toast({
        title: "Erreur lors de la lecture du fichier",
        description: "Impossible de lire le fichier.",
        variant: "destructive",
      });
    };
    reader.readAsBinaryString(file);
  };

  const handleImport = async () => {
    if (users.length === 0) {
      toast({
        title: "Aucun utilisateur à importer",
        description: "Veuillez sélectionner un fichier valide.",
        variant: "destructive",
      });
      return;
    }

    setImporting(true);
    setProgress(0);
    setResults({ success: 0, errors: [] });

    const successCount = 0;
    const errors: { row: number; message: string }[] = [];

    for (let i = 0; i < users.length; i++) {
      try {
        const user = users[i];
        
        // Validate required fields
        const requiredFields = ['username', 'firstName', 'lastName', 'email', 'role'];
        const missingFields = requiredFields.filter(field => !user[field]);
        
        if (missingFields.length > 0) {
          throw new Error(`Champs obligatoires manquants: ${missingFields.join(', ')}`);
        }
        
        // Check if role is valid and map display names to technical IDs
        const roleMapping: Record<string, string> = {
          // Map French display names to technical IDs
          'Télévendeur': 'televendeur',
          'Team Leader': 'team_leader',
          'Responsable Plateau': 'responsable_plateau',
          'Backoffice': 'backoffice',
          'Responsable Backoffice': 'responsable_backoffice',
          'Responsable Formation': 'responsable_formation',
          'Responsable Production': 'responsable_production',
          'Responsable Administratif': 'responsable_administratif',
          'Responsable Technique': 'responsable_technique',
          'Responsable RH': 'responsable_rh',
          'Manager': 'manager',
          'Directeur': 'manager',
          
          // Include technical IDs as-is for direct usage
          'televendeur': 'televendeur',
          'team_leader': 'team_leader',
          'responsable_plateau': 'responsable_plateau',
          'backoffice': 'backoffice',
          'responsable_backoffice': 'responsable_backoffice',
          'responsable_formation': 'responsable_formation',
          'responsable_production': 'responsable_production',
          'responsable_administratif': 'responsable_administratif',
          'responsable_technique': 'responsable_technique',
          'responsable_rh': 'responsable_rh',
          'manager': 'manager'
        };
        
        // Get technical role ID from mapping
        const technicalRole = roleMapping[user.role];
        
        if (!technicalRole) {
          throw new Error(`Rôle '${user.role}' invalide`);
        }
        
        // Replace display role with technical role ID
        user.role = technicalRole;
        
        await importMutation.mutateAsync(user);
        setResults(prev => ({ ...prev, success: prev.success + 1 }));
      } catch (error: any) {
        setResults(prev => ({ 
          ...prev, 
          errors: [...prev.errors, { row: i + 1, message: error.message }] 
        }));
      }
      
      // Update progress
      setProgress(Math.round(((i + 1) / users.length) * 100));
    }

    setImporting(false);
    
    if (errors.length === 0) {
      toast({
        title: "Importation réussie",
        description: `${users.length} utilisateurs importés avec succès.`,
        variant: "default",
      });
    } else {
      toast({
        title: "Importation terminée avec des erreurs",
        description: `${results.success} utilisateurs importés, ${errors.length} erreurs.`,
        variant: "destructive",
      });
    }
  };

  const downloadExcelTemplate = () => {
    // Créer un fichier Excel modèle
    const template = [
      {
        username: 'utilisateur1',
        password: 'password123',
        firstName: 'Prénom',
        lastName: 'Nom',
        email: 'email@example.com',
        role: 'Télévendeur', // Vous pouvez utiliser soit le libellé (Télévendeur) soit l'identifiant technique (televendeur)
        language: 'fr',
        phone: '+33612345678',
        isActive: true
      }
    ];

    const worksheet = XLSX.utils.json_to_sheet(template);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Utilisateurs');
    
    // Ajout de la largeur des colonnes
    const cols = [
      { wch: 15 }, // username
      { wch: 15 }, // password
      { wch: 15 }, // firstName
      { wch: 15 }, // lastName
      { wch: 25 }, // email
      { wch: 20 }, // role
      { wch: 10 }, // language
      { wch: 15 }, // phone
      { wch: 10 }  // isActive
    ];
    worksheet['!cols'] = cols;
    
    XLSX.writeFile(workbook, 'modele_importation_utilisateurs.xlsx');
  };

  return (
    <div className="container mx-auto py-10">
      <div className="flex items-center gap-2 mb-6">
        <Button variant="outline" size="icon" asChild>
          <Link href="/admin/users">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <h1 className="text-2xl font-bold">Importation d'utilisateurs</h1>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Instructions</CardTitle>
            <CardDescription>
              Suivez ces étapes pour importer des utilisateurs
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <h3 className="font-medium">1. Téléchargez le modèle</h3>
              <p className="text-sm text-muted-foreground">
                Utilisez notre modèle Excel pour structurer correctement vos données.
              </p>
              <Button onClick={downloadExcelTemplate}>
                <Download className="mr-2 h-4 w-4" />
                Télécharger le modèle
              </Button>
            </div>

            <div className="space-y-2">
              <h3 className="font-medium">2. Remplissez le modèle</h3>
              <p className="text-sm text-muted-foreground">
                Assurez-vous que toutes les colonnes obligatoires sont renseignées.
              </p>
              <div className="bg-muted rounded p-3 text-xs">
                <p><strong>Champs obligatoires:</strong></p>
                <ul className="list-disc pl-5 space-y-1 mt-1">
                  <li>username: Nom d'utilisateur unique</li>
                  <li>firstName: Prénom</li>
                  <li>lastName: Nom</li>
                  <li>email: Email</li>
                  <li>role: Un des rôles suivants - soit en identifiant technique (televendeur, team_leader, etc.) soit en libellé (Télévendeur, Team Leader, etc.)</li>
                </ul>
              </div>
            </div>

            <div className="space-y-2">
              <h3 className="font-medium">3. Importez le fichier</h3>
              <p className="text-sm text-muted-foreground">
                Sélectionnez le fichier Excel complété et cliquez sur Importer.
              </p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Téléchargement</CardTitle>
            <CardDescription>
              Sélectionnez votre fichier d'importation
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept=".xlsx,.xls"
              className="hidden"
            />

            <div 
              className="border-2 border-dashed rounded-lg p-10 text-center cursor-pointer hover:bg-muted/50 transition-colors"
              onClick={() => fileInputRef.current?.click()}
            >
              <FileSpreadsheet className="h-10 w-10 mx-auto mb-4 text-muted-foreground" />
              {fileSelected ? (
                <div>
                  <p className="font-medium">{fileName}</p>
                  <p className="text-sm text-muted-foreground mt-1">
                    {users.length} utilisateurs trouvés dans le fichier
                  </p>
                </div>
              ) : (
                <div>
                  <p className="font-medium">Cliquez pour sélectionner un fichier</p>
                  <p className="text-sm text-muted-foreground mt-1">ou glissez-déposez votre fichier ici</p>
                </div>
              )}
            </div>

            <Button 
              onClick={handleImport} 
              disabled={!fileSelected || importing}
              className="w-full"
            >
              {importing ? (
                <>
                  <span className="animate-spin mr-2">⏳</span>
                  Importation en cours...
                </>
              ) : (
                <>
                  <Upload className="mr-2 h-4 w-4" />
                  Importer les utilisateurs
                </>
              )}
            </Button>

            {importing && (
              <div className="space-y-2">
                <Progress value={progress} />
                <p className="text-sm text-center">{progress}% complété</p>
              </div>
            )}

            {results.errors.length > 0 && (
              <Alert variant="destructive">
                <AlertCircle className="h-4 w-4" />
                <AlertTitle>Erreurs d'importation</AlertTitle>
                <AlertDescription>
                  <div className="mt-2 max-h-40 overflow-y-auto">
                    <ul className="list-disc pl-5 space-y-1">
                      {results.errors.map((error, index) => (
                        <li key={index}>
                          Ligne {error.row}: {error.message}
                        </li>
                      ))}
                    </ul>
                  </div>
                </AlertDescription>
              </Alert>
            )}

            {results.success > 0 && (
              <Alert>
                <Check className="h-4 w-4" />
                <AlertTitle>Importation réussie</AlertTitle>
                <AlertDescription>
                  {results.success} utilisateurs ont été importés avec succès.
                </AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}