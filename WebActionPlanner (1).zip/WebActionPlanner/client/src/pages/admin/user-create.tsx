import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle, Loader2 } from "lucide-react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Separator } from "@/components/ui/separator";
import { useMutation } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { useState } from "react";

// Schéma de validation complet pour le formulaire
const userSchema = z.object({
  // Informations personnelles
  username: z.string().min(3, "Le nom d'utilisateur doit comporter au moins 3 caractères"),
  password: z.string().min(6, "Le mot de passe doit comporter au moins 6 caractères"),
  firstName: z.string().min(1, "Le prénom est requis"),
  lastName: z.string().min(1, "Le nom est requis"),
  email: z.string().email("L'adresse email n'est pas valide"),
  phone: z.string().optional(),
  mobile: z.string().optional(),
  address: z.string().optional(),
  postalCode: z.string().optional(),
  city: z.string().optional(),
  country: z.string().default("France"),
  birthDate: z.string().optional(),
  birthPlace: z.string().optional(),
  nationality: z.string().optional(),
  identityCard: z.string().optional(),
  
  // Situation familiale
  maritalStatus: z.enum(["single", "married", "divorced", "widowed", "civil_union"]).optional(),
  children: z.number().int().min(0).default(0),
  
  // Formation et compétences
  education: z.string().optional(),
  skills: z.string().optional(),
  languages: z.string().optional(),

  // Informations professionnelles
  role: z.enum([
    "televendeur", 
    "team_leader", 
    "responsable_plateau", 
    "backoffice", 
    "responsable_backoffice", 
    "responsable_formation", 
    "responsable_production", 
    "responsable_administratif", 
    "responsable_technique", 
    "responsable_rh", 
    "manager"
  ], {
    errorMap: () => ({ message: "Rôle non valide" })
  }),
  supervisor: z.string().optional(),
  startDate: z.string().optional(),
  endDate: z.string().optional(),
  contractType: z.enum(["cdi", "cdd", "stage", "alternance", "interim"]).optional(),
  language: z.enum(["fr", "it"], {
    errorMap: () => ({ message: "Langue non valide" })
  }),
  
  // Rémunération
  baseSalary: z.string().optional(),
  bonusRate: z.string().optional(),
  commissionRate: z.string().optional(),
  paymentMethod: z.enum(["bank_transfer", "check"]).default("bank_transfer"),
  bankName: z.string().optional(),
  iban: z.string().optional(),
  bic: z.string().optional(),
  
  // Horaires et congés
  workSchedule: z.string().optional(),
  paidLeave: z.string().optional(),
  
  // Informations complémentaires
  comments: z.string().optional(),
  isActive: z.boolean().default(true)
});

type UserFormValues = z.infer<typeof userSchema>;

export default function UserCreatePage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState("personal_info");

  // Vérifier si l'utilisateur a les droits d'accès
  if (!user || !['manager', 'responsable_rh', 'responsable_administratif'].includes(user.role)) {
    return (
      <div className="container mx-auto py-10">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Accès non autorisé</AlertTitle>
          <AlertDescription>
            Vous n'avez pas les permissions nécessaires pour accéder à cette page.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  // Initialiser le formulaire avec les valeurs par défaut
  const form = useForm<UserFormValues>({
    resolver: zodResolver(userSchema),
    defaultValues: {
      // Informations personnelles
      username: "",
      password: "password123", // Mot de passe par défaut
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      mobile: "",
      address: "",
      postalCode: "",
      city: "",
      country: "France",
      birthDate: "",
      birthPlace: "",
      nationality: "",
      identityCard: "",
      
      // Situation familiale
      maritalStatus: "single",
      children: 0,
      
      // Formation et compétences
      education: "",
      skills: "",
      languages: "",

      // Informations professionnelles
      role: "televendeur", // Rôle par défaut
      supervisor: "",
      startDate: "",
      endDate: "",
      contractType: "cdi",
      language: "fr", // Langue par défaut
      
      // Rémunération
      baseSalary: "",
      bonusRate: "",
      commissionRate: "",
      paymentMethod: "bank_transfer",
      bankName: "",
      iban: "",
      bic: "",
      
      // Horaires et congés
      workSchedule: "",
      paidLeave: "",
      
      // Informations complémentaires
      comments: "",
      isActive: true
    }
  });

  // Mutation pour créer un utilisateur
  const createUserMutation = useMutation({
    mutationFn: async (userData: UserFormValues) => {
      const response = await apiRequest("POST", "/api/users", userData);
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Erreur lors de la création de l'utilisateur");
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Utilisateur créé",
        description: "L'utilisateur a été créé avec succès",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      setLocation("/admin/users");
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Fonction de soumission du formulaire
  const onSubmit = (data: UserFormValues) => {
    createUserMutation.mutate(data);
  };

  // Constantes pour les options de formulaire
  const roles = [
    { value: "televendeur", label: "Télévendeur" },
    { value: "team_leader", label: "Team Leader" },
    { value: "responsable_plateau", label: "Responsable Plateau" },
    { value: "backoffice", label: "Backoffice" },
    { value: "responsable_backoffice", label: "Responsable Backoffice" },
    { value: "responsable_formation", label: "Responsable Formation" },
    { value: "responsable_production", label: "Responsable Production" },
    { value: "responsable_administratif", label: "Responsable Administratif" },
    { value: "responsable_technique", label: "Responsable Technique" },
    { value: "responsable_rh", label: "Responsable RH" },
    { value: "manager", label: "Manager" }
  ];

  const languages = [
    { value: "fr", label: "Français" },
    { value: "it", label: "Italien" }
  ];

  const maritalStatusOptions = [
    { value: "single", label: "Célibataire" },
    { value: "married", label: "Marié(e)" },
    { value: "divorced", label: "Divorcé(e)" },
    { value: "widowed", label: "Veuf/Veuve" },
    { value: "civil_union", label: "Pacsé(e)" }
  ];

  const contractTypeOptions = [
    { value: "cdi", label: "CDI" },
    { value: "cdd", label: "CDD" },
    { value: "stage", label: "Stage" },
    { value: "alternance", label: "Alternance" },
    { value: "interim", label: "Intérim" }
  ];

  return (
    <div className="container mx-auto py-10">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Créer un nouvel utilisateur</h1>
        <Button asChild variant="outline">
          <Link href="/admin/users">
            Retour à la liste
          </Link>
        </Button>
      </div>

      <Card className="mx-auto">
        <CardHeader>
          <CardTitle>Informations utilisateur</CardTitle>
        </CardHeader>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <Tabs
              defaultValue="personal_info"
              value={activeTab}
              onValueChange={setActiveTab}
              className="w-full"
            >
              <div className="px-6">
                <TabsList className="grid grid-cols-1 md:grid-cols-6 gap-2 w-full">
                  <TabsTrigger value="personal_info">Informations personnelles</TabsTrigger>
                  <TabsTrigger value="family">Situation familiale</TabsTrigger>
                  <TabsTrigger value="professional">Informations professionnelles</TabsTrigger>
                  <TabsTrigger value="remuneration">Rémunération</TabsTrigger>
                  <TabsTrigger value="schedule">Horaires et congés</TabsTrigger>
                  <TabsTrigger value="complementary">Informations complémentaires</TabsTrigger>
                </TabsList>
              </div>

              <CardContent className="p-6">
                {/* Informations personnelles */}
                <TabsContent value="personal_info" className="space-y-6">
                  <h3 className="text-lg font-medium">Identité et coordonnées</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="firstName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Prénom*</FormLabel>
                          <FormControl>
                            <Input placeholder="Prénom" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="lastName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nom*</FormLabel>
                          <FormControl>
                            <Input placeholder="Nom" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Email*</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder="Email" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="mobile"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Mobile</FormLabel>
                          <FormControl>
                            <Input placeholder="+33612345678" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    <FormField
                      control={form.control}
                      name="address"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Adresse</FormLabel>
                          <FormControl>
                            <Input placeholder="Adresse" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="postalCode"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Code postal</FormLabel>
                          <FormControl>
                            <Input placeholder="Code postal" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="city"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Ville</FormLabel>
                          <FormControl>
                            <Input placeholder="Ville" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="country"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Pays</FormLabel>
                          <FormControl>
                            <Input placeholder="Pays" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <Separator />
                  <h3 className="text-lg font-medium">Informations de connexion</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nom d'utilisateur*</FormLabel>
                          <FormControl>
                            <Input placeholder="Nom d'utilisateur" {...field} />
                          </FormControl>
                          <FormDescription>
                            Ce nom sera utilisé pour se connecter
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Mot de passe*</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder="Mot de passe" {...field} />
                          </FormControl>
                          <FormDescription>
                            Minimum 6 caractères
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <Separator />
                  <h3 className="text-lg font-medium">Naissance et nationalité</h3>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="birthDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Date de naissance</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="birthPlace"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Lieu de naissance</FormLabel>
                          <FormControl>
                            <Input placeholder="Lieu de naissance" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="nationality"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nationalité</FormLabel>
                          <FormControl>
                            <Input placeholder="Nationalité" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    <FormField
                      control={form.control}
                      name="identityCard"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Numéro de carte d'identité</FormLabel>
                          <FormControl>
                            <Input placeholder="Numéro de carte d'identité" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="flex justify-between pt-4">
                    <Button variant="outline" asChild>
                      <Link href="/admin/users">Annuler</Link>
                    </Button>
                    <Button type="button" onClick={() => setActiveTab("family")}>
                      Suivant
                    </Button>
                  </div>
                </TabsContent>

                {/* Situation familiale */}
                <TabsContent value="family" className="space-y-6">
                  <h3 className="text-lg font-medium">Situation familiale</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="maritalStatus"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Statut marital</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Sélectionner un statut" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {maritalStatusOptions.map((status) => (
                                <SelectItem key={status.value} value={status.value}>
                                  {status.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="children"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nombre d'enfants</FormLabel>
                          <FormControl>
                            <Input 
                              type="number" 
                              placeholder="0" 
                              min="0"
                              {...field}
                              onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="flex justify-between pt-4">
                    <Button type="button" variant="outline" onClick={() => setActiveTab("personal_info")}>
                      Précédent
                    </Button>
                    <Button type="button" onClick={() => setActiveTab("professional")}>
                      Suivant
                    </Button>
                  </div>
                </TabsContent>

                {/* Informations professionnelles */}
                <TabsContent value="professional" className="space-y-6">
                  <h3 className="text-lg font-medium">Poste et rôle</h3>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="role"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Rôle*</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Sélectionner un rôle" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {roles.map((role) => (
                                <SelectItem key={role.value} value={role.value}>
                                  {role.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="supervisor"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Superviseur</FormLabel>
                          <FormControl>
                            <Input placeholder="Nom du superviseur" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="startDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Date de début</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="endDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Date de fin (si applicable)</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="contractType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Type de contrat</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Sélectionner un type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {contractTypeOptions.map((contractType) => (
                                <SelectItem key={contractType.value} value={contractType.value}>
                                  {contractType.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={form.control}
                      name="language"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Langue principale*</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Sélectionner une langue" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {languages.map((language) => (
                                <SelectItem key={language.value} value={language.value}>
                                  {language.label}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <Separator />
                  <h3 className="text-lg font-medium">Formation et compétences</h3>

                  <div className="grid grid-cols-1 gap-4">
                    <FormField
                      control={form.control}
                      name="education"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Formation</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Décrivez la formation de l'employé" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    <FormField
                      control={form.control}
                      name="skills"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Compétences</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Listez les compétences de l'employé" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    <FormField
                      control={form.control}
                      name="languages"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Langues parlées</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Français (natif), Anglais (B2), Italien (B1), etc." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="flex justify-between pt-4">
                    <Button type="button" variant="outline" onClick={() => setActiveTab("family")}>
                      Précédent
                    </Button>
                    <Button type="button" onClick={() => setActiveTab("remuneration")}>
                      Suivant
                    </Button>
                  </div>
                </TabsContent>

                {/* Rémunération */}
                <TabsContent value="remuneration" className="space-y-6">
                  <h3 className="text-lg font-medium">Salaire et bonus</h3>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="baseSalary"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Salaire de base (€)</FormLabel>
                          <FormControl>
                            <Input placeholder="ex: 2000" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="bonusRate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Taux de bonus (%)</FormLabel>
                          <FormControl>
                            <Input placeholder="ex: 10" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="commissionRate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Taux de commission (%)</FormLabel>
                          <FormControl>
                            <Input placeholder="ex: 5" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <Separator />
                  <h3 className="text-lg font-medium">Méthode de paiement</h3>

                  <div className="grid grid-cols-1 gap-4">
                    <FormField
                      control={form.control}
                      name="paymentMethod"
                      render={({ field }) => (
                        <FormItem className="space-y-3">
                          <FormLabel>Méthode de paiement</FormLabel>
                          <FormControl>
                            <RadioGroup
                              onValueChange={field.onChange}
                              defaultValue={field.value}
                              className="flex flex-col space-y-1"
                            >
                              <FormItem className="flex items-center space-x-3 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="bank_transfer" />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  Virement bancaire
                                </FormLabel>
                              </FormItem>
                              <FormItem className="flex items-center space-x-3 space-y-0">
                                <FormControl>
                                  <RadioGroupItem value="check" />
                                </FormControl>
                                <FormLabel className="font-normal">
                                  Chèque
                                </FormLabel>
                              </FormItem>
                            </RadioGroup>
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="bankName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nom de la banque</FormLabel>
                          <FormControl>
                            <Input placeholder="Nom de la banque" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="iban"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>IBAN</FormLabel>
                          <FormControl>
                            <Input placeholder="IBAN" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="bic"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>BIC</FormLabel>
                          <FormControl>
                            <Input placeholder="BIC" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="flex justify-between pt-4">
                    <Button type="button" variant="outline" onClick={() => setActiveTab("professional")}>
                      Précédent
                    </Button>
                    <Button type="button" onClick={() => setActiveTab("schedule")}>
                      Suivant
                    </Button>
                  </div>
                </TabsContent>

                {/* Horaires et congés */}
                <TabsContent value="schedule" className="space-y-6">
                  <h3 className="text-lg font-medium">Horaires et congés</h3>

                  <div className="grid grid-cols-1 gap-4">
                    <FormField
                      control={form.control}
                      name="workSchedule"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Horaires de travail</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Ex: Lundi-Vendredi 9h-17h, pause déjeuner 12h-13h" 
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="grid grid-cols-1 gap-4">
                    <FormField
                      control={form.control}
                      name="paidLeave"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Congés payés</FormLabel>
                          <FormControl>
                            <Input placeholder="Nombre de jours" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="flex justify-between pt-4">
                    <Button type="button" variant="outline" onClick={() => setActiveTab("remuneration")}>
                      Précédent
                    </Button>
                    <Button type="button" onClick={() => setActiveTab("complementary")}>
                      Suivant
                    </Button>
                  </div>
                </TabsContent>

                {/* Informations complémentaires */}
                <TabsContent value="complementary" className="space-y-6">
                  <h3 className="text-lg font-medium">Informations complémentaires</h3>

                  <div className="grid grid-cols-1 gap-4">
                    <FormField
                      control={form.control}
                      name="comments"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Observations</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Commentaires ou informations supplémentaires" 
                              className="min-h-[150px]"
                              {...field} 
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={form.control}
                    name="isActive"
                    render={({ field }) => (
                      <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                        <div className="space-y-0.5">
                          <FormLabel className="text-base">Compte actif</FormLabel>
                          <FormDescription>
                            Activer ou désactiver le compte utilisateur
                          </FormDescription>
                        </div>
                        <FormControl>
                          <Switch
                            checked={field.value}
                            onCheckedChange={field.onChange}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />

                  <div className="flex justify-between pt-4">
                    <Button type="button" variant="outline" onClick={() => setActiveTab("schedule")}>
                      Précédent
                    </Button>
                    <Button 
                      type="submit" 
                      disabled={createUserMutation.isPending}
                    >
                      {createUserMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Création en cours...
                        </>
                      ) : (
                        "Créer l'utilisateur"
                      )}
                    </Button>
                  </div>
                </TabsContent>
              </CardContent>
            </Tabs>
          </form>
        </Form>
        <CardFooter className="border-t px-6 py-4 flex justify-between">
          <Button 
            variant="outline" 
            asChild
            disabled={createUserMutation.isPending}
          >
            <Link href="/admin/users">
              Annuler
            </Link>
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}