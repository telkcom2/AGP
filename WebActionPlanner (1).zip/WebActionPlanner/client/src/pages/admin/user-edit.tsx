import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertCircle } from "lucide-react";
import { Link, useLocation, useRoute } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { useMutation, useQuery } from "@tanstack/react-query";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Loader2 } from "lucide-react";
import { useEffect } from "react";

// Schéma de validation pour le formulaire
const userEditSchema = z.object({
  username: z.string().min(3, "Le nom d'utilisateur doit comporter au moins 3 caractères"),
  firstName: z.string().min(1, "Le prénom est requis"),
  lastName: z.string().min(1, "Le nom est requis"),
  email: z.string().email("L'adresse email n'est pas valide"),
  role: z.enum([
    "televendeur", 
    "team_leader", 
    "responsable_plateau", 
    "backoffice", 
    "responsable_backoffice", 
    "responsable_formation", 
    "responsable_production", 
    "responsable_administratif", 
    "responsable_technique", 
    "responsable_rh", 
    "manager"
  ], {
    errorMap: () => ({ message: "Rôle non valide" })
  }),
  phone: z.string().optional(),
  language: z.enum(["fr", "it"], {
    errorMap: () => ({ message: "Langue non valide" })
  }),
  isActive: z.boolean().default(true),
  // Mot de passe optionnel pour la modification
  password: z.string().min(6, "Le mot de passe doit comporter au moins 6 caractères").optional(),
});

type UserEditFormValues = z.infer<typeof userEditSchema>;

export default function UserEditPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [, setLocation] = useLocation();
  const [match, params] = useRoute<{ id: string }>("/admin/users/edit/:id");
  
  // Initialiser le formulaire
  const form = useForm<UserEditFormValues>({
    resolver: zodResolver(userEditSchema),
    defaultValues: {
      username: "",
      firstName: "",
      lastName: "",
      email: "",
      role: "televendeur",
      phone: "",
      language: "fr",
      isActive: true,
      password: "",
    }
  });

  // Vérifier si l'utilisateur a les droits d'accès
  if (!user || !['manager', 'responsable_rh', 'responsable_administratif'].includes(user.role)) {
    return (
      <div className="container mx-auto py-10">
        <Alert variant="destructive">
          <AlertCircle className="h-4 w-4" />
          <AlertTitle>Accès non autorisé</AlertTitle>
          <AlertDescription>
            Vous n'avez pas les permissions nécessaires pour accéder à cette page.
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  // Récupérer les données de l'utilisateur
  const userId = params?.id ? parseInt(params.id) : 0;
  
  const { data: userData, isLoading } = useQuery({
    queryKey: [`/api/users/${userId}`],
    queryFn: async () => {
      try {
        const response = await apiRequest("GET", `/api/users/${userId}`);
        if (!response.ok) {
          const errorData = await response.json();
          throw new Error(errorData.message || "Erreur lors de la récupération des données utilisateur");
        }
        return response.json();
      } catch (error) {
        toast({
          title: "Erreur",
          description: `Impossible de récupérer les données de l'utilisateur: ${(error as Error).message}`,
          variant: "destructive",
        });
        setLocation("/admin/users");
        throw error;
      }
    },
    enabled: !!userId
  });

  // Mettre à jour le formulaire lorsque les données sont chargées
  useEffect(() => {
    if (userData) {
      form.reset({
        username: userData.username,
        firstName: userData.firstName,
        lastName: userData.lastName,
        email: userData.email,
        role: userData.role,
        phone: userData.phone || "",
        language: userData.language,
        isActive: userData.isActive,
        password: "", // On ne récupère pas le mot de passe existant
      });
    }
  }, [userData, form]);

  // Mutation pour mettre à jour un utilisateur
  const updateUserMutation = useMutation({
    mutationFn: async (userData: UserEditFormValues) => {
      // Ne pas envoyer le mot de passe s'il est vide
      const dataToSend = { ...userData };
      if (!dataToSend.password) {
        delete dataToSend.password;
      }
      
      const response = await apiRequest("PUT", `/api/users/${userId}`, dataToSend);
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Erreur lors de la mise à jour de l'utilisateur");
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Utilisateur mis à jour",
        description: "L'utilisateur a été mis à jour avec succès",
        variant: "default",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/users'] });
      setLocation("/admin/users");
    },
    onError: (error: Error) => {
      toast({
        title: "Erreur",
        description: error.message,
        variant: "destructive",
      });
    }
  });

  // Fonction de soumission du formulaire
  const onSubmit = (data: UserEditFormValues) => {
    updateUserMutation.mutate(data);
  };

  // Liste des rôles disponibles pour le select
  const roles = [
    { value: "televendeur", label: "Télévendeur" },
    { value: "team_leader", label: "Team Leader" },
    { value: "responsable_plateau", label: "Responsable Plateau" },
    { value: "backoffice", label: "Backoffice" },
    { value: "responsable_backoffice", label: "Responsable Backoffice" },
    { value: "responsable_formation", label: "Responsable Formation" },
    { value: "responsable_production", label: "Responsable Production" },
    { value: "responsable_administratif", label: "Responsable Administratif" },
    { value: "responsable_technique", label: "Responsable Technique" },
    { value: "responsable_rh", label: "Responsable RH" },
    { value: "manager", label: "Manager" }
  ];

  // Liste des langues disponibles pour le select
  const languages = [
    { value: "fr", label: "Français" },
    { value: "it", label: "Italien" }
  ];

  if (isLoading) {
    return (
      <div className="container mx-auto py-10 flex justify-center items-center">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="container mx-auto py-10">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Modifier l'utilisateur</h1>
        <Button asChild variant="outline">
          <Link href="/admin/users">
            Retour à la liste
          </Link>
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Informations de l'utilisateur</CardTitle>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="username"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nom d'utilisateur*</FormLabel>
                      <FormControl>
                        <Input placeholder="nom.prenom" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="password"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Mot de passe (laisser vide pour conserver l'actuel)</FormLabel>
                      <FormControl>
                        <Input type="password" placeholder="••••••••" {...field} />
                      </FormControl>
                      <FormDescription>
                        Laissez vide pour conserver le mot de passe actuel
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="firstName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Prénom*</FormLabel>
                      <FormControl>
                        <Input placeholder="Prénom" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="lastName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nom*</FormLabel>
                      <FormControl>
                        <Input placeholder="Nom" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="email"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Email*</FormLabel>
                      <FormControl>
                        <Input type="email" placeholder="email@exemple.com" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="phone"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Téléphone</FormLabel>
                      <FormControl>
                        <Input placeholder="+33612345678" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="role"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Rôle*</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Sélectionnez un rôle" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {roles.map(role => (
                            <SelectItem key={role.value} value={role.value}>
                              {role.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="language"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Langue*</FormLabel>
                      <Select 
                        onValueChange={field.onChange} 
                        defaultValue={field.value}
                        value={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Sélectionnez une langue" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {languages.map(language => (
                            <SelectItem key={language.value} value={language.value}>
                              {language.label}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="isActive"
                  render={({ field }) => (
                    <FormItem className="flex flex-row items-center justify-between rounded-lg border p-4">
                      <div className="space-y-0.5">
                        <FormLabel className="text-base">Compte actif</FormLabel>
                        <FormDescription>
                          Désactivez pour empêcher l'utilisateur de se connecter
                        </FormDescription>
                      </div>
                      <FormControl>
                        <Switch
                          checked={field.value}
                          onCheckedChange={field.onChange}
                        />
                      </FormControl>
                    </FormItem>
                  )}
                />
              </div>

              <CardFooter className="flex justify-between px-0">
                <Button variant="outline" asChild>
                  <Link href="/admin/users">
                    Annuler
                  </Link>
                </Button>
                <Button 
                  type="submit" 
                  disabled={updateUserMutation.isPending}
                  className="ml-auto"
                >
                  {updateUserMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Mise à jour...
                    </>
                  ) : (
                    'Enregistrer les modifications'
                  )}
                </Button>
              </CardFooter>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}