import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import {
  LayoutDashboard,
  FileText,
  Calendar,
  Clock,
  BarChart2,
  Users,
  LogOut,
  Menu,
  X,
} from "lucide-react";
import { useState } from "react";
import { useAuth } from "@/hooks/use-auth";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { cn } from "@/lib/utils";
import { useIsMobile } from "@/hooks/use-mobile";

export function MainNav() {
  const [location] = useLocation();
  const { user, logoutMutation } = useAuth();
  const isMobile = useIsMobile();
  const [open, setOpen] = useState(false);

  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const isAdmin = user?.role === 'manager' || user?.role === 'responsable_rh' || user?.role === 'responsable_administratif';

  const navItems = [
    {
      label: "Tableau de bord",
      href: "/",
      icon: <LayoutDashboard className="h-5 w-5 mr-2" />,
      roles: ['televendeur', 'team_leader', 'responsable_plateau', 'backoffice', 'responsable_backoffice', 'responsable_formation', 'responsable_production', 'responsable_administratif', 'responsable_technique', 'responsable_rh', 'manager'],
    },
    {
      label: "Contrats",
      href: "/contracts",
      icon: <FileText className="h-5 w-5 mr-2" />,
      roles: ['televendeur', 'team_leader', 'responsable_plateau', 'backoffice', 'responsable_backoffice', 'responsable_production', 'manager'],
    },
    {
      label: "Rendez-vous",
      href: "/appointments",
      icon: <Calendar className="h-5 w-5 mr-2" />,
      roles: ['televendeur', 'team_leader', 'responsable_plateau', 'responsable_production', 'manager'],
    },
    {
      label: "Suivi du temps",
      href: "/time-tracking",
      icon: <Clock className="h-5 w-5 mr-2" />,
      roles: ['televendeur', 'team_leader', 'responsable_plateau', 'backoffice', 'responsable_backoffice', 'responsable_formation', 'responsable_production', 'responsable_administratif', 'responsable_technique', 'responsable_rh', 'manager'],
    },
    {
      label: "Statistiques",
      href: "/statistics",
      icon: <BarChart2 className="h-5 w-5 mr-2" />,
      roles: ['team_leader', 'responsable_plateau', 'responsable_backoffice', 'responsable_formation', 'responsable_production', 'responsable_administratif', 'responsable_technique', 'responsable_rh', 'manager'],
    },
    {
      label: "Utilisateurs",
      href: "/admin/users",
      icon: <Users className="h-5 w-5 mr-2" />,
      roles: ['responsable_rh', 'responsable_administratif', 'manager'],
    },
  ];

  // Filtrer les éléments de navigation en fonction du rôle de l'utilisateur
  const filteredNavItems = navItems.filter(item => user && item.roles.includes(user.role));

  const NavLinks = () => (
    <>
      {filteredNavItems.map((item) => (
        <Button
          key={item.href}
          variant={location === item.href ? "default" : "ghost"}
          className={cn(
            "w-full justify-start text-base font-normal",
            location === item.href && "font-medium"
          )}
          asChild
          onClick={() => isMobile && setOpen(false)}
        >
          <Link href={item.href}>
            {item.icon}
            {item.label}
          </Link>
        </Button>
      ))}
      <Button
        variant="ghost"
        className="w-full justify-start text-base font-normal text-destructive mt-auto"
        onClick={() => {
          handleLogout();
          if (isMobile) setOpen(false);
        }}
      >
        <LogOut className="h-5 w-5 mr-2" />
        Déconnexion
      </Button>
    </>
  );

  return (
    <>
      {isMobile ? (
        <div className="flex items-center justify-between p-4 border-b">
          <Link href="/" className="flex items-center space-x-2">
            <img 
              src="/assets/tn-ecco-power-logo.jpeg" 
              alt="TN ECCO POWER" 
              className="h-8"
            />
            <span className="font-bold text-xl">AGP v1.0</span>
          </Link>
          <Sheet open={open} onOpenChange={setOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon">
                {open ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="flex flex-col p-4">
              <div className="flex flex-col space-y-1 mt-4 flex-1">
                <NavLinks />
              </div>
            </SheetContent>
          </Sheet>
        </div>
      ) : (
        <div className="flex flex-col h-screen border-r p-4">
          <Link href="/" className="flex items-center space-x-2 mb-8">
            <img 
              src="/assets/tn-ecco-power-logo.jpeg" 
              alt="TN ECCO POWER" 
              className="h-10"
            />
            <span className="font-bold text-xl">AGP v1.0</span>
          </Link>
          <div className="flex flex-col space-y-1 mt-4 flex-1">
            <NavLinks />
          </div>
        </div>
      )}
    </>
  );
}