import { useAuth } from "@/hooks/use-auth";
import { useState } from "react";
import { useTranslation } from "react-i18next";
import LanguageSelector from "./language-selector";

type TopBarProps = {
  onMobileMenuToggle: () => void;
};

const TopBar = ({ onMobileMenuToggle }: TopBarProps) => {
  const { user, logoutMutation } = useAuth();
  const { t } = useTranslation();
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  
  if (!user) return null;

  // Get user initials
  const initials = `${user.firstName.charAt(0)}${user.lastName.charAt(0)}`;
  
  const handleLogout = () => {
    logoutMutation.mutate();
  };

  const toggleProfileMenu = () => {
    setShowProfileMenu(!showProfileMenu);
  };

  return (
    <header className="bg-white dark:bg-gray-800 shadow-sm z-10">
      <div className="px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex items-center justify-between">
          {/* Mobile menu button and Brand logo (only on mobile) */}
          <div className="flex items-center lg:hidden">
            <button 
              type="button" 
              className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
              onClick={onMobileMenuToggle}
            >
              <span className="material-icons">menu</span>
            </button>
            <span className="ml-3 text-lg font-semibold text-primary-600 dark:text-primary-400">ContractManager</span>
          </div>
          
          {/* Search Bar */}
          <div className="hidden md:block flex-1 px-4 max-w-md">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <span className="material-icons text-gray-400 text-sm">search</span>
              </div>
              <input 
                type="text" 
                placeholder={t('topbar.search')}
                className="block w-full pl-10 pr-3 py-2 border border-gray-300 dark:border-gray-600 rounded-md text-sm placeholder-gray-500 dark:placeholder-gray-400 bg-gray-100 dark:bg-gray-700 focus:outline-none focus:ring-1 focus:ring-primary-500 focus:border-primary-500"
              />
            </div>
          </div>
          
          {/* Right-side tools */}
          <div className="flex items-center space-x-4">
            {/* Language Selector */}
            <LanguageSelector />
            
            {/* Dark Mode Toggle (using browser preference for simplicity) */}
            <button 
              id="darkModeToggle" 
              type="button" 
              className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-200"
            >
              <span className="material-icons dark:hidden">dark_mode</span>
              <span className="material-icons hidden dark:block">light_mode</span>
            </button>
            
            {/* Profile Dropdown */}
            <div className="relative">
              <button 
                type="button" 
                className="flex items-center text-sm rounded-full focus:outline-none"
                onClick={toggleProfileMenu}
              >
                <div className="w-8 h-8 rounded-full bg-primary-500 dark:bg-primary-600 flex items-center justify-center text-white">
                  <span className="text-sm font-medium">{initials}</span>
                </div>
              </button>
              
              {/* Profile dropdown menu */}
              {showProfileMenu && (
                <div className="absolute right-0 mt-2 w-48 bg-white dark:bg-gray-800 rounded-md shadow-lg py-1 z-10">
                  <div className="px-4 py-2 text-sm text-gray-700 dark:text-gray-300 border-b border-gray-200 dark:border-gray-700">
                    <div className="font-medium">{`${user.firstName} ${user.lastName}`}</div>
                    <div className="text-xs text-gray-500 dark:text-gray-400">{user.email}</div>
                  </div>
                  <a href="#" className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                    {t('topbar.profile')}
                  </a>
                  <a href="#" className="block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700">
                    {t('topbar.settings')}
                  </a>
                  <button 
                    onClick={handleLogout}
                    className="w-full text-left block px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
                  >
                    {t('topbar.logout')}
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};

export default TopBar;
