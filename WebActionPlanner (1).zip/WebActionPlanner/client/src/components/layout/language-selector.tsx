import { useState } from "react";
import { useTranslation } from "react-i18next";

const LanguageSelector = () => {
  const { i18n, t } = useTranslation();
  const [showDropdown, setShowDropdown] = useState(false);

  const toggleDropdown = () => {
    setShowDropdown(!showDropdown);
  };

  const changeLanguage = (language: string) => {
    i18n.changeLanguage(language);
    setShowDropdown(false);
  };

  // Map language codes to their display names
  const languages = [
    { code: "fr", name: "Français (FR)" },
    { code: "it", name: "Italiano (IT)" }
  ];

  // Get current language display code
  const currentLanguageCode = i18n.language.substring(0, 2).toUpperCase();

  return (
    <div className="relative">
      <button 
        type="button" 
        className="text-sm flex items-center text-gray-700 dark:text-gray-300 hover:text-primary-500"
        onClick={toggleDropdown}
      >
        <span className="material-icons mr-1 text-sm">language</span>
        <span>{currentLanguageCode}</span>
        <span className="material-icons text-xs">arrow_drop_down</span>
      </button>
      
      {showDropdown && (
        <div className="lang-dropdown absolute right-0 mt-2 w-40 bg-white dark:bg-gray-800 rounded-md shadow-lg py-1 z-10">
          {languages.map((lang) => (
            <button 
              key={lang.code}
              onClick={() => changeLanguage(lang.code)}
              className="block w-full text-left px-4 py-2 text-sm text-gray-700 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-700"
            >
              {lang.name}
            </button>
          ))}
        </div>
      )}
    </div>
  );
};

export default LanguageSelector;
