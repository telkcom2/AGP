import { useAuth } from "@/hooks/use-auth";
import { Link, useLocation } from "wouter";
import { useTranslation } from "react-i18next";
import TimeTracker from "@/components/time-tracking/time-tracker";

type SidebarLinkProps = {
  icon: string;
  to: string;
  active?: boolean;
  children: React.ReactNode;
};

const SidebarLink = ({ icon, to, active, children }: SidebarLinkProps) => {
  const baseClasses = "flex items-center px-2 py-2 text-sm font-medium rounded-md";
  const activeClasses = "bg-primary-800 text-white";
  const inactiveClasses = "text-primary-100 hover:bg-primary-600";

  return (
    <Link href={to}>
      <div className={`${baseClasses} ${active ? activeClasses : inactiveClasses}`}>
        <span className="material-icons text-primary-200 mr-3 text-lg">{icon}</span>
        {children}
      </div>
    </Link>
  );
};

const Sidebar = () => {
  const { user } = useAuth();
  const [location] = useLocation();
  const { t } = useTranslation();

  if (!user) return null;

  const isAdmin = user.role === 'admin';
  const isSupervisor = user.role === 'supervisor';
  const isHrManager = user.role === 'hr_manager';

  // Get user initials
  const initials = `${user.firstName.charAt(0)}${user.lastName.charAt(0)}`;

  return (
    <aside className="hidden lg:flex flex-col w-64 bg-primary-700 text-white">
      {/* App Logo/Brand */}
      <div className="flex items-center justify-center h-16 border-b border-primary-800">
        <h1 className="text-xl font-semibold tracking-wider">ContractManager</h1>
      </div>
      
      {/* User Profile Summary */}
      <div className="p-4 border-b border-primary-800">
        <div className="flex items-center">
          <div className="flex-shrink-0">
            <div className="w-10 h-10 rounded-full bg-primary-600 flex items-center justify-center text-white">
              <span className="text-lg font-medium">{initials}</span>
            </div>
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium">{`${user.firstName} ${user.lastName}`}</p>
            <p className="text-xs text-primary-200">{t(`roles.${user.role}`)}</p>
          </div>
        </div>
      </div>
      
      {/* Main Navigation */}
      <nav className="flex-1 overflow-y-auto sidebar-scroll py-4">
        <div className="px-2 space-y-1">
          <SidebarLink icon="dashboard" to="/" active={location === '/'}>
            {t('sidebar.dashboard')}
          </SidebarLink>
          
          <SidebarLink icon="description" to="/contracts" active={location.startsWith('/contracts')}>
            {t('sidebar.contracts')}
          </SidebarLink>
          
          <SidebarLink icon="event" to="/appointments" active={location.startsWith('/appointments')}>
            {t('sidebar.appointments')}
          </SidebarLink>
          
          <SidebarLink icon="schedule" to="/time-tracking" active={location.startsWith('/time-tracking')}>
            {t('sidebar.timeTracking')}
          </SidebarLink>
          
          <SidebarLink icon="bar_chart" to="/statistics" active={location.startsWith('/statistics')}>
            {t('sidebar.statistics')}
          </SidebarLink>
          
          {/* Admin section - only for admin/supervisor/HR */}
          {(isAdmin || isSupervisor || isHrManager) && (
            <>
              <div className="pt-4 pb-2">
                <h3 className="px-3 text-xs font-semibold text-primary-200 uppercase tracking-wider">
                  {t('sidebar.administration')}
                </h3>
              </div>
              
              <SidebarLink icon="people" to="/admin/users" active={location.startsWith('/admin/users')}>
                {t('sidebar.userManagement')}
              </SidebarLink>
              
              {isAdmin && (
                <SidebarLink icon="settings" to="/admin/settings" active={location.startsWith('/admin/settings')}>
                  {t('sidebar.settings')}
                </SidebarLink>
              )}
            </>
          )}
        </div>
      </nav>
      
      {/* Bottom section with time tracking */}
      <div className="p-4 border-t border-primary-800">
        <TimeTracker />
      </div>
    </aside>
  );
};

export default Sidebar;
