import { ReactNode } from "react";
import { MainNav } from "./main-nav";
import { useIsMobile } from "@/hooks/use-mobile";
import { useAuth } from "@/hooks/use-auth";

type MainLayoutProps = {
  children: ReactNode;
};

export function MainLayout({ children }: MainLayoutProps) {
  const isMobile = useIsMobile();
  const { user } = useAuth();

  // Ne pas afficher le layout si l'utilisateur n'est pas connecté
  if (!user) {
    return <>{children}</>;
  }

  return (
    <div className="flex flex-col min-h-screen md:flex-row">
      <MainNav />
      <main className="flex-1 p-4 md:p-6 overflow-auto">
        {children}
      </main>
      
      {/* Footer avec le logo de TEL-K */}
      <div className="p-2 border-t mt-auto text-center text-xs text-muted-foreground">
        <div className="flex items-center justify-center md:justify-end gap-2">
          <span>Développé par</span>
          <img 
            src="/assets/telk-logo.png" 
            alt="TEL-K TUNISIE" 
            className="h-5" 
          />
        </div>
      </div>
    </div>
  );
}