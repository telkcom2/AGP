import { useState } from "react";
import { useTranslation } from "react-i18next";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertContractSchema, Contract } from "@shared/schema";
import { useToast } from "@/hooks/use-toast";

import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Separator } from "@/components/ui/separator";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { 
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger 
} from "@/components/ui/accordion";

// Extend contract schema with all detailed fields
const detailedContractSchema = insertContractSchema
  .omit({ createdBy: true, validatedBy: true, validatedAt: true })
  .extend({
    // Informations Télévendeur
    informations: z.object({
      langue: z.string(),
      teleoperateur: z.string(),
      supervisor: z.string(),
      geocodingApiKey: z.string().optional(),
      contratSource: z.string().optional(),
    }),
    
    // Informations Client
    client: z.object({
      societe: z.string().optional(),
      nom: z.string().min(1, "Nom requis"),
      prenom: z.string().min(1, "Prénom requis"),
      dateNaissance: z.string().optional(),
      lieuNaissance: z.string().optional(),
      nationalite: z.string().optional(),
      telephone: z.string().min(1, "Téléphone requis"),
      email: z.string().email("Email invalide").min(1, "Email requis"),
      adresse: z.string().min(1, "Adresse requise"),
      codePostal: z.string().min(1, "Code postal requis"),
      ville: z.string().min(1, "Ville requise"),
      pays: z.string().min(1, "Pays requis"),
      formationEnergieConseil: z.boolean().default(false),
    }),
    
    // Informations professionnelles
    professionnel: z.object({
      statut: z.string(),
      profession: z.string(),
      dateDebutActivite: z.string().optional(),
      revenus: z.string().optional(),
      societe: z.string().optional(),
      adresseSociete: z.string().optional(),
      codePays: z.string().optional(),
      codeNAF: z.string().optional(),
      numeroSIRET: z.string().optional(),
      attestationUrssaf: z.boolean().default(false),
      attestationRcPro: z.boolean().default(false),
    }),
    
    // Rémunération
    remuneration: z.object({
      tauxHoraireBrut: z.string().min(1, "Taux horaire requis"),
      prime: z.string().optional(),
      tauxJournalierFrais: z.string().optional(),
      plafondMensuel: z.string().optional(),
      tauxCommission: z.string().optional(),
    }),
    
    // Horaires et congés
    horaires: z.object({
      dureeHebdo: z.string().min(1, "Durée hebdomadaire requise"),
      repartitionHoraire: z.array(z.object({
        jour: z.string(),
        horaireDebut: z.string().optional(),
        horaireFin: z.string().optional(),
        duree: z.string().optional(),
      })),
      conges: z.string().optional(),
    }),
    
    // Informations complémentaires
    complementaire: z.object({
      observations: z.string().optional(),
      coordonnees: z.object({
        latitude: z.string().optional(),
        longitude: z.string().optional(),
      }).optional(),
    }),
    
    // Validation par Team Leader et Back Office
    validation: z.object({
      teamLeader: z.object({
        contact: z.boolean().default(false),
        identite: z.boolean().default(false),
        adresse: z.boolean().default(false),
        email: z.boolean().default(false),
        telephone: z.boolean().default(false),
        revenu: z.boolean().default(false),
        tva: z.boolean().default(false),
        disponibilite: z.boolean().default(false),
        remuneration: z.boolean().default(false),
        frais: z.boolean().default(false),
      }),
      backOffice: z.object({
        formulaire: z.boolean().default(false),
        identite: z.boolean().default(false),
        rib: z.boolean().default(false),
        adresse: z.boolean().default(false),
        telephone: z.boolean().default(false),
        email: z.boolean().default(false),
        revenu: z.boolean().default(false),
        siret: z.boolean().default(false),
        urssaf: z.boolean().default(false),
        tva: z.boolean().default(false),
        statut: z.boolean().default(false),
        disponibilite: z.boolean().default(false),
        remuneration: z.boolean().default(false),
        frais: z.boolean().default(false),
        signatureSalarie: z.boolean().default(false),
        signatureClient: z.boolean().default(false),
      }),
      etape: z.enum(["initial", "attente_tl", "attente_bo", "valide_tl", "valide_bo", "complet"]).default("initial"),
    }),
    
    // Convertir contractValue de string à number
    contractValue: z.string().refine(
      (val) => {
        const num = parseFloat(val.replace(/,/g, "."));
        return !isNaN(num) && num > 0;
      },
      {
        message: "La valeur doit être un nombre positif",
      }
    ),
    customerId: z
      .string()
      .optional()
      .transform((val) => (val ? parseInt(val) : null)),
  });

type DetailedContractFormValues = z.infer<typeof detailedContractSchema>;

interface ContractFormDetailedProps {
  isEditMode: boolean;
  initialData?: Contract;
  onSubmit: (data: any) => void;
  isLoading: boolean;
}

export const ContractFormDetailed = ({
  isEditMode,
  initialData,
  onSubmit,
  isLoading
}: ContractFormDetailedProps) => {
  const { t } = useTranslation();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState("informations");

  // Définir les valeurs par défaut
  const defaultValues: Partial<DetailedContractFormValues> = {
    contractNumber: "",
    customerName: "",
    customerEmail: "",
    customerPhone: "",
    productType: "Contrat standard",
    contractValue: "",
    status: "draft",
    notes: "",
    informations: {
      langue: "Français",
      teleoperateur: "",
      supervisor: "",
    },
    client: {
      nom: "",
      prenom: "",
      dateNaissance: "",
      lieuNaissance: "",
      nationalite: "Française",
      telephone: "",
      email: "",
      adresse: "",
      codePostal: "",
      ville: "",
      pays: "France",
    },
    professionnel: {
      statut: "",
      profession: "",
      dateDebutActivite: "",
      revenus: "",
      societe: "",
      adresseSociete: "",
      codePays: "",
      codeNAF: "",
      numeroSIRET: "",
    },
    remuneration: {
      tauxHoraireBrut: "",
      prime: "",
      tauxJournalierFrais: "",
      plafondMensuel: "",
    },
    horaires: {
      dureeHebdo: "35",
      repartitionHoraire: [
        { jour: "Lundi", horaireDebut: "09:00", horaireFin: "17:00", duree: "7" },
        { jour: "Mardi", horaireDebut: "09:00", horaireFin: "17:00", duree: "7" },
        { jour: "Mercredi", horaireDebut: "09:00", horaireFin: "17:00", duree: "7" },
        { jour: "Jeudi", horaireDebut: "09:00", horaireFin: "17:00", duree: "7" },
        { jour: "Vendredi", horaireDebut: "09:00", horaireFin: "17:00", duree: "7" },
        { jour: "Samedi", horaireDebut: "", horaireFin: "", duree: "" },
        { jour: "Dimanche", horaireDebut: "", horaireFin: "", duree: "" },
      ],
      conges: "5 semaines",
    },
    complementaire: {
      observations: "",
    },
    validation: {
      teamLeader: {
        contact: false,
        identite: false,
        adresse: false,
        email: false,
        telephone: false,
        revenu: false,
        tva: false,
        disponibilite: false,
        remuneration: false,
        frais: false,
      },
      backOffice: {
        formulaire: false,
        identite: false,
        rib: false,
        adresse: false,
        telephone: false,
        email: false,
        revenu: false,
        siret: false,
        urssaf: false,
        tva: false,
        statut: false,
        disponibilite: false,
        remuneration: false,
        frais: false,
        signatureSalarie: false,
        signatureClient: false,
      },
      etape: "initial",
    },
  };

  // Initialiser le formulaire
  const form = useForm<DetailedContractFormValues>({
    resolver: zodResolver(detailedContractSchema),
    defaultValues,
  });

  // Utiliser fieldArray pour les horaires
  const { fields: horaireFields } = useFieldArray({
    control: form.control,
    name: "horaires.repartitionHoraire",
  });

  // Gérer la soumission du formulaire
  const handleSubmit = (data: DetailedContractFormValues) => {
    try {
      // Convertir contract value de string à number (cents)
      const contractValueCents = Math.round(parseFloat(data.contractValue.replace(/,/g, ".")) * 100);
      
      // Construire les données du contrat pour l'API
      const contractData = {
        contractNumber: isEditMode ? data.contractNumber : undefined,
        customerName: `${data.client.prenom} ${data.client.nom}`,
        customerEmail: data.client.email,
        customerPhone: data.client.telephone,
        productType: data.productType,
        contractValue: contractValueCents,
        status: data.status,
        content: {
          informations: data.informations,
          client: data.client,
          professionnel: data.professionnel,
          remuneration: data.remuneration,
          horaires: data.horaires,
          complementaire: data.complementaire,
          validation: data.validation,
        },
        notes: data.notes,
        customerId: data.customerId,
      };
      
      onSubmit(contractData);
    } catch (error) {
      console.error("Erreur lors de la préparation des données:", error);
      toast({
        title: "Erreur",
        description: "Une erreur est survenue lors de la préparation des données du contrat.",
        variant: "destructive",
      });
    }
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-6">
            <TabsTrigger value="informations">
              Informations
            </TabsTrigger>
            <TabsTrigger value="client">
              Client
            </TabsTrigger>
            <TabsTrigger value="professionnel">
              Professionnel
            </TabsTrigger>
            <TabsTrigger value="remuneration">
              Rémunération
            </TabsTrigger>
            <TabsTrigger value="horaires">
              Horaires
            </TabsTrigger>
            <TabsTrigger value="validation">
              Validation
            </TabsTrigger>
          </TabsList>

          {/* Onglet Informations générales */}
          <TabsContent value="informations" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Informations générales</CardTitle>
                <CardDescription>
                  Informations de base du contrat et du télévendeur
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Numéro de contrat (en lecture seule en mode édition) */}
                {isEditMode && (
                  <FormField
                    control={form.control}
                    name="contractNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Numéro de contrat</FormLabel>
                        <FormControl>
                          <Input {...field} disabled />
                        </FormControl>
                        <FormDescription>
                          Numéro de contrat généré automatiquement
                        </FormDescription>
                      </FormItem>
                    )}
                  />
                )}

                {/* Statut du contrat */}
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Statut du contrat</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Sélectionnez un statut" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="draft">Brouillon</SelectItem>
                          <SelectItem value="pending">En attente de validation</SelectItem>
                          <SelectItem value="validated">Validé</SelectItem>
                          <SelectItem value="completed">Complété</SelectItem>
                          <SelectItem value="rejected">Rejeté</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Type de produit */}
                <FormField
                  control={form.control}
                  name="productType"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Type de contrat</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Type de contrat" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Valeur du contrat */}
                <FormField
                  control={form.control}
                  name="contractValue"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Valeur du contrat</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                            €
                          </span>
                          <Input
                            className="pl-8"
                            placeholder="0.00"
                            {...field}
                          />
                        </div>
                      </FormControl>
                      <FormDescription>
                        Valeur totale du contrat en euros
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Separator className="my-4" />
                <h3 className="text-lg font-medium">Informations Télévendeur</h3>

                {/* Langue */}
                <FormField
                  control={form.control}
                  name="informations.langue"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Langue</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Sélectionnez une langue" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="Français">Français</SelectItem>
                          <SelectItem value="Italien">Italien</SelectItem>
                          <SelectItem value="Anglais">Anglais</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Téléopérateur */}
                <FormField
                  control={form.control}
                  name="informations.teleoperateur"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Téléopérateur</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Nom du téléopérateur" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Superviseur */}
                <FormField
                  control={form.control}
                  name="informations.supervisor"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Superviseur</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Nom du superviseur" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Notes générales */}
                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Notes</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Notes additionnelles concernant le contrat"
                          className="min-h-32"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Onglet Informations Client */}
          <TabsContent value="client" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Informations Client</CardTitle>
                <CardDescription>
                  Données personnelles et coordonnées du client
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Nom */}
                  <FormField
                    control={form.control}
                    name="client.nom"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nom</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Nom de famille" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Prénom */}
                  <FormField
                    control={form.control}
                    name="client.prenom"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Prénom</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Prénom" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Date de naissance */}
                  <FormField
                    control={form.control}
                    name="client.dateNaissance"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Date de naissance</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Lieu de naissance */}
                  <FormField
                    control={form.control}
                    name="client.lieuNaissance"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Lieu de naissance</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Ville de naissance" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Nationalité */}
                  <FormField
                    control={form.control}
                    name="client.nationalite"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Nationalité</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Nationalité" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Separator className="my-4" />
                <h3 className="text-lg font-medium">Coordonnées</h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Téléphone */}
                  <FormField
                    control={form.control}
                    name="client.telephone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Téléphone</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="+33 1 23 45 67 89" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Email */}
                  <FormField
                    control={form.control}
                    name="client.email"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Email</FormLabel>
                        <FormControl>
                          <Input type="email" {...field} placeholder="exemple@email.com" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Adresse */}
                <FormField
                  control={form.control}
                  name="client.adresse"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Adresse</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Numéro et rue" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Code postal */}
                  <FormField
                    control={form.control}
                    name="client.codePostal"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Code postal</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="75001" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Ville */}
                  <FormField
                    control={form.control}
                    name="client.ville"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Ville</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Paris" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Pays */}
                  <FormField
                    control={form.control}
                    name="client.pays"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Pays</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="France" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Onglet Informations Professionnelles */}
          <TabsContent value="professionnel" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Informations Professionnelles</CardTitle>
                <CardDescription>
                  Détails sur l'activité professionnelle du client
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Statut */}
                  <FormField
                    control={form.control}
                    name="professionnel.statut"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Statut professionnel</FormLabel>
                        <Select
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Sélectionnez un statut" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="Salarié">Salarié</SelectItem>
                            <SelectItem value="Indépendant">Indépendant</SelectItem>
                            <SelectItem value="Auto-entrepreneur">Auto-entrepreneur</SelectItem>
                            <SelectItem value="Gérant">Gérant de société</SelectItem>
                            <SelectItem value="Autre">Autre</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Profession */}
                  <FormField
                    control={form.control}
                    name="professionnel.profession"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Profession</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Intitulé du poste" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Date de début d'activité */}
                  <FormField
                    control={form.control}
                    name="professionnel.dateDebutActivite"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Date de début d'activité</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Revenus */}
                  <FormField
                    control={form.control}
                    name="professionnel.revenus"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Revenus annuels</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                              €
                            </span>
                            <Input
                              className="pl-8"
                              placeholder="0"
                              {...field}
                            />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <Separator className="my-4" />
                <h3 className="text-lg font-medium">Entreprise</h3>

                {/* Société */}
                <FormField
                  control={form.control}
                  name="professionnel.societe"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Société</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Nom de la société" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Adresse société */}
                <FormField
                  control={form.control}
                  name="professionnel.adresseSociete"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Adresse de la société</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="Adresse du siège social" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Code pays */}
                  <FormField
                    control={form.control}
                    name="professionnel.codePays"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Code pays</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="FR" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Code NAF/APE */}
                  <FormField
                    control={form.control}
                    name="professionnel.codeNAF"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Code NAF/APE</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="Ex: 6201Z" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Numéro SIRET */}
                  <FormField
                    control={form.control}
                    name="professionnel.numeroSIRET"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Numéro SIRET</FormLabel>
                        <FormControl>
                          <Input {...field} placeholder="14 chiffres" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Onglet Rémunération */}
          <TabsContent value="remuneration" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Rémunération</CardTitle>
                <CardDescription>
                  Détails sur la rémunération et les avantages
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Taux horaire brut */}
                  <FormField
                    control={form.control}
                    name="remuneration.tauxHoraireBrut"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Taux horaire brut</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                              €
                            </span>
                            <Input
                              className="pl-8"
                              placeholder="0.00"
                              {...field}
                            />
                          </div>
                        </FormControl>
                        <FormDescription>
                          Taux horaire brut en euros
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Prime */}
                  <FormField
                    control={form.control}
                    name="remuneration.prime"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Prime</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                              €
                            </span>
                            <Input
                              className="pl-8"
                              placeholder="0.00"
                              {...field}
                            />
                          </div>
                        </FormControl>
                        <FormDescription>
                          Prime éventuelle en euros
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {/* Taux journalier frais */}
                  <FormField
                    control={form.control}
                    name="remuneration.tauxJournalierFrais"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Taux journalier frais</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                              €
                            </span>
                            <Input
                              className="pl-8"
                              placeholder="0.00"
                              {...field}
                            />
                          </div>
                        </FormControl>
                        <FormDescription>
                          Taux journalier de frais en euros
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  {/* Plafond mensuel */}
                  <FormField
                    control={form.control}
                    name="remuneration.plafondMensuel"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Plafond mensuel</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <span className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                              €
                            </span>
                            <Input
                              className="pl-8"
                              placeholder="0.00"
                              {...field}
                            />
                          </div>
                        </FormControl>
                        <FormDescription>
                          Plafond mensuel de rémunération en euros
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Tableau de rémunération selon les heures */}
                <div className="mt-6">
                  <h3 className="text-lg font-medium mb-2">Barème de rémunération</h3>
                  <div className="border rounded-md p-4">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left pb-2">Tranche d'heures</th>
                          <th className="text-right pb-2">Taux</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr className="border-b">
                          <td className="py-2">De 0 à 35 heures</td>
                          <td className="text-right">100%</td>
                        </tr>
                        <tr className="border-b">
                          <td className="py-2">De 36 à 43 heures</td>
                          <td className="text-right">125%</td>
                        </tr>
                        <tr>
                          <td className="py-2">Au-delà de 43 heures</td>
                          <td className="text-right">150%</td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Onglet Horaires et congés */}
          <TabsContent value="horaires" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Horaires et congés</CardTitle>
                <CardDescription>
                  Organisation du temps de travail et congés
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {/* Durée hebdomadaire */}
                <FormField
                  control={form.control}
                  name="horaires.dureeHebdo"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Durée hebdomadaire</FormLabel>
                      <div className="flex items-center space-x-2">
                        <FormControl>
                          <Input {...field} placeholder="35" />
                        </FormControl>
                        <span>heures</span>
                      </div>
                      <FormDescription>
                        Durée de travail hebdomadaire contractuelle
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Répartition des horaires */}
                <div className="mt-6">
                  <h3 className="text-lg font-medium mb-4">Répartition des horaires</h3>
                  <div className="border rounded-md p-4">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b">
                          <th className="text-left pb-2">Jour</th>
                          <th className="text-left pb-2">Début</th>
                          <th className="text-left pb-2">Fin</th>
                          <th className="text-right pb-2">Durée</th>
                        </tr>
                      </thead>
                      <tbody>
                        {horaireFields.map((field, index) => (
                          <tr key={field.id} className="border-b last:border-0">
                            <td className="py-2">{field.jour}</td>
                            <td className="py-2 pr-2">
                              <FormField
                                control={form.control}
                                name={`horaires.repartitionHoraire.${index}.horaireDebut`}
                                render={({ field }) => (
                                  <Input type="time" {...field} value={field.value || ""} />
                                )}
                              />
                            </td>
                            <td className="py-2 pr-2">
                              <FormField
                                control={form.control}
                                name={`horaires.repartitionHoraire.${index}.horaireFin`}
                                render={({ field }) => (
                                  <Input type="time" {...field} value={field.value || ""} />
                                )}
                              />
                            </td>
                            <td className="py-2 w-24">
                              <FormField
                                control={form.control}
                                name={`horaires.repartitionHoraire.${index}.duree`}
                                render={({ field }) => (
                                  <Input {...field} value={field.value || ""} placeholder="0" className="text-right" />
                                )}
                              />
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Congés */}
                <FormField
                  control={form.control}
                  name="horaires.conges"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Congés payés</FormLabel>
                      <FormControl>
                        <Input {...field} placeholder="5 semaines par an" />
                      </FormControl>
                      <FormDescription>
                        Droits aux congés payés
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>
          </TabsContent>

          {/* Onglet Validation */}
          <TabsContent value="validation" className="space-y-4 mt-4">
            <Card>
              <CardHeader>
                <CardTitle>Validation</CardTitle>
                <CardDescription>
                  Validation par le Team Leader et le Back Office
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  {/* Partie Team Leader */}
                  <div className="space-y-6">
                    <h3 className="text-lg font-medium">Validation Team Leader</h3>
                    <div className="space-y-2 border p-4 rounded-md bg-green-50 dark:bg-green-950">
                      <FormField
                        control={form.control}
                        name="validation.teamLeader.contact"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0 ">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Contact
                              </FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="validation.teamLeader.identite"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Identité
                              </FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="validation.teamLeader.adresse"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Adresse
                              </FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="validation.teamLeader.email"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Email
                              </FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="validation.teamLeader.telephone"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Téléphone
                              </FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="validation.teamLeader.revenu"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Revenu
                              </FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="validation.teamLeader.tva"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                TVA
                              </FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="validation.teamLeader.disponibilite"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Disponibilité
                              </FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="validation.teamLeader.remuneration"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Rémunération
                              </FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="validation.teamLeader.frais"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Frais
                              </FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  {/* Partie Back Office */}
                  <div className="space-y-6">
                    <h3 className="text-lg font-medium">Validation Back Office</h3>
                    <div className="space-y-2 border p-4 rounded-md bg-blue-50 dark:bg-blue-950">
                      <FormField
                        control={form.control}
                        name="validation.backOffice.formulaire"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Formulaire complet
                              </FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="validation.backOffice.identite"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Pièce d'identité
                              </FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="validation.backOffice.rib"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                RIB
                              </FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="validation.backOffice.adresse"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Justificatif adresse
                              </FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="validation.backOffice.siret"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Extrait KBIS/SIRET
                              </FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="validation.backOffice.urssaf"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Attestation URSSAF
                              </FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="validation.backOffice.signatureSalarie"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Signature salarié
                              </FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                      <FormField
                        control={form.control}
                        name="validation.backOffice.signatureClient"
                        render={({ field }) => (
                          <FormItem className="flex flex-row items-start space-x-3 space-y-0">
                            <FormControl>
                              <Checkbox
                                checked={field.value}
                                onCheckedChange={field.onChange}
                              />
                            </FormControl>
                            <div className="space-y-1 leading-none">
                              <FormLabel>
                                Signature client
                              </FormLabel>
                            </div>
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                </div>

                {/* Étape de validation */}
                <FormField
                  control={form.control}
                  name="validation.etape"
                  render={({ field }) => (
                    <FormItem className="mt-6">
                      <FormLabel>Étape de validation</FormLabel>
                      <Select
                        onValueChange={field.onChange}
                        defaultValue={field.value}
                      >
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Sélectionnez l'étape" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="initial">Initial</SelectItem>
                          <SelectItem value="attente_tl">En attente Team Leader</SelectItem>
                          <SelectItem value="valide_tl">Validé Team Leader</SelectItem>
                          <SelectItem value="attente_bo">En attente Back Office</SelectItem>
                          <SelectItem value="valide_bo">Validé Back Office</SelectItem>
                          <SelectItem value="complet">Complet</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription>
                        Statut actuel du processus de validation
                      </FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Observations complémentaires */}
                <FormField
                  control={form.control}
                  name="complementaire.observations"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Observations complémentaires</FormLabel>
                      <FormControl>
                        <Textarea
                          placeholder="Observations ou commentaires additionnels"
                          className="min-h-32"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end space-x-4 mt-6">
          <Button
            variant="outline"
            type="button"
            onClick={() => window.history.back()}
          >
            Annuler
          </Button>
          <Button type="submit" disabled={isLoading}>
            {isLoading ? (
              <>
                <span className="mr-2 h-4 w-4 animate-spin">⚙️</span>
                Enregistrement...
              </>
            ) : (
              <>
                Enregistrer le contrat
              </>
            )}
          </Button>
        </div>
      </form>
    </Form>
  );
};