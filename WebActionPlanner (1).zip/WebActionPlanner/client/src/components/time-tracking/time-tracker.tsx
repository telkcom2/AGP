import { useState, useEffect } from "react";
import { useTranslation } from "react-i18next";
import { useAuth } from "@/hooks/use-auth";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";

const TimeTracker = () => {
  const { t } = useTranslation();
  const { user } = useAuth();
  const { toast } = useToast();
  const [currentTime, setCurrentTime] = useState<string>("00:00:00");
  const [workStatus, setWorkStatus] = useState<'idle' | 'working' | 'paused'>('idle');

  // Get today's time tracking data
  const { data: timeTrackings, isLoading } = useQuery({
    queryKey: ["/api/time/today"],
    enabled: !!user,
    refetchInterval: 60000, // Refetch every minute
  });

  // Handle check-in
  const checkInMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/time/checkin", {});
      return await res.json();
    },
    onSuccess: () => {
      setWorkStatus('working');
      queryClient.invalidateQueries({ queryKey: ["/api/time/today"] });
      toast({
        title: t('timeTracking.checkedIn'),
        description: format(new Date(), 'HH:mm:ss'),
      });
    },
    onError: (error: Error) => {
      toast({
        title: t('timeTracking.checkInFailed'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle check-out
  const checkOutMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/time/checkout", {});
      return await res.json();
    },
    onSuccess: () => {
      setWorkStatus('idle');
      queryClient.invalidateQueries({ queryKey: ["/api/time/today"] });
      toast({
        title: t('timeTracking.checkedOut'),
        description: format(new Date(), 'HH:mm:ss'),
      });
    },
    onError: (error: Error) => {
      toast({
        title: t('timeTracking.checkOutFailed'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle pause start
  const startPauseMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/time/pause/start", {});
      return await res.json();
    },
    onSuccess: () => {
      setWorkStatus('paused');
      queryClient.invalidateQueries({ queryKey: ["/api/time/today"] });
      toast({
        title: t('timeTracking.pauseStarted'),
        description: format(new Date(), 'HH:mm:ss'),
      });
    },
    onError: (error: Error) => {
      toast({
        title: t('timeTracking.pauseStartFailed'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle pause end
  const endPauseMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/time/pause/end", {});
      return await res.json();
    },
    onSuccess: () => {
      setWorkStatus('working');
      queryClient.invalidateQueries({ queryKey: ["/api/time/today"] });
      toast({
        title: t('timeTracking.pauseEnded'),
        description: format(new Date(), 'HH:mm:ss'),
      });
    },
    onError: (error: Error) => {
      toast({
        title: t('timeTracking.pauseEndFailed'),
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Determine current work status from time tracking data
  useEffect(() => {
    if (!timeTrackings || timeTrackings.length === 0) {
      setWorkStatus('idle');
      return;
    }

    // Sort by timestamp in descending order
    const sortedTimeTrackings = [...timeTrackings].sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );

    const latestEntry = sortedTimeTrackings[0];
    
    if (latestEntry.status === 'in') {
      setWorkStatus('working');
    } else if (latestEntry.status === 'pause') {
      setWorkStatus('paused');
    } else if (latestEntry.status === 'out') {
      setWorkStatus('idle');
    }
  }, [timeTrackings]);

  // Timer to update current time every second
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    // Only start timer if working or paused
    if (workStatus === 'working' || workStatus === 'paused') {
      let startTime = new Date();
      
      // Find the latest check-in time
      if (timeTrackings && timeTrackings.length > 0) {
        const checkIns = timeTrackings.filter(t => t.status === 'in');
        if (checkIns.length > 0) {
          const latestCheckIn = checkIns.sort(
            (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
          )[0];
          startTime = new Date(latestCheckIn.timestamp);
        }
      }
      
      const updateTimer = () => {
        const now = new Date();
        const diffMs = now.getTime() - startTime.getTime();
        const hours = Math.floor(diffMs / (1000 * 60 * 60));
        const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
        const seconds = Math.floor((diffMs % (1000 * 60)) / 1000);
        
        setCurrentTime(
          `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`
        );
      };
      
      updateTimer();
      interval = setInterval(updateTimer, 1000);
    } else {
      setCurrentTime("00:00:00");
    }
    
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [workStatus, timeTrackings]);

  const handleCheckIn = () => {
    checkInMutation.mutate();
  };

  const handleCheckOut = () => {
    checkOutMutation.mutate();
  };

  const handlePause = () => {
    if (workStatus === 'paused') {
      endPauseMutation.mutate();
    } else {
      startPauseMutation.mutate();
    }
  };

  return (
    <div className="bg-primary-600 dark:bg-gray-700 rounded-lg p-3">
      <div className="flex items-center justify-between mb-2">
        <h3 className="text-sm font-medium">{t('timeTracking.title')}</h3>
        <span className="text-sm font-mono">{currentTime}</span>
      </div>
      <div className="flex space-x-2">
        <button 
          className={`flex-1 py-1 px-2 rounded text-xs flex items-center justify-center
            ${workStatus === 'idle' ? 'bg-green-500 hover:bg-green-600' : 'bg-gray-500 cursor-not-allowed'}`}
          onClick={handleCheckIn}
          disabled={workStatus !== 'idle'}
        >
          <span className="material-icons text-xs mr-1">login</span>
          {t('timeTracking.checkIn')}
        </button>
        <button 
          className={`flex-1 py-1 px-2 rounded text-xs flex items-center justify-center
            ${workStatus === 'working' ? 'bg-yellow-500 hover:bg-yellow-600' : 
              workStatus === 'paused' ? 'bg-blue-500 hover:bg-blue-600' : 
              'bg-gray-500 cursor-not-allowed'}`}
          onClick={handlePause}
          disabled={workStatus === 'idle'}
        >
          <span className="material-icons text-xs mr-1">
            {workStatus === 'paused' ? 'play_arrow' : 'pause'}
          </span>
          {workStatus === 'paused' ? t('timeTracking.resume') : t('timeTracking.pause')}
        </button>
        <button 
          className={`flex-1 py-1 px-2 rounded text-xs flex items-center justify-center
            ${workStatus !== 'idle' ? 'bg-red-500 hover:bg-red-600' : 'bg-gray-500 cursor-not-allowed'}`}
          onClick={handleCheckOut}
          disabled={workStatus === 'idle'}
        >
          <span className="material-icons text-xs mr-1">logout</span>
          {t('timeTracking.checkOut')}
        </button>
      </div>
    </div>
  );
};

export default TimeTracker;
