import { useState, useEffect } from 'react';

export function useIsMobile(breakpoint: number = 768) {
  const [isMobile, setIsMobile] = useState(false);

  useEffect(() => {
    // Vérifier la taille de l'écran au chargement
    const checkScreenSize = () => {
      setIsMobile(window.innerWidth < breakpoint);
    };

    // Vérifier la taille initiale
    checkScreenSize();

    // Ajouter un écouteur pour les changements de taille
    window.addEventListener('resize', checkScreenSize);

    // Nettoyer l'écouteur lors du démontage
    return () => window.removeEventListener('resize', checkScreenSize);
  }, [breakpoint]);

  return isMobile;
}