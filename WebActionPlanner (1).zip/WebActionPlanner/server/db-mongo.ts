import mongoose from 'mongoose';

// Configuration de la connexion MongoDB
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/contract-management';

// Options de connexion
const options = {
  autoIndex: true, // Ne pas construire d'index en production
};

// Fonction pour se connecter à MongoDB
export async function connectToDatabase() {
  try {
    await mongoose.connect(MONGODB_URI, options);
    console.log('🔌 Connecté à MongoDB');
    return mongoose.connection;
  } catch (error) {
    console.error('❌ Erreur de connexion MongoDB:', error);
    process.exit(1);
  }
}

// Export pour utilisation dans d'autres fichiers
export const db = mongoose.connection;