import mongoose, { Schema, Document } from 'mongoose';

// Interfaces pour nos types de documents
export interface IUser extends Document {
  id: number;
  username: string;
  password: string;
  email: string;
  firstName: string;
  lastName: string;
  role: 'admin' | 'backoffice' | 'supervisor' | 'telesales';
  phone?: string;
  language: string;
  lastLogin?: Date;
  isActive: boolean;
  createdAt: Date;
  updatedAt: Date;
}

export interface IContract extends Document {
  id: number;
  userId: number;
  contractNumber: string;
  title: string;
  status: 'draft' | 'pending_validation' | 'validated' | 'active' | 'completed' | 'canceled';
  content: Record<string, any>;
  validatedBy?: number;
  validatedAt?: Date;
  createdAt: Date;
  updatedAt: Date;
}

export interface IAppointment extends Document {
  id: number;
  userId: number;
  title: string;
  description: string;
  startTime: Date;
  endTime: Date;
  status: 'scheduled' | 'completed' | 'canceled' | 'rescheduled';
  location?: string;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface ITimeTracking extends Document {
  id: number;
  userId: number;
  date: Date;
  startTime: Date;
  endTime?: Date;
  status: 'active' | 'paused' | 'completed';
  totalDuration?: number;
  notes?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface IPause extends Document {
  id: number;
  timeTrackingId: number;
  startTime: Date;
  endTime?: Date;
  duration?: number;
  reason?: string;
  createdAt: Date;
  updatedAt: Date;
}

export interface IStatistics extends Document {
  id: number;
  userId: number;
  date: Date;
  hoursWorked: number;
  pauseTime: number;
  contractsCreated: number;
  contractsValidated: number;
  appointmentsScheduled: number;
  createdAt: Date;
  updatedAt: Date;
}

// Auto-incrémentation pour simuler les IDs séquentiels comme dans SQL
// Utilisation du plugin mongoose-sequence dans un environnement de production
// Pour notre exemple, nous utiliserons un compteur manuel dans pre-save

// Schémas Mongoose
const UserSchema = new Schema<IUser>({
  id: { type: Number, required: true, unique: true },
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  firstName: { type: String, required: true },
  lastName: { type: String, required: true },
  role: { 
    type: String, 
    required: true, 
    enum: ['admin', 'backoffice', 'supervisor', 'telesales'] 
  },
  phone: { type: String },
  language: { type: String, required: true, default: 'fr' },
  lastLogin: { type: Date },
  isActive: { type: Boolean, required: true, default: true },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

const ContractSchema = new Schema<IContract>({
  id: { type: Number, required: true, unique: true },
  userId: { type: Number, required: true, ref: 'User' },
  contractNumber: { type: String, required: true, unique: true },
  title: { type: String, required: true },
  status: { 
    type: String, 
    required: true, 
    enum: ['draft', 'pending_validation', 'validated', 'active', 'completed', 'canceled'],
    default: 'draft'
  },
  content: { type: Schema.Types.Mixed, required: true },
  validatedBy: { type: Number, ref: 'User' },
  validatedAt: { type: Date },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

const AppointmentSchema = new Schema<IAppointment>({
  id: { type: Number, required: true, unique: true },
  userId: { type: Number, required: true, ref: 'User' },
  title: { type: String, required: true },
  description: { type: String, required: true },
  startTime: { type: Date, required: true },
  endTime: { type: Date, required: true },
  status: { 
    type: String, 
    required: true, 
    enum: ['scheduled', 'completed', 'canceled', 'rescheduled'],
    default: 'scheduled'
  },
  location: { type: String },
  notes: { type: String },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

const TimeTrackingSchema = new Schema<ITimeTracking>({
  id: { type: Number, required: true, unique: true },
  userId: { type: Number, required: true, ref: 'User' },
  date: { type: Date, required: true },
  startTime: { type: Date, required: true },
  endTime: { type: Date },
  status: { 
    type: String, 
    required: true, 
    enum: ['active', 'paused', 'completed'],
    default: 'active'
  },
  totalDuration: { type: Number },
  notes: { type: String },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

const PauseSchema = new Schema<IPause>({
  id: { type: Number, required: true, unique: true },
  timeTrackingId: { type: Number, required: true, ref: 'TimeTracking' },
  startTime: { type: Date, required: true },
  endTime: { type: Date },
  duration: { type: Number },
  reason: { type: String },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

const StatisticsSchema = new Schema<IStatistics>({
  id: { type: Number, required: true, unique: true },
  userId: { type: Number, required: true, ref: 'User' },
  date: { type: Date, required: true },
  hoursWorked: { type: Number, required: true, default: 0 },
  pauseTime: { type: Number, required: true, default: 0 },
  contractsCreated: { type: Number, required: true, default: 0 },
  contractsValidated: { type: Number, required: true, default: 0 },
  appointmentsScheduled: { type: Number, required: true, default: 0 },
  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now }
});

// Middleware pour gérer l'auto-incrémentation
async function getNextSequenceValue(modelName: string): Promise<number> {
  const Counter = mongoose.model('Counter', new Schema({
    _id: { type: String, required: true },
    seq: { type: Number, default: 0 }
  }));
  
  const counter = await Counter.findOneAndUpdate(
    { _id: modelName }, 
    { $inc: { seq: 1 } },
    { new: true, upsert: true }
  );
  
  return counter.seq;
}

// Middleware pre-save pour auto-incrémentation de l'ID
UserSchema.pre('save', async function(next) {
  if (this.isNew) {
    this.id = await getNextSequenceValue('User');
  }
  this.updatedAt = new Date();
  next();
});

ContractSchema.pre('save', async function(next) {
  if (this.isNew) {
    this.id = await getNextSequenceValue('Contract');
    // Generate contractNumber if not provided
    if (!this.contractNumber) {
      this.contractNumber = `C-${String(this.id).padStart(6, '0')}`;
    }
  }
  this.updatedAt = new Date();
  next();
});

AppointmentSchema.pre('save', async function(next) {
  if (this.isNew) {
    this.id = await getNextSequenceValue('Appointment');
  }
  this.updatedAt = new Date();
  next();
});

TimeTrackingSchema.pre('save', async function(next) {
  if (this.isNew) {
    this.id = await getNextSequenceValue('TimeTracking');
  }
  this.updatedAt = new Date();
  next();
});

PauseSchema.pre('save', async function(next) {
  if (this.isNew) {
    this.id = await getNextSequenceValue('Pause');
  }
  this.updatedAt = new Date();
  next();
});

StatisticsSchema.pre('save', async function(next) {
  if (this.isNew) {
    this.id = await getNextSequenceValue('Statistics');
  }
  this.updatedAt = new Date();
  next();
});

// Créer et exporter les modèles
export const User = mongoose.model<IUser>('User', UserSchema);
export const Contract = mongoose.model<IContract>('Contract', ContractSchema);
export const Appointment = mongoose.model<IAppointment>('Appointment', AppointmentSchema);
export const TimeTracking = mongoose.model<ITimeTracking>('TimeTracking', TimeTrackingSchema);
export const Pause = mongoose.model<IPause>('Pause', PauseSchema);
export const Statistics = mongoose.model<IStatistics>('Statistics', StatisticsSchema);