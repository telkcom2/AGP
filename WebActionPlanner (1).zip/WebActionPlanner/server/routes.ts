import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { setupAuth } from "./auth";
import { 
  insertContractSchema, 
  insertAppointmentSchema, 
  insertTimeTrackingSchema,
  insertPauseSchema,
  insertStatisticsSchema,
  insertUserSchema
} from "@shared/schema";
import { ZodError } from "zod";
import { fromZodError } from "zod-validation-error";
import * as XLSX from 'xlsx';
import multer from 'multer';
import { scrypt, randomBytes } from "crypto";
import { promisify } from "util";

// Middleware to check if user is authenticated
function isAuthenticated(req: Request, res: Response, next: Function) {
  if (req.isAuthenticated()) {
    return next();
  }
  res.status(401).json({ message: "Unauthorized" });
}

// Middleware to check if user has required role
function hasRole(roles: string[]) {
  return (req: Request, res: Response, next: Function) => {
    if (!req.isAuthenticated()) {
      return res.status(401).json({ message: "Unauthorized" });
    }
    
    if (roles.includes(req.user.role)) {
      return next();
    }
    
    res.status(403).json({ message: "Forbidden: Insufficient permissions" });
  };
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Setup authentication routes
  setupAuth(app);

  // ========= Contract Routes =========
  
  // Create a new contract
  app.post("/api/contracts", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      const contractData = insertContractSchema.parse({
        ...req.body,
        createdBy: userId
      });
      
      const contract = await storage.createContract(contractData);
      res.status(201).json(contract);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  // Get all contracts (with role-based filtering)
  app.get("/api/contracts", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      const userRole = req.user.role;
      
      let contracts;
      if (userRole === 'telemarketer') {
        // Telemarketers only see their own contracts
        contracts = await storage.listUserContracts(userId);
      } else if (['supervisor', 'backoffice', 'admin'].includes(userRole)) {
        // Supervisors, backoffice, and admins see all contracts
        contracts = await storage.listContracts();
      } else {
        // HR managers don't have access to contracts
        return res.status(403).json({ message: "Forbidden: Insufficient permissions" });
      }
      
      res.status(200).json(contracts);
    } catch (error) {
      next(error);
    }
  });

  // Get a specific contract
  app.get("/api/contracts/:id", isAuthenticated, async (req, res, next) => {
    try {
      const contractId = parseInt(req.params.id);
      const userId = req.user.id;
      const userRole = req.user.role;
      
      const contract = await storage.getContract(contractId);
      if (!contract) {
        return res.status(404).json({ message: "Contract not found" });
      }
      
      // Check permissions
      if (userRole === 'telemarketer' && contract.createdBy !== userId) {
        return res.status(403).json({ message: "Forbidden: You don't have access to this contract" });
      }
      
      res.status(200).json(contract);
    } catch (error) {
      next(error);
    }
  });

  // Update a contract
  app.put("/api/contracts/:id", isAuthenticated, async (req, res, next) => {
    try {
      const contractId = parseInt(req.params.id);
      const userId = req.user.id;
      const userRole = req.user.role;
      
      // Get the existing contract
      const existingContract = await storage.getContract(contractId);
      if (!existingContract) {
        return res.status(404).json({ message: "Contract not found" });
      }
      
      // Check permissions
      if (userRole === 'telemarketer') {
        // Telemarketers can only update their own contracts that are in draft status
        if (existingContract.createdBy !== userId) {
          return res.status(403).json({ message: "Forbidden: You don't have access to this contract" });
        }
        
        if (existingContract.status !== 'draft') {
          return res.status(403).json({ message: "Forbidden: You can only update draft contracts" });
        }
      } else if (!['supervisor', 'backoffice', 'admin'].includes(userRole)) {
        return res.status(403).json({ message: "Forbidden: Insufficient permissions" });
      }
      
      // Update the contract
      const updatedContract = await storage.updateContract(contractId, req.body);
      res.status(200).json(updatedContract);
    } catch (error) {
      next(error);
    }
  });

  // Validate a contract (supervisors only)
  app.put("/api/contracts/:id/validate", hasRole(['supervisor', 'admin']), async (req, res, next) => {
    try {
      const contractId = parseInt(req.params.id);
      const validatorId = req.user.id;
      
      // Get the existing contract
      const existingContract = await storage.getContract(contractId);
      if (!existingContract) {
        return res.status(404).json({ message: "Contract not found" });
      }
      
      // Check contract status
      if (existingContract.status !== 'pending') {
        return res.status(400).json({ message: "Only pending contracts can be validated" });
      }
      
      // Validate the contract
      const validatedContract = await storage.validateContract(contractId, validatorId);
      res.status(200).json(validatedContract);
    } catch (error) {
      next(error);
    }
  });

  // Change contract status
  app.put("/api/contracts/:id/status", isAuthenticated, async (req, res, next) => {
    try {
      const contractId = parseInt(req.params.id);
      const { status } = req.body;
      const userRole = req.user.role;
      
      if (!status) {
        return res.status(400).json({ message: "Status is required" });
      }
      
      // Get the existing contract
      const existingContract = await storage.getContract(contractId);
      if (!existingContract) {
        return res.status(404).json({ message: "Contract not found" });
      }
      
      // Role-based permission check for status changes
      let allowed = false;
      
      if (userRole === 'telemarketer') {
        // Telemarketers can only change from draft to pending
        allowed = existingContract.createdBy === req.user.id && 
                 existingContract.status === 'draft' && 
                 status === 'pending';
      } else if (userRole === 'supervisor') {
        // Supervisors can validate, reject, or send back to draft
        allowed = ['validated', 'rejected', 'draft'].includes(status) && 
                 existingContract.status === 'pending';
      } else if (userRole === 'backoffice') {
        // Backoffice can mark as completed or rejected
        allowed = ['completed', 'rejected'].includes(status) && 
                 existingContract.status === 'validated';
      } else if (userRole === 'admin') {
        // Admins can change to any status
        allowed = true;
      }
      
      if (!allowed) {
        return res.status(403).json({ message: "Forbidden: You cannot change the contract to this status" });
      }
      
      // Update the contract status
      const updatedContract = await storage.updateContract(contractId, { status });
      res.status(200).json(updatedContract);
    } catch (error) {
      next(error);
    }
  });

  // ========= Appointment Routes =========
  
  // Create a new appointment
  app.post("/api/appointments", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      const appointmentData = insertAppointmentSchema.parse({
        ...req.body,
        createdBy: userId
      });
      
      const appointment = await storage.createAppointment(appointmentData);
      res.status(201).json(appointment);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  // Get all appointments
  app.get("/api/appointments", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      const userRole = req.user.role;
      
      let appointments;
      if (userRole === 'telemarketer') {
        // Telemarketers only see their own appointments
        appointments = await storage.listUserAppointments(userId);
      } else if (['supervisor', 'admin'].includes(userRole)) {
        // Supervisors and admins see all appointments
        appointments = await storage.listAppointments();
      } else {
        // Other roles don't have access to appointments
        return res.status(403).json({ message: "Forbidden: Insufficient permissions" });
      }
      
      res.status(200).json(appointments);
    } catch (error) {
      next(error);
    }
  });

  // Get a specific appointment
  app.get("/api/appointments/:id", isAuthenticated, async (req, res, next) => {
    try {
      const appointmentId = parseInt(req.params.id);
      const userId = req.user.id;
      const userRole = req.user.role;
      
      const appointment = await storage.getAppointment(appointmentId);
      if (!appointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      
      // Check permissions
      if (userRole === 'telemarketer' && appointment.createdBy !== userId) {
        return res.status(403).json({ message: "Forbidden: You don't have access to this appointment" });
      }
      
      res.status(200).json(appointment);
    } catch (error) {
      next(error);
    }
  });

  // Update an appointment
  app.put("/api/appointments/:id", isAuthenticated, async (req, res, next) => {
    try {
      const appointmentId = parseInt(req.params.id);
      const userId = req.user.id;
      const userRole = req.user.role;
      
      // Get the existing appointment
      const existingAppointment = await storage.getAppointment(appointmentId);
      if (!existingAppointment) {
        return res.status(404).json({ message: "Appointment not found" });
      }
      
      // Check permissions
      if (userRole === 'telemarketer' && existingAppointment.createdBy !== userId) {
        return res.status(403).json({ message: "Forbidden: You don't have access to this appointment" });
      }
      
      // Update the appointment
      const updatedAppointment = await storage.updateAppointment(appointmentId, req.body);
      res.status(200).json(updatedAppointment);
    } catch (error) {
      next(error);
    }
  });

  // ========= Time Tracking Routes =========
  
  // Check in (start working)
  app.post("/api/time/checkin", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      
      // Check if user is already checked in
      const latestTracking = await storage.getLatestUserTimeTracking(userId);
      if (latestTracking && latestTracking.status === 'in') {
        return res.status(400).json({ message: "You are already checked in" });
      }
      
      // Create new time tracking entry
      const timeTracking = await storage.createTimeTracking({
        userId,
        status: 'in',
        timestamp: new Date(),
        notes: req.body.notes || "Check in"
      });
      
      res.status(201).json(timeTracking);
    } catch (error) {
      next(error);
    }
  });

  // Check out (end working)
  app.post("/api/time/checkout", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      
      // Check if user is checked in
      const latestTracking = await storage.getLatestUserTimeTracking(userId);
      if (!latestTracking || latestTracking.status !== 'in') {
        return res.status(400).json({ message: "You are not checked in" });
      }
      
      // Create new time tracking entry for checkout
      const timeTracking = await storage.createTimeTracking({
        userId,
        status: 'out',
        timestamp: new Date(),
        notes: req.body.notes || "Check out"
      });
      
      res.status(201).json(timeTracking);
    } catch (error) {
      next(error);
    }
  });

  // Start a pause
  app.post("/api/time/pause/start", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      
      // Check if user is checked in
      const latestTracking = await storage.getLatestUserTimeTracking(userId);
      if (!latestTracking || latestTracking.status !== 'in') {
        return res.status(400).json({ message: "You must be checked in to start a pause" });
      }
      
      // Check if there's already an active pause
      const activePause = await storage.getActivePause(latestTracking.id);
      if (activePause) {
        return res.status(400).json({ message: "You already have an active pause" });
      }
      
      // Create pause record
      const pause = await storage.createPause({
        timeTrackingId: latestTracking.id,
        startTime: new Date()
      });
      
      // Create time tracking entry for pause
      const timeTracking = await storage.createTimeTracking({
        userId,
        status: 'pause',
        timestamp: new Date(),
        notes: req.body.notes || "Pause started"
      });
      
      res.status(201).json({ pause, timeTracking });
    } catch (error) {
      next(error);
    }
  });

  // End a pause
  app.post("/api/time/pause/end", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      
      // Check if user is checked in
      const latestTracking = await storage.getLatestUserTimeTracking(userId);
      if (!latestTracking) {
        return res.status(400).json({ message: "No active time tracking session found" });
      }
      
      // Get active pause for this time tracking session
      const activePause = await storage.getActivePause(latestTracking.id);
      if (!activePause) {
        return res.status(400).json({ message: "No active pause found" });
      }
      
      // Calculate pause duration in minutes
      const endTime = new Date();
      const durationMs = endTime.getTime() - activePause.startTime.getTime();
      const durationMinutes = Math.round(durationMs / (1000 * 60));
      
      // Update pause record
      const updatedPause = await storage.updatePause(
        activePause.id,
        endTime,
        durationMinutes
      );
      
      // Create time tracking entry for resuming work
      const timeTracking = await storage.createTimeTracking({
        userId,
        status: 'in',
        timestamp: new Date(),
        notes: req.body.notes || "Work resumed after pause"
      });
      
      res.status(200).json({ pause: updatedPause, timeTracking });
    } catch (error) {
      next(error);
    }
  });

  // Get today's time tracking for current user
  app.get("/api/time/today", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      const today = new Date();
      
      const timeTrackings = await storage.getUserTimeTrackingByDate(userId, today);
      res.status(200).json(timeTrackings);
    } catch (error) {
      next(error);
    }
  });

  // ========= Statistics Routes =========
  
  // Get user's statistics for a specific date
  app.get("/api/statistics/user/:date?", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      const dateParam = req.params.date;
      const date = dateParam ? new Date(dateParam) : new Date();
      
      const statistics = await storage.getUserStatisticsByDate(userId, date);
      
      if (!statistics) {
        return res.status(200).json({ 
          userId,
          date,
          contractsCreated: 0,
          contractsValidated: 0,
          appointmentsScheduled: 0,
          hoursWorked: 0,
          pauseTime: 0
        });
      }
      
      res.status(200).json(statistics);
    } catch (error) {
      next(error);
    }
  });

  // Get user's statistics for a date range
  app.get("/api/statistics/user/range/:startDate/:endDate", isAuthenticated, async (req, res, next) => {
    try {
      const userId = req.user.id;
      const { startDate, endDate } = req.params;
      
      const start = new Date(startDate);
      const end = new Date(endDate);
      
      const statistics = await storage.getUserStatisticsByDateRange(userId, start, end);
      res.status(200).json(statistics);
    } catch (error) {
      next(error);
    }
  });

  // Create or update statistics
  app.post("/api/statistics", hasRole(['admin', 'supervisor']), async (req, res, next) => {
    try {
      const statisticsData = insertStatisticsSchema.parse(req.body);
      
      const statistics = await storage.createOrUpdateStatistics(statisticsData);
      res.status(201).json(statistics);
    } catch (error) {
      if (error instanceof ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      next(error);
    }
  });

  // ========= User Routes =========
  
  // Create a new user
  app.post("/api/users", hasRole(['manager', 'responsable_rh', 'responsable_administratif']), async (req, res, next) => {
    try {
      const userData = { ...req.body };
      
      // Check if username already exists
      const existingUser = await storage.getUserByUsername(userData.username);
      if (existingUser) {
        return res.status(400).json({ message: "Ce nom d'utilisateur existe déjà" });
      }
      
      // Hash the password
      userData.password = await hashPassword(userData.password || 'password123');
      
      // Validate with schema
      try {
        insertUserSchema.parse(userData);
      } catch (error) {
        if (error instanceof ZodError) {
          const validationError = fromZodError(error);
          return res.status(400).json({ message: validationError.message });
        }
        throw error;
      }
      
      // Create the user
      const newUser = await storage.createUser(userData);
      
      // Remove password from response
      const { password, ...userWithoutPassword } = newUser;
      
      res.status(201).json(userWithoutPassword);
    } catch (error) {
      next(error);
    }
  });
  
  // Get all users (admin and supervisors only)
  app.get("/api/users", hasRole(['manager', 'responsable_rh', 'responsable_administratif']), async (req, res, next) => {
    try {
      const users = await storage.listUsers();
      
      // Remove passwords from response
      const safeUsers = users.map(user => {
        const { password, ...userWithoutPassword } = user;
        return userWithoutPassword;
      });
      
      res.status(200).json(safeUsers);
    } catch (error) {
      next(error);
    }
  });

  // Get a specific user
  app.get("/api/users/:id", hasRole(['manager', 'responsable_rh', 'responsable_administratif']), async (req, res, next) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.getUser(userId);
      
      if (!user) {
        return res.status(404).json({ message: "User not found" });
      }
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      next(error);
    }
  });

  // Update a user (self or admin only)
  app.put("/api/users/:id", isAuthenticated, async (req, res, next) => {
    try {
      const userId = parseInt(req.params.id);
      const currentUser = req.user;
      
      // Check permissions
      if (currentUser?.id !== userId && !['manager', 'responsable_rh', 'responsable_administratif'].includes(currentUser?.role || '')) {
        return res.status(403).json({ message: "Interdit: Vous ne pouvez pas mettre à jour cet utilisateur" });
      }
      
      // Get the existing user
      const existingUser = await storage.getUser(userId);
      if (!existingUser) {
        return res.status(404).json({ message: "Utilisateur non trouvé" });
      }
      
      // If the request is trying to change the role, only admins can do that
      if (req.body.role && req.body.role !== existingUser.role && !['manager', 'responsable_rh', 'responsable_administratif'].includes(currentUser?.role || '')) {
        return res.status(403).json({ message: "Interdit: Seuls les administrateurs peuvent changer les rôles" });
      }
      
      // Update the user
      let userData = { ...req.body };
      
      // If there's a new password, hash it
      if (userData.password) {
        userData.password = await hashPassword(userData.password);
      }
      
      const updatedUser = await storage.updateUser(userId, userData);
      
      // Remove password from response
      const { password, ...userWithoutPassword } = updatedUser;
      
      res.status(200).json(userWithoutPassword);
    } catch (error) {
      next(error);
    }
  });

  // Function to hash passwords (same as in auth.ts)
  const scryptAsync = promisify(scrypt);
  async function hashPassword(password: string) {
    const salt = randomBytes(16).toString("hex");
    const buf = (await scryptAsync(password, salt, 64)) as Buffer;
    return `${buf.toString("hex")}.${salt}`;
  }

  // Configure multer for file uploads
  const upload = multer({ 
    storage: multer.memoryStorage(),
    limits: {
      fileSize: 5 * 1024 * 1024, // 5MB max file size
    },
    fileFilter: (req, file, cb) => {
      if (file.mimetype === 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' ||
          file.mimetype === 'application/vnd.ms-excel') {
        cb(null, true);
      } else {
        cb(null, false);
        return cb(new Error('Seuls les fichiers .xlsx et .xls sont autorisés'));
      }
    }
  });

  // Import users from Excel file (admin only)
  app.post("/api/users/import", hasRole(['manager']), upload.single('file'), async (req, res, next) => {
    try {
      if (!req.file) {
        return res.status(400).json({ message: "Aucun fichier n'a été téléchargé" });
      }

      // Parse Excel file
      const workbook = XLSX.read(req.file.buffer, { type: 'buffer' });
      const sheetName = workbook.SheetNames[0];
      const worksheet = workbook.Sheets[sheetName];
      const data = XLSX.utils.sheet_to_json(worksheet);

      if (!data || data.length === 0) {
        return res.status(400).json({ message: "Le fichier Excel est vide ou ne contient pas de données valides" });
      }

      const results = {
        success: 0,
        errors: [] as Array<{ row: number; error: string }>
      };

      // Process each row
      for (let i = 0; i < data.length; i++) {
        const row = data[i] as any;
        try {
          // Validate and prepare user data
          if (!row.username || !row.firstName || !row.lastName || !row.email || !row.role) {
            results.errors.push({
              row: i + 2, // +2 because Excel rows start at 1 and there's a header row
              error: "Données manquantes. Les champs requis sont : username, firstName, lastName, email, role"
            });
            continue;
          }

          // Check if user already exists
          const existingUser = await storage.getUserByUsername(row.username);
          if (existingUser) {
            results.errors.push({
              row: i + 2,
              error: `L'utilisateur avec le nom d'utilisateur '${row.username}' existe déjà`
            });
            continue;
          }

          // Generate a default password if none provided
          const password = row.password || 'password123';
          const hashedPassword = await hashPassword(password);

          // Create the user
          const userData = {
            username: row.username,
            password: hashedPassword,
            email: row.email,
            firstName: row.firstName,
            lastName: row.lastName,
            role: row.role,
            language: row.language || 'fr',
            phone: row.phone || null,
            isActive: row.isActive !== undefined ? row.isActive : true,
          };

          await storage.createUser(userData);
          results.success++;
        } catch (error) {
          results.errors.push({
            row: i + 2,
            error: error instanceof Error ? error.message : "Erreur inconnue"
          });
        }
      }

      res.status(200).json({
        message: `Import terminé. ${results.success} utilisateurs créés avec succès, ${results.errors.length} erreurs.`,
        details: results
      });
    } catch (error) {
      next(error);
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
