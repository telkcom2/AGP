import { 
  User as SchemaUser, InsertUser, 
  Contract as SchemaContract, InsertContract, 
  Appointment as SchemaAppointment, InsertAppointment, 
  TimeTracking as SchemaTimeTracking, InsertTimeTracking,
  Pause as SchemaPause, InsertPause,
  Statistics as SchemaStatistics, InsertStatistics
} from "@shared/schema";
import session from "express-session";
import { format } from "date-fns";
import createMemoryStore from "memorystore";

// Implémentation temporaire pour utiliser une base en mémoire pour test
const MemoryStore = createMemoryStore(session);

export interface IStorage {
  // User operations
  getUser(id: number): Promise<SchemaUser | undefined>;
  getUserByUsername(username: string): Promise<SchemaUser | undefined>;
  createUser(user: InsertUser): Promise<SchemaUser>;
  updateUser(id: number, user: Partial<SchemaUser>): Promise<SchemaUser | undefined>;
  listUsers(): Promise<SchemaUser[]>;
  updateUserLastLogin(id: number): Promise<void>;
  
  // Contract operations
  createContract(contract: InsertContract): Promise<SchemaContract>;
  getContract(id: number): Promise<SchemaContract | undefined>;
  getContractByNumber(contractNumber: string): Promise<SchemaContract | undefined>;
  listContracts(): Promise<SchemaContract[]>;
  listUserContracts(userId: number): Promise<SchemaContract[]>;
  updateContract(id: number, contract: Partial<SchemaContract>): Promise<SchemaContract | undefined>;
  validateContract(id: number, validatedBy: number): Promise<SchemaContract | undefined>;

  // Appointment operations
  createAppointment(appointment: InsertAppointment): Promise<SchemaAppointment>;
  getAppointment(id: number): Promise<SchemaAppointment | undefined>;
  listAppointments(): Promise<SchemaAppointment[]>;
  listUserAppointments(userId: number): Promise<SchemaAppointment[]>;
  updateAppointment(id: number, appointment: Partial<SchemaAppointment>): Promise<SchemaAppointment | undefined>;
  
  // Time tracking operations
  createTimeTracking(timeTracking: InsertTimeTracking): Promise<SchemaTimeTracking>;
  getUserTimeTrackingByDate(userId: number, date: Date): Promise<SchemaTimeTracking[]>;
  getLatestUserTimeTracking(userId: number): Promise<SchemaTimeTracking | undefined>;

  // Pause operations
  createPause(pause: InsertPause): Promise<SchemaPause>;
  updatePause(id: number, endTime: Date, duration: number): Promise<SchemaPause | undefined>;
  getActivePause(timeTrackingId: number): Promise<SchemaPause | undefined>;

  // Statistics operations
  createOrUpdateStatistics(statistics: InsertStatistics): Promise<SchemaStatistics>;
  getUserStatisticsByDate(userId: number, date: Date): Promise<SchemaStatistics | undefined>;
  getUserStatisticsByDateRange(userId: number, startDate: Date, endDate: Date): Promise<SchemaStatistics[]>;
  
  // Session store
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: SchemaUser[] = [];
  private contracts: SchemaContract[] = [];
  private appointments: SchemaAppointment[] = [];
  private timeTrackings: SchemaTimeTracking[] = [];
  private pauses: SchemaPause[] = [];
  private statistics: SchemaStatistics[] = [];
  private userIdCounter = 1;
  private contractIdCounter = 1;
  private appointmentIdCounter = 1;
  private timeTrackingIdCounter = 1;
  private pauseIdCounter = 1;
  private statisticsIdCounter = 1;
  sessionStore: session.Store;

  constructor() {
    // Utiliser MemoryStore pour la session
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000 // 24h en millisecondes
    });

    // Ajouter un utilisateur administrateur par défaut
    const now = new Date();
    this.users.push({
      id: this.userIdCounter++,
      username: 'admin',
      password: 'password', // Mot de passe simple pour pouvoir se connecter facilement
      email: 'admin@example.com',
      firstName: 'Admin',
      lastName: 'User',
      role: 'manager' as const, // Rôle de manager (remplace admin)
      language: 'fr',
      phone: null,
      lastLogin: null,
      isActive: true,
      createdAt: now,
      updatedAt: now
    });
  }

  // Implémentation des méthodes User
  async getUser(id: number): Promise<SchemaUser | undefined> {
    return this.users.find(user => user.id === id);
  }

  async getUserByUsername(username: string): Promise<SchemaUser | undefined> {
    return this.users.find(user => user.username === username);
  }

  async createUser(user: InsertUser): Promise<SchemaUser> {
    const now = new Date();
    // S'assurer que les valeurs par défaut sont définies
    const role = user.role || 'televendeur';
    const language = user.language || 'fr';
    
    const newUser: SchemaUser = {
      id: this.userIdCounter++,
      username: user.username,
      password: user.password,
      firstName: user.firstName,
      lastName: user.lastName,
      email: user.email,
      role: role,
      language: language,
      phone: user.phone || null,
      isActive: user.isActive ?? true,
      createdAt: now,
      updatedAt: now,
      lastLogin: null
    };
    this.users.push(newUser);
    return newUser;
  }

  async updateUser(id: number, userData: Partial<SchemaUser>): Promise<SchemaUser | undefined> {
    const userIndex = this.users.findIndex(user => user.id === id);
    if (userIndex === -1) return undefined;
    
    const updatedUser = {
      ...this.users[userIndex],
      ...userData,
      updatedAt: new Date()
    };
    
    this.users[userIndex] = updatedUser;
    return updatedUser;
  }

  async listUsers(): Promise<SchemaUser[]> {
    return [...this.users];
  }

  async updateUserLastLogin(id: number): Promise<void> {
    const userIndex = this.users.findIndex(user => user.id === id);
    if (userIndex !== -1) {
      this.users[userIndex].lastLogin = new Date();
      this.users[userIndex].updatedAt = new Date();
    }
  }

  // Implémentation des méthodes Contract
  async createContract(contract: InsertContract): Promise<SchemaContract> {
    const now = new Date();
    const id = this.contractIdCounter++;
    const contractNumber = `C-${now.getFullYear()}-${id.toString().padStart(3, '0')}`;
    
    // Création du contrat avec les valeurs par défaut
    const newContract: SchemaContract = {
      id,
      contractNumber,
      customerId: contract.customerId || null,
      customerName: contract.customerName,
      customerEmail: contract.customerEmail || null,
      customerPhone: contract.customerPhone || null,
      productType: contract.productType,
      contractValue: contract.contractValue,
      status: 'draft',
      createdBy: contract.createdBy,
      validatedBy: null,
      validatedAt: null,
      notes: contract.notes || null,
      createdAt: now,
      updatedAt: now
    };
    
    this.contracts.push(newContract);
    return newContract;
  }

  async getContract(id: number): Promise<SchemaContract | undefined> {
    return this.contracts.find(contract => contract.id === id);
  }

  async getContractByNumber(contractNumber: string): Promise<SchemaContract | undefined> {
    return this.contracts.find(contract => contract.contractNumber === contractNumber);
  }

  async listContracts(): Promise<SchemaContract[]> {
    return [...this.contracts];
  }

  async listUserContracts(userId: number): Promise<SchemaContract[]> {
    return this.contracts.filter(contract => contract.createdBy === userId);
  }

  async updateContract(id: number, contractData: Partial<SchemaContract>): Promise<SchemaContract | undefined> {
    const contractIndex = this.contracts.findIndex(contract => contract.id === id);
    if (contractIndex === -1) return undefined;
    
    const updatedContract = {
      ...this.contracts[contractIndex],
      ...contractData,
      updatedAt: new Date()
    };
    
    this.contracts[contractIndex] = updatedContract;
    return updatedContract;
  }

  async validateContract(id: number, validatedBy: number): Promise<SchemaContract | undefined> {
    const contractIndex = this.contracts.findIndex(contract => contract.id === id);
    if (contractIndex === -1) return undefined;
    
    const now = new Date();
    const validatedContract = {
      ...this.contracts[contractIndex],
      status: 'validated' as const,
      validatedBy,
      validatedAt: now,
      updatedAt: now
    };
    
    this.contracts[contractIndex] = validatedContract;
    return validatedContract;
  }

  // Implémentation des méthodes Appointment
  async createAppointment(appointment: InsertAppointment): Promise<SchemaAppointment> {
    const now = new Date();
    
    const newAppointment: SchemaAppointment = {
      id: this.appointmentIdCounter++,
      title: appointment.title,
      description: appointment.description || null,
      customerId: appointment.customerId || null,
      customerName: appointment.customerName,
      date: appointment.date,
      duration: appointment.duration,
      status: 'scheduled',
      location: appointment.location || null,
      createdBy: appointment.createdBy,
      userId: appointment.userId || null,
      notes: appointment.notes || null,
      createdAt: now,
      updatedAt: now
    };
    
    this.appointments.push(newAppointment);
    return newAppointment;
  }

  async getAppointment(id: number): Promise<SchemaAppointment | undefined> {
    return this.appointments.find(appointment => appointment.id === id);
  }

  async listAppointments(): Promise<SchemaAppointment[]> {
    return [...this.appointments];
  }

  async listUserAppointments(userId: number): Promise<SchemaAppointment[]> {
    return this.appointments.filter(appointment => appointment.userId === userId);
  }

  async updateAppointment(id: number, appointmentData: Partial<SchemaAppointment>): Promise<SchemaAppointment | undefined> {
    const appointmentIndex = this.appointments.findIndex(appointment => appointment.id === id);
    if (appointmentIndex === -1) return undefined;
    
    const updatedAppointment = {
      ...this.appointments[appointmentIndex],
      ...appointmentData,
      updatedAt: new Date()
    };
    
    this.appointments[appointmentIndex] = updatedAppointment;
    return updatedAppointment;
  }

  // Implémentation des méthodes TimeTracking
  async createTimeTracking(timeTrackingData: InsertTimeTracking): Promise<SchemaTimeTracking> {
    const now = new Date();
    
    // Assurer que toutes les propriétés requises sont présentes
    const newTimeTracking: SchemaTimeTracking = {
      id: this.timeTrackingIdCounter++,
      userId: timeTrackingData.userId,
      date: timeTrackingData.date || now,
      status: timeTrackingData.status,
      startTime: timeTrackingData.startTime || now,
      timestamp: timeTrackingData.timestamp || now,
      endTime: null,
      totalDuration: null,
      notes: timeTrackingData.notes || null,
      createdAt: now,
      updatedAt: now
    };
    
    this.timeTrackings.push(newTimeTracking);
    return newTimeTracking;
  }

  async getUserTimeTrackingByDate(userId: number, date: Date): Promise<SchemaTimeTracking[]> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);
    
    return this.timeTrackings.filter(tt => 
      tt.userId === userId && 
      tt.date >= startOfDay && 
      tt.date <= endOfDay
    );
  }

  async getLatestUserTimeTracking(userId: number): Promise<SchemaTimeTracking | undefined> {
    const userTracks = this.timeTrackings
      .filter(tt => tt.userId === userId)
      .sort((a, b) => b.startTime.getTime() - a.startTime.getTime());
    
    return userTracks.length > 0 ? userTracks[0] : undefined;
  }

  // Implémentation des méthodes Pause
  async createPause(pauseData: InsertPause): Promise<SchemaPause> {
    const now = new Date();
    const newPause: SchemaPause = {
      ...pauseData,
      id: this.pauseIdCounter++,
      startTime: pauseData.startTime || now,
      endTime: null,
      duration: null,
      reason: null,
      createdAt: now,
      updatedAt: now
    };
    
    this.pauses.push(newPause);
    return newPause;
  }

  async updatePause(id: number, endTime: Date, duration: number): Promise<SchemaPause | undefined> {
    const pauseIndex = this.pauses.findIndex(pause => pause.id === id);
    if (pauseIndex === -1) return undefined;
    
    const updatedPause = {
      ...this.pauses[pauseIndex],
      endTime,
      duration,
      updatedAt: new Date()
    };
    
    this.pauses[pauseIndex] = updatedPause;
    return updatedPause;
  }

  async getActivePause(timeTrackingId: number): Promise<SchemaPause | undefined> {
    return this.pauses.find(
      pause => pause.timeTrackingId === timeTrackingId && !pause.endTime
    );
  }

  // Implémentation des méthodes Statistics
  async createOrUpdateStatistics(statisticsData: InsertStatistics): Promise<SchemaStatistics> {
    const date = new Date(statisticsData.date);
    date.setHours(0, 0, 0, 0);
    
    // Chercher des statistiques existantes pour cette date et cet utilisateur
    const existingStats = await this.getUserStatisticsByDate(statisticsData.userId, date);
    
    if (existingStats) {
      // Mettre à jour les statistiques existantes
      const statsIndex = this.statistics.findIndex(stats => stats.id === existingStats.id);
      if (statsIndex !== -1) {
        const now = new Date();
        const updatedStats: SchemaStatistics = {
          ...this.statistics[statsIndex],
          userId: statisticsData.userId,
          date: date,
          contractsCreated: statisticsData.contractsCreated ?? this.statistics[statsIndex].contractsCreated,
          contractsValidated: statisticsData.contractsValidated ?? this.statistics[statsIndex].contractsValidated,
          appointmentsScheduled: statisticsData.appointmentsScheduled ?? this.statistics[statsIndex].appointmentsScheduled,
          hoursWorked: statisticsData.hoursWorked ?? this.statistics[statsIndex].hoursWorked,
          pauseTime: statisticsData.pauseTime ?? this.statistics[statsIndex].pauseTime,
          updatedAt: now,
          id: this.statistics[statsIndex].id,
          createdAt: this.statistics[statsIndex].createdAt
        };
        
        this.statistics[statsIndex] = updatedStats;
        return updatedStats;
      }
    }
    
    // Créer de nouvelles statistiques
    const now = new Date();
    const newStats: SchemaStatistics = {
      id: this.statisticsIdCounter++,
      userId: statisticsData.userId,
      date: date,
      contractsCreated: statisticsData.contractsCreated ?? 0,
      contractsValidated: statisticsData.contractsValidated ?? 0,
      appointmentsScheduled: statisticsData.appointmentsScheduled ?? 0,
      hoursWorked: statisticsData.hoursWorked ?? 0,
      pauseTime: statisticsData.pauseTime ?? 0,
      createdAt: now,
      updatedAt: now
    };
    
    this.statistics.push(newStats);
    return newStats;
  }

  async getUserStatisticsByDate(userId: number, date: Date): Promise<SchemaStatistics | undefined> {
    const startOfDay = new Date(date);
    startOfDay.setHours(0, 0, 0, 0);
    
    const endOfDay = new Date(date);
    endOfDay.setHours(23, 59, 59, 999);
    
    return this.statistics.find(
      stats => stats.userId === userId && 
              stats.date >= startOfDay && 
              stats.date <= endOfDay
    );
  }

  async getUserStatisticsByDateRange(userId: number, startDate: Date, endDate: Date): Promise<SchemaStatistics[]> {
    return this.statistics.filter(
      stats => stats.userId === userId && 
              stats.date >= startDate && 
              stats.date <= endDate
    );
  }
}

export const storage = new MemStorage();