import { drizzle } from "drizzle-orm/neon-serverless";
import { neon } from "@neondatabase/serverless";
import * as schema from "@shared/schema";

// Create the connection
const sql = neon(process.env.DATABASE_URL as string);
export const db = drizzle(sql, { schema });