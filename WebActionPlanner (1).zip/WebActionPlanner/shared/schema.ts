import { pgTable, text, serial, integer, boolean, timestamp, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { relations } from "drizzle-orm";
import { z } from "zod";

// Role enum
export const roleEnum = pgEnum('role', [
  'televendeur', 'team_leader', 'responsable_plateau', 'backoffice', 'responsable_backoffice',
  'responsable_formation', 'responsable_production', 'responsable_administratif', 
  'responsable_technique', 'responsable_rh', 'manager'
]);

// Contract status enum
export const contractStatusEnum = pgEnum('contract_status', [
  'draft', 'pending', 'validated', 'approved', 'rejected', 'completed'
]);

// Appointment status enum
export const appointmentStatusEnum = pgEnum('appointment_status', [
  'scheduled', 'confirmed', 'cancelled', 'completed'
]);

// Time tracking status enum
export const timeTrackingStatusEnum = pgEnum('time_tracking_status', [
  'in', 'out', 'pause'
]);

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull().unique(),
  role: roleEnum("role").notNull().default('televendeur'),
  language: text("language").notNull().default('fr'),
  phone: text("phone"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  lastLogin: timestamp("last_login"),
});

// Contracts table
export const contracts = pgTable("contracts", {
  id: serial("id").primaryKey(),
  contractNumber: text("contract_number").notNull().unique(),
  customerId: integer("customer_id"),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email"),
  customerPhone: text("customer_phone"),
  productType: text("product_type").notNull(),
  contractValue: integer("contract_value").notNull(),
  status: contractStatusEnum("status").notNull().default('draft'),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  createdBy: integer("created_by").notNull().references(() => users.id),
  validatedBy: integer("validated_by").references(() => users.id),
  validatedAt: timestamp("validated_at"),
  notes: text("notes"),
});

// Appointments table
export const appointments = pgTable("appointments", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description"),
  customerId: integer("customer_id"),
  customerName: text("customer_name").notNull(),
  date: timestamp("date").notNull(),
  duration: integer("duration").notNull(), // in minutes
  status: appointmentStatusEnum("status").notNull().default('scheduled'),
  location: text("location"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
  createdBy: integer("created_by").notNull().references(() => users.id),
  userId: integer("user_id").references(() => users.id),
  notes: text("notes"),
});

// Time tracking table
export const timeTracking = pgTable("time_tracking", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  date: timestamp("date").notNull().defaultNow(),
  status: timeTrackingStatusEnum("status").notNull(),
  startTime: timestamp("start_time").notNull().defaultNow(),
  endTime: timestamp("end_time"),
  totalDuration: integer("total_duration"), // in minutes
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Pauses table
export const pauses = pgTable("pauses", {
  id: serial("id").primaryKey(),
  timeTrackingId: integer("time_tracking_id").notNull().references(() => timeTracking.id),
  startTime: timestamp("start_time").notNull().defaultNow(),
  endTime: timestamp("end_time"),
  duration: integer("duration"), // in minutes
  reason: text("reason"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Statistics table
export const statistics = pgTable("statistics", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  date: timestamp("date").notNull(),
  contractsCreated: integer("contracts_created").notNull().default(0),
  contractsValidated: integer("contracts_validated").notNull().default(0),
  appointmentsScheduled: integer("appointments_scheduled").notNull().default(0),
  hoursWorked: integer("hours_worked").notNull().default(0), // in minutes
  pauseTime: integer("pause_time").notNull().default(0), // in minutes
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Schemas for insertion
export const insertUserSchema = createInsertSchema(users).omit({ 
  id: true, 
  createdAt: true,
  updatedAt: true,
  lastLogin: true 
});

export const insertContractSchema = createInsertSchema(contracts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  validatedAt: true
});

export const insertAppointmentSchema = createInsertSchema(appointments).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertTimeTrackingSchema = createInsertSchema(timeTracking).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

export const insertPauseSchema = createInsertSchema(pauses).omit({
  id: true,
  endTime: true,
  duration: true,
  createdAt: true,
  updatedAt: true
});

export const insertStatisticsSchema = createInsertSchema(statistics).omit({
  id: true,
  createdAt: true,
  updatedAt: true
});

// Relations definitions
export const usersRelations = relations(users, ({ many, one }) => ({
  contracts: many(contracts, { relationName: "user_contracts" }),
  appointments: many(appointments, { relationName: "user_appointments" }),
  timeTracking: many(timeTracking, { relationName: "user_timeTracking" }),
  statistics: many(statistics, { relationName: "user_statistics" }),
  validatedContracts: many(contracts, { relationName: "user_validatedContracts" }),
}));

export const contractsRelations = relations(contracts, ({ one }) => ({
  creator: one(users, {
    fields: [contracts.createdBy],
    references: [users.id],
    relationName: "user_contracts",
  }),
  validator: one(users, {
    fields: [contracts.validatedBy],
    references: [users.id],
    relationName: "user_validatedContracts",
  }),
}));

export const appointmentsRelations = relations(appointments, ({ one }) => ({
  creator: one(users, {
    fields: [appointments.createdBy],
    references: [users.id],
    relationName: "user_appointments",
  }),
}));

export const timeTrackingRelations = relations(timeTracking, ({ one, many }) => ({
  user: one(users, {
    fields: [timeTracking.userId],
    references: [users.id],
    relationName: "user_timeTracking",
  }),
  pauses: many(pauses, { relationName: "timeTracking_pauses" }),
}));

export const pausesRelations = relations(pauses, ({ one }) => ({
  timeTracking: one(timeTracking, {
    fields: [pauses.timeTrackingId],
    references: [timeTracking.id],
    relationName: "timeTracking_pauses",
  }),
}));

export const statisticsRelations = relations(statistics, ({ one }) => ({
  user: one(users, {
    fields: [statistics.userId],
    references: [users.id],
    relationName: "user_statistics",
  }),
}));

// Types for insert and select
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export type InsertContract = z.infer<typeof insertContractSchema>;
export type Contract = typeof contracts.$inferSelect;

export type InsertAppointment = z.infer<typeof insertAppointmentSchema>;
export type Appointment = typeof appointments.$inferSelect;

export type InsertTimeTracking = z.infer<typeof insertTimeTrackingSchema>;
export type TimeTracking = typeof timeTracking.$inferSelect;

export type InsertPause = z.infer<typeof insertPauseSchema>;
export type Pause = typeof pauses.$inferSelect;

export type InsertStatistics = z.infer<typeof insertStatisticsSchema>;
export type Statistics = typeof statistics.$inferSelect;
